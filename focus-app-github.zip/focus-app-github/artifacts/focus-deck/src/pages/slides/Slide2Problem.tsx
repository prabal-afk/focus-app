export default function Slide2Problem() {
  return (
    <div
      className="relative w-screen h-screen overflow-hidden"
      style={{
        backgroundColor: "#F4F4F5",
        display: "flex",
        flexDirection: "column",
        fontFamily: "'Space Grotesk', sans-serif",
        padding: "8vh 6vw",
        boxSizing: "border-box",
      }}
    >
      {/* Header bar */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "7vh" }}>
        <div style={{ fontSize: "1.2vw", fontWeight: 700, color: "#18181B", letterSpacing: "-0.02em" }}>focus</div>
        <div style={{ width: "3vw", height: "0.4vh", backgroundColor: "#18181B" }} />
      </div>

      {/* Two-column layout */}
      <div style={{ display: "flex", gap: "8vw", flex: 1 }}>
        {/* Left: headline */}
        <div style={{ width: "38vw", display: "flex", flexDirection: "column", justifyContent: "center" }}>
          <div style={{ width: "2.5vw", height: "0.35vh", backgroundColor: "#3B82F6", marginBottom: "2.5vh" }} />
          <h2
            style={{
              fontSize: "4.8vw",
              fontWeight: 700,
              lineHeight: 1.08,
              color: "#18181B",
              margin: 0,
              letterSpacing: "-0.03em",
              textWrap: "balance",
            }}
          >
            The problem with productivity tools
          </h2>
        </div>

        {/* Right: bullets */}
        <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "center", gap: "3.5vh" }}>
          <div style={{ display: "flex", alignItems: "flex-start", gap: "1.5vw" }}>
            <div style={{ width: "0.4vw", height: "0.4vw", borderRadius: "50%", backgroundColor: "#3B82F6", marginTop: "1.2vh", flexShrink: 0 }} />
            <p style={{ fontSize: "1.8vw", lineHeight: 1.5, color: "#18181B", margin: 0, fontWeight: 400 }}>
              Too many apps, too much context-switching
            </p>
          </div>
          <div style={{ display: "flex", alignItems: "flex-start", gap: "1.5vw" }}>
            <div style={{ width: "0.4vw", height: "0.4vw", borderRadius: "50%", backgroundColor: "#3B82F6", marginTop: "1.2vh", flexShrink: 0 }} />
            <p style={{ fontSize: "1.8vw", lineHeight: 1.5, color: "#18181B", margin: 0, fontWeight: 400 }}>
              Calendars don't talk to to-do lists
            </p>
          </div>
          <div style={{ display: "flex", alignItems: "flex-start", gap: "1.5vw" }}>
            <div style={{ width: "0.4vw", height: "0.4vw", borderRadius: "50%", backgroundColor: "#3B82F6", marginTop: "1.2vh", flexShrink: 0 }} />
            <p style={{ fontSize: "1.8vw", lineHeight: 1.5, color: "#18181B", margin: 0, fontWeight: 400 }}>
              Notes live somewhere else entirely
            </p>
          </div>
          <div style={{ display: "flex", alignItems: "flex-start", gap: "1.5vw" }}>
            <div style={{ width: "0.4vw", height: "0.4vw", borderRadius: "50%", backgroundColor: "#3B82F6", marginTop: "1.2vh", flexShrink: 0 }} />
            <p style={{ fontSize: "1.8vw", lineHeight: 1.5, color: "#18181B", margin: 0, fontWeight: 400 }}>
              Nothing surfaces what matters right now
            </p>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginTop: "5vh" }}>
        <div style={{ fontSize: "0.9vw", color: "#A1A1AA", textTransform: "uppercase", letterSpacing: "0.06em", fontFamily: "'DM Mono', monospace" }}>
          Focus / 2026
        </div>
        <div style={{ fontSize: "1vw", color: "#71717A", fontFamily: "'DM Mono', monospace" }}>02</div>
      </div>
    </div>
  );
}
