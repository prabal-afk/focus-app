const base = import.meta.env.BASE_URL;

export default function Slide1Title() {
  return (
    <div
      className="relative w-screen h-screen overflow-hidden"
      style={{ backgroundColor: "#F4F4F5", display: "flex", fontFamily: "'Space Grotesk', sans-serif" }}
    >
      {/* Left text panel */}
      <div
        style={{
          width: "50vw",
          height: "100vh",
          padding: "8vh 6vw",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          boxSizing: "border-box",
        }}
      >
        {/* Top bar */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div style={{ fontSize: "1.2vw", fontWeight: 700, color: "#18181B", letterSpacing: "-0.02em" }}>
            focus
          </div>
          <div style={{ fontSize: "1vw", fontWeight: 400, color: "#71717A", fontFamily: "'DM Mono', monospace" }}>
            2026
          </div>
        </div>

        {/* Main content */}
        <div style={{ display: "flex", flexDirection: "column", gap: "2.5vh" }}>
          <div style={{ width: "3vw", height: "0.4vh", backgroundColor: "#3B82F6" }} />
          <h1
            style={{
              fontSize: "6.5vw",
              fontWeight: 700,
              lineHeight: 1.05,
              color: "#18181B",
              margin: 0,
              letterSpacing: "-0.04em",
              textWrap: "balance",
            }}
          >
            Focus
          </h1>
          <p
            style={{
              fontSize: "1.6vw",
              lineHeight: 1.55,
              color: "#52525B",
              fontFamily: "'DM Mono', monospace",
              fontWeight: 400,
              maxWidth: "36vw",
              margin: 0,
            }}
          >
            A productivity companion for everything — tasks, notes, events, and focus sessions in one place.
          </p>
        </div>

        {/* Footer */}
        <div style={{ fontSize: "0.9vw", color: "#A1A1AA", textTransform: "uppercase", letterSpacing: "0.06em", fontFamily: "'DM Mono', monospace" }}>
          Built for mobile. Designed to keep you moving.
        </div>
      </div>

      {/* Right image panel */}
      <div
        style={{
          width: "50vw",
          height: "100vh",
          position: "relative",
          backgroundColor: "#E4E4E7",
          overflow: "hidden",
        }}
      >
        <img
          src={`${base}hero-workspace.png`}
          crossOrigin="anonymous"
          alt="Workspace"
          style={{
            width: "100%",
            height: "100%",
            objectFit: "cover",
            objectPosition: "center",
          }}
        />
        {/* Fade blend on left edge */}
        <div
          style={{
            position: "absolute",
            inset: 0,
            background: "linear-gradient(to right, rgba(244,244,245,1) 0%, rgba(244,244,245,0) 12%)",
          }}
        />
      </div>
    </div>
  );
}
