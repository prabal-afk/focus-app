export default function Slide3Features() {
  return (
    <div
      className="relative w-screen h-screen overflow-hidden"
      style={{
        backgroundColor: "#F4F4F5",
        display: "flex",
        flexDirection: "column",
        fontFamily: "'Space Grotesk', sans-serif",
        padding: "8vh 6vw",
        boxSizing: "border-box",
      }}
    >
      {/* Header bar */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "6vh" }}>
        <div style={{ fontSize: "1.2vw", fontWeight: 700, color: "#18181B", letterSpacing: "-0.02em" }}>focus</div>
        <div style={{ width: "3vw", height: "0.4vh", backgroundColor: "#18181B" }} />
      </div>

      {/* Title */}
      <div style={{ marginBottom: "5vh" }}>
        <div style={{ width: "2.5vw", height: "0.35vh", backgroundColor: "#3B82F6", marginBottom: "2vh" }} />
        <h2
          style={{
            fontSize: "3.8vw",
            fontWeight: 700,
            color: "#18181B",
            margin: 0,
            letterSpacing: "-0.03em",
          }}
        >
          One app, every workflow
        </h2>
      </div>

      {/* 3-column feature cards */}
      <div style={{ display: "flex", gap: "2.5vw", flex: 1 }}>
        {/* Col 1 */}
        <div
          style={{
            flex: 1,
            backgroundColor: "#FFFFFF",
            border: "1px solid #E4E4E7",
            padding: "3.5vh 2.5vw",
            display: "flex",
            flexDirection: "column",
            gap: "2vh",
          }}
        >
          <div style={{ fontSize: "1vw", fontWeight: 600, color: "#3B82F6", textTransform: "uppercase", letterSpacing: "0.08em", fontFamily: "'DM Mono', monospace" }}>
            Core
          </div>
          <div style={{ fontSize: "1.5vw", fontWeight: 600, color: "#18181B", lineHeight: 1.4 }}>To-Do</div>
          <div style={{ fontSize: "1.5vw", fontWeight: 600, color: "#18181B", lineHeight: 1.4 }}>Planner</div>
          <div style={{ fontSize: "1.5vw", fontWeight: 600, color: "#18181B", lineHeight: 1.4 }}>Notes</div>
          <div style={{ fontSize: "1.5vw", fontWeight: 600, color: "#18181B", lineHeight: 1.4 }}>Focus Timer</div>
        </div>

        {/* Col 2 */}
        <div
          style={{
            flex: 1,
            backgroundColor: "#18181B",
            padding: "3.5vh 2.5vw",
            display: "flex",
            flexDirection: "column",
            gap: "2vh",
          }}
        >
          <div style={{ fontSize: "1vw", fontWeight: 600, color: "#3B82F6", textTransform: "uppercase", letterSpacing: "0.08em", fontFamily: "'DM Mono', monospace" }}>
            Intelligence
          </div>
          <div style={{ fontSize: "1.5vw", fontWeight: 600, color: "#F4F4F5", lineHeight: 1.4 }}>AI Companion</div>
          <div style={{ fontSize: "1.5vw", fontWeight: 600, color: "#F4F4F5", lineHeight: 1.4 }}>Global Search</div>
          <div style={{ fontSize: "1.5vw", fontWeight: 600, color: "#F4F4F5", lineHeight: 1.4 }}>Stats & Insights</div>
        </div>

        {/* Col 3 */}
        <div
          style={{
            flex: 1,
            backgroundColor: "#E4E4E7",
            padding: "3.5vh 2.5vw",
            display: "flex",
            flexDirection: "column",
            gap: "2vh",
          }}
        >
          <div style={{ fontSize: "1vw", fontWeight: 600, color: "#52525B", textTransform: "uppercase", letterSpacing: "0.08em", fontFamily: "'DM Mono', monospace" }}>
            Automation
          </div>
          <div style={{ fontSize: "1.5vw", fontWeight: 600, color: "#18181B", lineHeight: 1.4 }}>Recurring Tasks</div>
          <div style={{ fontSize: "1.5vw", fontWeight: 600, color: "#18181B", lineHeight: 1.4 }}>Notifications</div>
          <div style={{ fontSize: "1.5vw", fontWeight: 400, color: "#52525B", lineHeight: 1.5, marginTop: "1vh", fontFamily: "'DM Mono', monospace", fontSize: "1.1vw" }}>
            Everything connected — complete a task, your stats update.
          </div>
        </div>
      </div>

      {/* Footer */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginTop: "4vh" }}>
        <div style={{ fontSize: "0.9vw", color: "#A1A1AA", textTransform: "uppercase", letterSpacing: "0.06em", fontFamily: "'DM Mono', monospace" }}>
          Focus / 2026
        </div>
        <div style={{ fontSize: "1vw", color: "#71717A", fontFamily: "'DM Mono', monospace" }}>03</div>
      </div>
    </div>
  );
}
