export default function Slide8Close() {
  return (
    <div
      className="relative w-screen h-screen overflow-hidden"
      style={{
        backgroundColor: "#18181B",
        display: "flex",
        flexDirection: "column",
        fontFamily: "'Space Grotesk', sans-serif",
        padding: "8vh 6vw",
        boxSizing: "border-box",
      }}
    >
      {/* Header bar */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div style={{ fontSize: "1.2vw", fontWeight: 700, color: "#F4F4F5", letterSpacing: "-0.02em" }}>focus</div>
        <div style={{ width: "3vw", height: "0.4vh", backgroundColor: "#F4F4F5" }} />
      </div>

      {/* Center content */}
      <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", textAlign: "center" }}>
        <div style={{ width: "2.5vw", height: "0.35vh", backgroundColor: "#3B82F6", marginBottom: "3vh" }} />
        <h2
          style={{
            fontSize: "6vw",
            fontWeight: 700,
            lineHeight: 1.05,
            color: "#F4F4F5",
            margin: 0,
            letterSpacing: "-0.04em",
            textWrap: "balance",
            marginBottom: "3vh",
          }}
        >
          Get started
        </h2>
        <p
          style={{
            fontSize: "1.8vw",
            color: "#A1A1AA",
            maxWidth: "42vw",
            margin: "0 0 5vh 0",
            lineHeight: 1.55,
            fontFamily: "'DM Mono', monospace",
          }}
        >
          Your tasks. Your schedule. Your notes. All in one place.
        </p>
        <div
          style={{
            display: "inline-block",
            padding: "1.8vh 3.5vw",
            backgroundColor: "#F4F4F5",
            color: "#18181B",
            fontSize: "1.3vw",
            fontWeight: 700,
            fontFamily: "'DM Mono', monospace",
            letterSpacing: "0.02em",
          }}
        >
          focus — built on Replit
        </div>
      </div>

      {/* Footer */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
        <div style={{ fontSize: "0.9vw", color: "#52525B", textTransform: "uppercase", letterSpacing: "0.06em", fontFamily: "'DM Mono', monospace" }}>
          Focus / 2026
        </div>
        <div style={{ fontSize: "1vw", color: "#71717A", fontFamily: "'DM Mono', monospace" }}>08</div>
      </div>
    </div>
  );
}
