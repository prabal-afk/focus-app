export default function Slide4AI() {
  return (
    <div
      className="relative w-screen h-screen overflow-hidden"
      style={{
        backgroundColor: "#18181B",
        display: "flex",
        flexDirection: "column",
        fontFamily: "'Space Grotesk', sans-serif",
        padding: "8vh 6vw",
        boxSizing: "border-box",
      }}
    >
      {/* Header bar */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "7vh" }}>
        <div style={{ fontSize: "1.2vw", fontWeight: 700, color: "#F4F4F5", letterSpacing: "-0.02em" }}>focus</div>
        <div style={{ width: "3vw", height: "0.4vh", backgroundColor: "#F4F4F5" }} />
      </div>

      {/* Content: left label + right detail */}
      <div style={{ display: "flex", gap: "8vw", flex: 1 }}>
        {/* Left */}
        <div style={{ width: "38vw", display: "flex", flexDirection: "column", justifyContent: "center" }}>
          <div style={{ width: "2.5vw", height: "0.35vh", backgroundColor: "#3B82F6", marginBottom: "2.5vh" }} />
          <h2
            style={{
              fontSize: "4.8vw",
              fontWeight: 700,
              lineHeight: 1.08,
              color: "#F4F4F5",
              margin: 0,
              letterSpacing: "-0.03em",
              textWrap: "balance",
            }}
          >
            AI that does the work
          </h2>
          <p style={{ fontSize: "1.3vw", color: "#71717A", marginTop: "2.5vh", lineHeight: 1.5, fontFamily: "'DM Mono', monospace", margin: "2.5vh 0 0 0" }}>
            Powered by OpenAI
          </p>
        </div>

        {/* Right: example + bullets */}
        <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "center", gap: "3.5vh" }}>
          {/* Chat example */}
          <div
            style={{
              backgroundColor: "#27272A",
              padding: "2.5vh 2vw",
              borderLeft: "0.3vw solid #3B82F6",
            }}
          >
            <p style={{ fontSize: "1.4vw", color: "#A1A1AA", margin: "0 0 0.8vh 0", fontFamily: "'DM Mono', monospace" }}>
              You say:
            </p>
            <p style={{ fontSize: "1.5vw", color: "#F4F4F5", margin: 0, lineHeight: 1.4, fontFamily: "'DM Mono', monospace" }}>
              "Remind me to review the proposal tomorrow at 9am"
            </p>
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: "2vh" }}>
            <div style={{ display: "flex", alignItems: "flex-start", gap: "1.2vw" }}>
              <div style={{ width: "0.4vw", height: "0.4vw", borderRadius: "50%", backgroundColor: "#3B82F6", marginTop: "1vh", flexShrink: 0 }} />
              <p style={{ fontSize: "1.6vw", color: "#D4D4D8", margin: 0, lineHeight: 1.4 }}>
                AI creates the task, schedules the event, sets the reminder
              </p>
            </div>
            <div style={{ display: "flex", alignItems: "flex-start", gap: "1.2vw" }}>
              <div style={{ width: "0.4vw", height: "0.4vw", borderRadius: "50%", backgroundColor: "#3B82F6", marginTop: "1vh", flexShrink: 0 }} />
              <p style={{ fontSize: "1.6vw", color: "#D4D4D8", margin: 0, lineHeight: 1.4 }}>
                Context-aware: knows your pending tasks and upcoming events
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginTop: "5vh" }}>
        <div style={{ fontSize: "0.9vw", color: "#52525B", textTransform: "uppercase", letterSpacing: "0.06em", fontFamily: "'DM Mono', monospace" }}>
          Focus / 2026
        </div>
        <div style={{ fontSize: "1vw", color: "#71717A", fontFamily: "'DM Mono', monospace" }}>04</div>
      </div>
    </div>
  );
}
