export default function Slide6Stack() {
  return (
    <div
      className="relative w-screen h-screen overflow-hidden"
      style={{
        backgroundColor: "#F4F4F5",
        display: "flex",
        flexDirection: "column",
        fontFamily: "'Space Grotesk', sans-serif",
        padding: "8vh 6vw",
        boxSizing: "border-box",
      }}
    >
      {/* Header bar */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "7vh" }}>
        <div style={{ fontSize: "1.2vw", fontWeight: 700, color: "#18181B", letterSpacing: "-0.02em" }}>focus</div>
        <div style={{ width: "3vw", height: "0.4vh", backgroundColor: "#18181B" }} />
      </div>

      <div style={{ display: "flex", gap: "8vw", flex: 1 }}>
        {/* Left: title */}
        <div style={{ width: "36vw", display: "flex", flexDirection: "column", justifyContent: "center" }}>
          <div style={{ width: "2.5vw", height: "0.35vh", backgroundColor: "#3B82F6", marginBottom: "2.5vh" }} />
          <h2
            style={{
              fontSize: "4.8vw",
              fontWeight: 700,
              lineHeight: 1.08,
              color: "#18181B",
              margin: 0,
              letterSpacing: "-0.03em",
              textWrap: "balance",
            }}
          >
            Built on a modern stack
          </h2>
          <p style={{ fontSize: "1.3vw", color: "#71717A", marginTop: "2.5vh", lineHeight: 1.6, fontFamily: "'DM Mono', monospace", margin: "2.5vh 0 0 0" }}>
            Mobile-first. Runs in any browser. No install required.
          </p>
        </div>

        {/* Right: two rows of tech tags */}
        <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "center", gap: "3vh" }}>
          {/* Row 1 */}
          <div>
            <div style={{ fontSize: "0.9vw", fontWeight: 600, color: "#A1A1AA", textTransform: "uppercase", letterSpacing: "0.08em", fontFamily: "'DM Mono', monospace", marginBottom: "1.5vh" }}>
              Frontend
            </div>
            <div style={{ display: "flex", gap: "1.2vw", flexWrap: "wrap" }}>
              <span style={{ backgroundColor: "#18181B", color: "#F4F4F5", fontSize: "1.3vw", fontWeight: 600, padding: "0.8vh 1.5vw", fontFamily: "'DM Mono', monospace" }}>React + Vite</span>
              <span style={{ backgroundColor: "#18181B", color: "#F4F4F5", fontSize: "1.3vw", fontWeight: 600, padding: "0.8vh 1.5vw", fontFamily: "'DM Mono', monospace" }}>TypeScript</span>
              <span style={{ backgroundColor: "#18181B", color: "#F4F4F5", fontSize: "1.3vw", fontWeight: 600, padding: "0.8vh 1.5vw", fontFamily: "'DM Mono', monospace" }}>Tailwind CSS</span>
            </div>
          </div>

          {/* Row 2 */}
          <div>
            <div style={{ fontSize: "0.9vw", fontWeight: 600, color: "#A1A1AA", textTransform: "uppercase", letterSpacing: "0.08em", fontFamily: "'DM Mono', monospace", marginBottom: "1.5vh" }}>
              Motion & Data
            </div>
            <div style={{ display: "flex", gap: "1.2vw", flexWrap: "wrap" }}>
              <span style={{ border: "1px solid #D4D4D8", color: "#18181B", fontSize: "1.3vw", fontWeight: 600, padding: "0.8vh 1.5vw", fontFamily: "'DM Mono', monospace" }}>Framer Motion</span>
              <span style={{ border: "1px solid #D4D4D8", color: "#18181B", fontSize: "1.3vw", fontWeight: 600, padding: "0.8vh 1.5vw", fontFamily: "'DM Mono', monospace" }}>localStorage</span>
            </div>
          </div>

          {/* Row 3 */}
          <div>
            <div style={{ fontSize: "0.9vw", fontWeight: 600, color: "#A1A1AA", textTransform: "uppercase", letterSpacing: "0.08em", fontFamily: "'DM Mono', monospace", marginBottom: "1.5vh" }}>
              APIs
            </div>
            <div style={{ display: "flex", gap: "1.2vw", flexWrap: "wrap" }}>
              <span style={{ backgroundColor: "#3B82F6", color: "#FFFFFF", fontSize: "1.3vw", fontWeight: 600, padding: "0.8vh 1.5vw", fontFamily: "'DM Mono', monospace" }}>OpenAI API</span>
              <span style={{ backgroundColor: "#3B82F6", color: "#FFFFFF", fontSize: "1.3vw", fontWeight: 600, padding: "0.8vh 1.5vw", fontFamily: "'DM Mono', monospace" }}>Web Notifications</span>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginTop: "5vh" }}>
        <div style={{ fontSize: "0.9vw", color: "#A1A1AA", textTransform: "uppercase", letterSpacing: "0.06em", fontFamily: "'DM Mono', monospace" }}>
          Focus / 2026
        </div>
        <div style={{ fontSize: "1vw", color: "#71717A", fontFamily: "'DM Mono', monospace" }}>06</div>
      </div>
    </div>
  );
}
