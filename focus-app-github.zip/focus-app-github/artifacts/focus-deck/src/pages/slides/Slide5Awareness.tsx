export default function Slide5Awareness() {
  return (
    <div
      className="relative w-screen h-screen overflow-hidden"
      style={{
        backgroundColor: "#F4F4F5",
        display: "flex",
        flexDirection: "column",
        fontFamily: "'Space Grotesk', sans-serif",
        padding: "8vh 6vw",
        boxSizing: "border-box",
      }}
    >
      {/* Header bar */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "6vh" }}>
        <div style={{ fontSize: "1.2vw", fontWeight: 700, color: "#18181B", letterSpacing: "-0.02em" }}>focus</div>
        <div style={{ width: "3vw", height: "0.4vh", backgroundColor: "#18181B" }} />
      </div>

      {/* Title */}
      <div style={{ marginBottom: "5vh" }}>
        <div style={{ width: "2.5vw", height: "0.35vh", backgroundColor: "#3B82F6", marginBottom: "2vh" }} />
        <h2 style={{ fontSize: "3.8vw", fontWeight: 700, color: "#18181B", margin: 0, letterSpacing: "-0.03em" }}>
          Stay on top of everything
        </h2>
      </div>

      {/* 2x2 grid of feature cards */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "2vw", flex: 1 }}>
        {/* Card 1 */}
        <div style={{ backgroundColor: "#FFFFFF", border: "1px solid #E4E4E7", padding: "3vh 2.5vw" }}>
          <div style={{ fontSize: "0.95vw", fontWeight: 600, color: "#3B82F6", textTransform: "uppercase", letterSpacing: "0.08em", fontFamily: "'DM Mono', monospace", marginBottom: "1.5vh" }}>
            Search
          </div>
          <p style={{ fontSize: "1.6vw", fontWeight: 600, color: "#18181B", margin: "0 0 1vh 0", lineHeight: 1.2 }}>
            Global search
          </p>
          <p style={{ fontSize: "1.2vw", color: "#71717A", margin: 0, lineHeight: 1.5, fontFamily: "'DM Mono', monospace" }}>
            Find anything across all tasks, notes, and events instantly
          </p>
        </div>

        {/* Card 2 */}
        <div style={{ backgroundColor: "#18181B", padding: "3vh 2.5vw" }}>
          <div style={{ fontSize: "0.95vw", fontWeight: 600, color: "#3B82F6", textTransform: "uppercase", letterSpacing: "0.08em", fontFamily: "'DM Mono', monospace", marginBottom: "1.5vh" }}>
            Alerts
          </div>
          <p style={{ fontSize: "1.6vw", fontWeight: 600, color: "#F4F4F5", margin: "0 0 1vh 0", lineHeight: 1.2 }}>
            Push notifications
          </p>
          <p style={{ fontSize: "1.2vw", color: "#71717A", margin: 0, lineHeight: 1.5, fontFamily: "'DM Mono', monospace" }}>
            Browser reminders for due tasks and upcoming events
          </p>
        </div>

        {/* Card 3 */}
        <div style={{ backgroundColor: "#E4E4E7", padding: "3vh 2.5vw" }}>
          <div style={{ fontSize: "0.95vw", fontWeight: 600, color: "#52525B", textTransform: "uppercase", letterSpacing: "0.08em", fontFamily: "'DM Mono', monospace", marginBottom: "1.5vh" }}>
            Automation
          </div>
          <p style={{ fontSize: "1.6vw", fontWeight: 600, color: "#18181B", margin: "0 0 1vh 0", lineHeight: 1.2 }}>
            Recurring tasks
          </p>
          <p style={{ fontSize: "1.2vw", color: "#52525B", margin: 0, lineHeight: 1.5, fontFamily: "'DM Mono', monospace" }}>
            Auto-generate on completion — daily, weekly, or monthly
          </p>
        </div>

        {/* Card 4 */}
        <div style={{ backgroundColor: "#FFFFFF", border: "1px solid #E4E4E7", padding: "3vh 2.5vw" }}>
          <div style={{ fontSize: "0.95vw", fontWeight: 600, color: "#3B82F6", textTransform: "uppercase", letterSpacing: "0.08em", fontFamily: "'DM Mono', monospace", marginBottom: "1.5vh" }}>
            Analytics
          </div>
          <p style={{ fontSize: "1.6vw", fontWeight: 600, color: "#18181B", margin: "0 0 1vh 0", lineHeight: 1.2 }}>
            Weekly stats
          </p>
          <p style={{ fontSize: "1.2vw", color: "#71717A", margin: 0, lineHeight: 1.5, fontFamily: "'DM Mono', monospace" }}>
            Streaks, completion rate, 7-day bar chart
          </p>
        </div>
      </div>

      {/* Footer */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginTop: "4vh" }}>
        <div style={{ fontSize: "0.9vw", color: "#A1A1AA", textTransform: "uppercase", letterSpacing: "0.06em", fontFamily: "'DM Mono', monospace" }}>
          Focus / 2026
        </div>
        <div style={{ fontSize: "1vw", color: "#71717A", fontFamily: "'DM Mono', monospace" }}>05</div>
      </div>
    </div>
  );
}
