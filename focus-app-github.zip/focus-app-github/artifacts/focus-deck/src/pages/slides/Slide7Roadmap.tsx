export default function Slide7Roadmap() {
  return (
    <div
      className="relative w-screen h-screen overflow-hidden"
      style={{
        backgroundColor: "#F4F4F5",
        display: "flex",
        flexDirection: "column",
        fontFamily: "'Space Grotesk', sans-serif",
        padding: "8vh 6vw",
        boxSizing: "border-box",
      }}
    >
      {/* Header bar */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "6vh" }}>
        <div style={{ fontSize: "1.2vw", fontWeight: 700, color: "#18181B", letterSpacing: "-0.02em" }}>focus</div>
        <div style={{ width: "3vw", height: "0.4vh", backgroundColor: "#18181B" }} />
      </div>

      {/* Title */}
      <div style={{ marginBottom: "5vh" }}>
        <div style={{ width: "2.5vw", height: "0.35vh", backgroundColor: "#3B82F6", marginBottom: "2vh" }} />
        <h2 style={{ fontSize: "3.8vw", fontWeight: 700, color: "#18181B", margin: 0, letterSpacing: "-0.03em" }}>
          What's next
        </h2>
      </div>

      {/* Roadmap items in a horizontal row */}
      <div style={{ display: "flex", gap: "2vw", flex: 1 }}>
        {/* Item 1 */}
        <div style={{ flex: 1, display: "flex", flexDirection: "column" }}>
          <div style={{ width: "100%", height: "0.35vh", backgroundColor: "#3B82F6", marginBottom: "2.5vh" }} />
          <p style={{ fontSize: "1.6vw", fontWeight: 700, color: "#18181B", margin: "0 0 1.2vh 0", lineHeight: 1.2 }}>
            Subtasks
          </p>
          <p style={{ fontSize: "1.2vw", color: "#71717A", margin: 0, lineHeight: 1.5, fontFamily: "'DM Mono', monospace" }}>
            Break any to-do into a checklist with a progress bar on the parent card
          </p>
        </div>

        {/* Item 2 */}
        <div style={{ flex: 1, display: "flex", flexDirection: "column" }}>
          <div style={{ width: "100%", height: "0.35vh", backgroundColor: "#D4D4D8", marginBottom: "2.5vh" }} />
          <p style={{ fontSize: "1.6vw", fontWeight: 700, color: "#18181B", margin: "0 0 1.2vh 0", lineHeight: 1.2 }}>
            Pomodoro Timer
          </p>
          <p style={{ fontSize: "1.2vw", color: "#71717A", margin: 0, lineHeight: 1.5, fontFamily: "'DM Mono', monospace" }}>
            Work/break cycles with session counter and auto-start option
          </p>
        </div>

        {/* Item 3 */}
        <div style={{ flex: 1, display: "flex", flexDirection: "column" }}>
          <div style={{ width: "100%", height: "0.35vh", backgroundColor: "#D4D4D8", marginBottom: "2.5vh" }} />
          <p style={{ fontSize: "1.6vw", fontWeight: 700, color: "#18181B", margin: "0 0 1.2vh 0", lineHeight: 1.2 }}>
            Habit Tracker
          </p>
          <p style={{ fontSize: "1.2vw", color: "#71717A", margin: 0, lineHeight: 1.5, fontFamily: "'DM Mono', monospace" }}>
            Daily habits with streak counter and 30-day heatmap
          </p>
        </div>

        {/* Item 4 */}
        <div style={{ flex: 1, display: "flex", flexDirection: "column" }}>
          <div style={{ width: "100%", height: "0.35vh", backgroundColor: "#D4D4D8", marginBottom: "2.5vh" }} />
          <p style={{ fontSize: "1.6vw", fontWeight: 700, color: "#18181B", margin: "0 0 1.2vh 0", lineHeight: 1.2 }}>
            Data Export
          </p>
          <p style={{ fontSize: "1.2vw", color: "#71717A", margin: 0, lineHeight: 1.5, fontFamily: "'DM Mono', monospace" }}>
            Download all tasks, notes, and events as a JSON backup
          </p>
        </div>

        {/* Item 5 */}
        <div style={{ flex: 1, display: "flex", flexDirection: "column" }}>
          <div style={{ width: "100%", height: "0.35vh", backgroundColor: "#D4D4D8", marginBottom: "2.5vh" }} />
          <p style={{ fontSize: "1.6vw", fontWeight: 700, color: "#18181B", margin: "0 0 1.2vh 0", lineHeight: 1.2 }}>
            Bulk Actions
          </p>
          <p style={{ fontSize: "1.2vw", color: "#71717A", margin: 0, lineHeight: 1.5, fontFamily: "'DM Mono', monospace" }}>
            Drag-to-reorder and multi-select complete or delete
          </p>
        </div>
      </div>

      {/* Footer */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginTop: "4vh" }}>
        <div style={{ fontSize: "0.9vw", color: "#A1A1AA", textTransform: "uppercase", letterSpacing: "0.06em", fontFamily: "'DM Mono', monospace" }}>
          Focus / 2026
        </div>
        <div style={{ fontSize: "1vw", color: "#71717A", fontFamily: "'DM Mono', monospace" }}>07</div>
      </div>
    </div>
  );
}
