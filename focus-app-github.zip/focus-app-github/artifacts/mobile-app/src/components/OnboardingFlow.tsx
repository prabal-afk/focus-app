import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Sparkles, Sun, Moon, Monitor, ArrowRight, Check,
  CheckSquare, CalendarDays, StickyNote, Timer,
  Search, TrendingUp, RefreshCw, Bell,
} from "lucide-react";
import { useSettings, Theme } from "@/context/SettingsContext";

const ONBOARDING_KEY = "onboarding_v1";

const GOALS = [
  { id: "work",     label: "Work",       icon: "💼", desc: "Projects & deadlines"    },
  { id: "study",    label: "Study",      icon: "📚", desc: "Assignments & sessions"  },
  { id: "personal", label: "Personal",   icon: "🌱", desc: "Habits & personal goals" },
  { id: "all",      label: "Everything", icon: "🎯", desc: "Work, study & life"      },
];

const THEMES: { value: Theme; label: string; Icon: React.ElementType; desc: string }[] = [
  { value: "light",  label: "Light",  Icon: Sun,     desc: "Clean & bright"      },
  { value: "dark",   label: "Dark",   Icon: Moon,    desc: "Easy on the eyes"    },
  { value: "system", label: "System", Icon: Monitor, desc: "Matches your device" },
];

const FEATURES = [
  {
    Icon: CheckSquare,
    bg: "bg-violet-100",
    icon: "text-violet-600",
    title: "To-Do List",
    desc: "Add tasks with priorities, categories & due dates. Filter, sort and clear completed items.",
  },
  {
    Icon: CalendarDays,
    bg: "bg-sky-100",
    icon: "text-sky-600",
    title: "Planner",
    desc: "Calendar view with drag-and-drop scheduling. Add timed events and track completions.",
  },
  {
    Icon: StickyNote,
    bg: "bg-amber-100",
    icon: "text-amber-600",
    title: "Notes",
    desc: "Write, colour-code, tag and pin notes. Search your thoughts instantly.",
  },
  {
    Icon: Timer,
    bg: "bg-rose-100",
    icon: "text-rose-600",
    title: "Focus Timer",
    desc: "Countdown and interval timers to keep you in deep work mode.",
  },
  {
    Icon: Sparkles,
    bg: "bg-indigo-100",
    icon: "text-indigo-600",
    title: "AI Companion",
    desc: "Chat naturally to add tasks, schedule events, manage notes and get advice.",
  },
  {
    Icon: Search,
    bg: "bg-emerald-100",
    icon: "text-emerald-600",
    title: "Global Search",
    desc: "Find anything across all your tasks, notes and events in one search.",
  },
  {
    Icon: TrendingUp,
    bg: "bg-orange-100",
    icon: "text-orange-600",
    title: "Stats & Insights",
    desc: "Weekly bar charts, streaks and a full breakdown of your productivity.",
  },
  {
    Icon: RefreshCw,
    bg: "bg-teal-100",
    icon: "text-teal-600",
    title: "Recurring Items",
    desc: "Set tasks or events to repeat daily, weekly or monthly — next ones appear automatically.",
  },
  {
    Icon: Bell,
    bg: "bg-purple-100",
    icon: "text-purple-600",
    title: "Notifications",
    desc: "Browser reminders for tasks due today and events starting in 5 minutes.",
  },
];

function Screen({ children, scrollable }: { children: React.ReactNode; scrollable?: boolean }) {
  return (
    <motion.div
      initial={{ opacity: 0, x: 40 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -40 }}
      transition={{ type: "spring", stiffness: 320, damping: 28 }}
      className={`flex-1 flex flex-col ${scrollable ? "overflow-hidden" : "items-center justify-center px-8 pb-10"}`}
    >
      {children}
    </motion.div>
  );
}

export function OnboardingFlow() {
  const { updateSettings } = useSettings();
  const [visible, setVisible] = useState(() => !localStorage.getItem(ONBOARDING_KEY));
  const [step, setStep]       = useState(0);
  const [name, setName]       = useState("");
  const [goal, setGoal]       = useState<string | null>(null);
  const [theme, setTheme]     = useState<Theme>("system");

  if (!visible) return null;

  function applyAndShowTour() {
    updateSettings({ name: name.trim() || "Friend", theme });
    setStep(3);
  }

  function finish() {
    localStorage.setItem(ONBOARDING_KEY, "1");
    setVisible(false);
  }

  const TOTAL_STEPS = 4;

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0, scale: 0.97 }}
          transition={{ duration: 0.25 }}
          className="absolute inset-0 z-[100] bg-background flex flex-col overflow-hidden"
        >
          {/* Progress dots */}
          <div className="flex justify-center gap-2 pt-12 pb-4 shrink-0">
            {Array.from({ length: TOTAL_STEPS }).map((_, i) => (
              <motion.div
                key={i}
                layout
                className={`h-1.5 rounded-full transition-all duration-300 ${
                  i === step
                    ? "w-8 bg-indigo-500"
                    : i < step
                    ? "w-3 bg-indigo-300"
                    : "w-3 bg-border"
                }`}
              />
            ))}
          </div>

          <AnimatePresence mode="wait">

            {/* ── Step 0: Name ── */}
            {step === 0 && (
              <Screen key="name">
                <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-indigo-100 to-violet-100 flex items-center justify-center mb-6 shadow-inner">
                  <Sparkles className="w-10 h-10 text-indigo-500" />
                </div>
                <h1 className="text-2xl font-bold text-foreground mb-2">Welcome! 👋</h1>
                <p className="text-sm text-muted-foreground mb-8 text-center max-w-[260px] leading-relaxed">
                  Your personal productivity companion. Let's set things up in a minute.
                </p>
                <div className="w-full">
                  <label className="text-xs font-semibold text-muted-foreground uppercase tracking-widest mb-2 block">
                    What should I call you?
                  </label>
                  <input
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && name.trim() && setStep(1)}
                    placeholder="Your name"
                    autoFocus
                    className="w-full h-12 px-4 rounded-2xl bg-muted border border-border text-sm focus:outline-none focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 placeholder:text-muted-foreground/50 text-foreground transition-all"
                  />
                </div>
                <button
                  onClick={() => setStep(1)}
                  disabled={!name.trim()}
                  className="mt-6 w-full h-12 rounded-2xl bg-indigo-600 text-white font-semibold text-sm flex items-center justify-center gap-2 disabled:opacity-40 hover:bg-indigo-700 transition-all active:scale-95"
                >
                  Continue <ArrowRight className="w-4 h-4" />
                </button>
                <button
                  onClick={() => { setName("Friend"); setStep(1); }}
                  className="mt-3 text-xs text-muted-foreground underline underline-offset-2"
                >
                  Skip
                </button>
              </Screen>
            )}

            {/* ── Step 1: Goal ── */}
            {step === 1 && (
              <Screen key="goal">
                <h1 className="text-2xl font-bold text-foreground mb-1">What's your focus?</h1>
                <p className="text-sm text-muted-foreground mb-6 text-center">
                  We'll personalise the experience for you
                </p>
                <div className="w-full grid grid-cols-2 gap-3 mb-6">
                  {GOALS.map((g) => (
                    <button
                      key={g.id}
                      onClick={() => setGoal(g.id)}
                      className={`relative flex flex-col items-start p-4 rounded-2xl border-2 text-left transition-all active:scale-95 ${
                        goal === g.id
                          ? "border-indigo-500 bg-indigo-50 shadow-sm"
                          : "border-border bg-card hover:border-indigo-200"
                      }`}
                    >
                      {goal === g.id && (
                        <div className="absolute top-3 right-3 w-4 h-4 rounded-full bg-indigo-600 flex items-center justify-center">
                          <Check className="w-2.5 h-2.5 text-white" />
                        </div>
                      )}
                      <span className="text-2xl mb-2">{g.icon}</span>
                      <p className="font-semibold text-sm text-foreground">{g.label}</p>
                      <p className="text-[11px] text-muted-foreground mt-0.5 leading-relaxed">{g.desc}</p>
                    </button>
                  ))}
                </div>
                <button
                  onClick={() => setStep(2)}
                  disabled={!goal}
                  className="w-full h-12 rounded-2xl bg-indigo-600 text-white font-semibold text-sm flex items-center justify-center gap-2 disabled:opacity-40 hover:bg-indigo-700 transition-all active:scale-95"
                >
                  Continue <ArrowRight className="w-4 h-4" />
                </button>
                <button
                  onClick={() => { setGoal("all"); setStep(2); }}
                  className="mt-3 text-xs text-muted-foreground underline underline-offset-2"
                >
                  Skip
                </button>
              </Screen>
            )}

            {/* ── Step 2: Theme ── */}
            {step === 2 && (
              <Screen key="theme">
                <h1 className="text-2xl font-bold text-foreground mb-1">Choose your look</h1>
                <p className="text-sm text-muted-foreground mb-6 text-center">
                  You can always change this in Settings
                </p>
                <div className="w-full flex flex-col gap-3 mb-6">
                  {THEMES.map(({ value, label, Icon, desc }) => (
                    <button
                      key={value}
                      onClick={() => setTheme(value)}
                      className={`flex items-center gap-4 p-4 rounded-2xl border-2 text-left transition-all active:scale-95 ${
                        theme === value
                          ? "border-indigo-500 bg-indigo-50"
                          : "border-border bg-card hover:border-indigo-200"
                      }`}
                    >
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                        theme === value ? "bg-indigo-100" : "bg-muted"
                      }`}>
                        <Icon className={`w-5 h-5 ${theme === value ? "text-indigo-600" : "text-muted-foreground"}`} />
                      </div>
                      <div className="flex-1">
                        <p className="font-semibold text-sm text-foreground">{label}</p>
                        <p className="text-[11px] text-muted-foreground">{desc}</p>
                      </div>
                      {theme === value && (
                        <div className="w-5 h-5 rounded-full bg-indigo-600 flex items-center justify-center shrink-0">
                          <Check className="w-3 h-3 text-white" />
                        </div>
                      )}
                    </button>
                  ))}
                </div>
                <button
                  onClick={applyAndShowTour}
                  className="w-full h-12 rounded-2xl bg-gradient-to-r from-indigo-600 to-violet-600 text-white font-semibold text-sm flex items-center justify-center gap-2 shadow-lg shadow-indigo-200 hover:brightness-105 transition-all active:scale-95"
                >
                  <Sparkles className="w-4 h-4" /> Show me what's inside
                </button>
              </Screen>
            )}

            {/* ── Step 3: Feature Tour ── */}
            {step === 3 && (
              <Screen key="tour" scrollable>
                {/* Header — fixed at top */}
                <div className="px-7 pt-3 pb-4 shrink-0 text-center">
                  <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-br from-indigo-100 to-violet-100 mb-4">
                    <Sparkles className="w-7 h-7 text-indigo-500" />
                  </div>
                  <h1 className="text-xl font-bold text-foreground mb-1">
                    You're all set{name && name !== "Friend" ? `, ${name}` : ""}! 🎉
                  </h1>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    Here's a quick look at everything available to you.
                  </p>
                </div>

                {/* Scrollable feature list */}
                <div className="flex-1 overflow-y-auto px-5 pb-2">
                  <div className="space-y-2.5">
                    {FEATURES.map(({ Icon, bg, icon, title, desc }, idx) => (
                      <motion.div
                        key={title}
                        initial={{ opacity: 0, y: 12 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: idx * 0.045, type: "spring", stiffness: 280, damping: 24 }}
                        className="flex items-start gap-3.5 bg-card border border-border rounded-2xl px-4 py-3.5"
                      >
                        <div className={`w-9 h-9 rounded-xl ${bg} flex items-center justify-center shrink-0 mt-0.5`}>
                          <Icon className={`w-4.5 h-4.5 ${icon}`} strokeWidth={2} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-semibold text-foreground leading-tight">{title}</p>
                          <p className="text-[11px] text-muted-foreground mt-0.5 leading-relaxed">{desc}</p>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </div>

                {/* CTA — fixed at bottom */}
                <div className="px-5 pt-4 pb-8 shrink-0">
                  <button
                    onClick={finish}
                    className="w-full h-12 rounded-2xl bg-gradient-to-r from-indigo-600 to-violet-600 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-indigo-200 hover:brightness-105 transition-all active:scale-95"
                  >
                    Let's go! <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </Screen>
            )}

          </AnimatePresence>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
