import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Settings, X, Sun, Moon, Monitor, Bell,
  User, Palette, CheckSquare, CalendarDays, Timer, Sparkles,
  ChevronRight, Check, ShieldCheck,
} from "lucide-react";
import { useSettings, Theme, Settings as SettingsType } from "@/context/SettingsContext";
import { useNotifications } from "@/context/NotificationsContext";

const THEMES: { value: Theme; label: string; icon: React.ElementType }[] = [
  { value: "light",  label: "Light",  icon: Sun     },
  { value: "dark",   label: "Dark",   icon: Moon    },
  { value: "system", label: "System", icon: Monitor },
];

const ACCENTS: { value: SettingsType["accentColor"]; bg: string; ring: string }[] = [
  { value: "indigo",  bg: "bg-indigo-500",  ring: "ring-indigo-500"  },
  { value: "rose",    bg: "bg-rose-500",    ring: "ring-rose-500"    },
  { value: "emerald", bg: "bg-emerald-500", ring: "ring-emerald-500" },
  { value: "amber",   bg: "bg-amber-500",   ring: "ring-amber-500"   },
  { value: "sky",     bg: "bg-sky-500",     ring: "ring-sky-500"     },
];

function SectionHeader({ label }: { label: string }) {
  return (
    <p className="text-[11px] font-bold uppercase tracking-widest text-muted-foreground/50 pt-5 pb-2 px-1">
      {label}
    </p>
  );
}

function Toggle({ value, onChange }: { value: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      role="switch"
      aria-checked={value}
      onClick={() => onChange(!value)}
      className={`relative w-11 h-6 rounded-full transition-colors duration-200 shrink-0 ${
        value ? "bg-indigo-500" : "bg-slate-200 dark:bg-slate-700"
      }`}
    >
      <motion.span
        animate={{ x: value ? 22 : 2 }}
        transition={{ type: "spring", stiffness: 500, damping: 30 }}
        className="absolute top-0.5 left-0 w-5 h-5 rounded-full bg-white shadow"
        style={{ display: "block" }}
      />
    </button>
  );
}

function NotifRow({
  icon: Icon, iconBg, label, sublabel, value, onChange,
}: {
  icon: React.ElementType; iconBg: string; label: string; sublabel: string;
  value: boolean; onChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-center gap-3 py-3 border-b border-border/40 last:border-0">
      <div className={`w-8 h-8 ${iconBg} rounded-xl flex items-center justify-center shrink-0`}>
        <Icon className="w-4 h-4 text-white" strokeWidth={2} />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-semibold text-foreground leading-tight">{label}</p>
        <p className="text-[11px] text-muted-foreground mt-0.5 leading-tight">{sublabel}</p>
      </div>
      <Toggle value={value} onChange={onChange} />
    </div>
  );
}

export function SettingsPanel({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { settings, updateSettings } = useSettings();
  const { browserPermission, requestPermission } = useNotifications();
  const [nameInput, setNameInput] = useState(settings.name);

  function saveName() {
    const trimmed = nameInput.trim();
    if (trimmed !== settings.name) updateSettings({ name: trimmed });
  }

  return (
    <AnimatePresence>
      {open && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black/40 z-20"
            onClick={onClose}
          />

          {/* Sheet */}
          <motion.div
            initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }}
            transition={{ type: "spring", stiffness: 300, damping: 32 }}
            className="absolute bottom-0 left-0 right-0 bg-background rounded-t-3xl z-30 shadow-2xl max-h-[90%] flex flex-col"
          >
            {/* Drag handle */}
            <div className="flex justify-center pt-3 pb-1 shrink-0">
              <div className="w-10 h-1 rounded-full bg-border" />
            </div>

            {/* Header */}
            <div className="px-5 pt-2 pb-4 border-b border-border flex items-center justify-between shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 bg-slate-100 dark:bg-slate-800 rounded-xl flex items-center justify-center">
                  <Settings className="w-5 h-5 text-foreground" />
                </div>
                <h2 className="text-lg font-bold">Settings</h2>
              </div>
              <button
                onClick={onClose}
                className="w-8 h-8 rounded-full bg-muted flex items-center justify-center text-muted-foreground hover:bg-muted/80"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Scrollable body */}
            <div className="flex-1 overflow-y-auto px-5 pb-10">

              {/* ── Profile ── */}
              <SectionHeader label="Profile" />
              <div className="bg-card border border-border rounded-2xl p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-indigo-100 dark:bg-indigo-900/40 rounded-full flex items-center justify-center shrink-0">
                    <User className="w-5 h-5 text-indigo-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-[11px] text-muted-foreground font-medium mb-1">Your name</p>
                    <input
                      value={nameInput}
                      onChange={(e) => setNameInput(e.target.value)}
                      onBlur={saveName}
                      onKeyDown={(e) => e.key === "Enter" && (saveName(), (e.target as HTMLInputElement).blur())}
                      placeholder="Enter your name…"
                      className="w-full bg-transparent text-sm font-semibold text-foreground placeholder:text-muted-foreground/40 focus:outline-none"
                    />
                  </div>
                  {nameInput.trim() !== settings.name && (
                    <button
                      onClick={saveName}
                      className="w-7 h-7 rounded-full bg-indigo-500 flex items-center justify-center shrink-0"
                    >
                      <Check className="w-3.5 h-3.5 text-white" strokeWidth={3} />
                    </button>
                  )}
                </div>
                <p className="text-[11px] text-muted-foreground/60 mt-2.5">
                  Shown in your greeting on the home screen.
                </p>
              </div>

              {/* ── Appearance ── */}
              <SectionHeader label="Appearance" />
              <div className="bg-card border border-border rounded-2xl p-4 space-y-4">
                {/* Theme grid */}
                <div>
                  <p className="text-xs font-semibold text-muted-foreground mb-2.5 flex items-center gap-1.5">
                    <Palette className="w-3.5 h-3.5" /> Theme
                  </p>
                  <div className="grid grid-cols-3 gap-2">
                    {THEMES.map((t) => {
                      const active = settings.theme === t.value;
                      return (
                        <button
                          key={t.value}
                          onClick={() => updateSettings({ theme: t.value })}
                          className={`flex flex-col items-center gap-1.5 py-3 rounded-xl border-2 transition-all text-xs font-semibold ${
                            active
                              ? "border-indigo-500 bg-indigo-50 text-indigo-700 dark:bg-indigo-950/40 dark:text-indigo-300"
                              : "border-border text-muted-foreground"
                          }`}
                        >
                          <t.icon className="w-4 h-4" />
                          {t.label}
                          {active && <span className="w-1.5 h-1.5 rounded-full bg-indigo-500" />}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Accent dots */}
                <div>
                  <p className="text-xs font-semibold text-muted-foreground mb-2.5 flex items-center gap-1.5">
                    <Palette className="w-3.5 h-3.5" /> Accent colour
                  </p>
                  <div className="flex gap-3 items-center">
                    {ACCENTS.map((a) => (
                      <button
                        key={a.value}
                        onClick={() => updateSettings({ accentColor: a.value })}
                        className={`w-8 h-8 rounded-full ${a.bg} transition-all ${
                          settings.accentColor === a.value
                            ? `ring-2 ring-offset-2 ${a.ring} scale-110`
                            : "opacity-60"
                        }`}
                      />
                    ))}
                  </div>
                </div>
              </div>

              {/* ── Notifications ── */}
              <SectionHeader label="Notifications" />
              <div className="bg-card border border-border rounded-2xl px-4 pt-1 pb-1">

                {/* Browser permission banner */}
                {browserPermission !== "granted" && (
                  <div className="flex items-center gap-3 py-3 border-b border-border/40">
                    <div className="w-8 h-8 bg-amber-100 dark:bg-amber-900/40 rounded-xl flex items-center justify-center shrink-0">
                      <Bell className="w-4 h-4 text-amber-600" strokeWidth={2} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-foreground leading-tight">System alerts</p>
                      <p className="text-[11px] text-muted-foreground mt-0.5 leading-tight">
                        {browserPermission === "denied" ? "Blocked in browser settings" : "Enable to get alerts when app is closed"}
                      </p>
                    </div>
                    {browserPermission === "default" ? (
                      <button
                        onClick={requestPermission}
                        className="shrink-0 flex items-center gap-1 px-3 py-1.5 rounded-full bg-indigo-600 text-white text-xs font-bold"
                      >
                        Enable <ChevronRight className="w-3 h-3" />
                      </button>
                    ) : (
                      <span className="text-[11px] text-rose-500 font-semibold shrink-0">Blocked</span>
                    )}
                  </div>
                )}

                {browserPermission === "granted" && (
                  <div className="flex items-center gap-3 py-3 border-b border-border/40">
                    <div className="w-8 h-8 bg-emerald-100 dark:bg-emerald-900/40 rounded-xl flex items-center justify-center shrink-0">
                      <ShieldCheck className="w-4 h-4 text-emerald-600" strokeWidth={2} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-foreground leading-tight">System alerts</p>
                      <p className="text-[11px] text-emerald-600 mt-0.5 leading-tight font-medium">Enabled</p>
                    </div>
                  </div>
                )}

                <NotifRow
                  icon={CheckSquare} iconBg="bg-emerald-500"
                  label="Task completed" sublabel="When you mark a task as done"
                  value={settings.notifyTaskComplete}
                  onChange={(v) => updateSettings({ notifyTaskComplete: v })}
                />
                <NotifRow
                  icon={CalendarDays} iconBg="bg-rose-500"
                  label="Due date alerts" sublabel="Tasks due today or tomorrow"
                  value={settings.notifyDueDate}
                  onChange={(v) => updateSettings({ notifyDueDate: v })}
                />
                <NotifRow
                  icon={Timer} iconBg="bg-violet-500"
                  label="Timer complete" sublabel="When a focus session ends"
                  value={settings.notifyTimer}
                  onChange={(v) => updateSettings({ notifyTimer: v })}
                />
                <NotifRow
                  icon={Sparkles} iconBg="bg-indigo-500"
                  label="AI companion" sublabel="Actions taken by the AI"
                  value={settings.notifyAi}
                  onChange={(v) => updateSettings({ notifyAi: v })}
                />
              </div>

              {/* ── About ── */}
              <SectionHeader label="About" />
              <div className="bg-card border border-border rounded-2xl px-4">
                {[
                  { label: "Version",    value: "1.0.0"        },
                  { label: "Built with", value: "React + Vite" },
                ].map((row) => (
                  <div key={row.label} className="flex items-center justify-between py-3.5 border-b border-border/40 last:border-0">
                    <p className="text-sm text-foreground font-medium">{row.label}</p>
                    <p className="text-sm text-muted-foreground">{row.value}</p>
                  </div>
                ))}
              </div>

            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
