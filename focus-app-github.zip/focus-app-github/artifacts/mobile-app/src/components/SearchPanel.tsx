import { useState, useEffect, useRef, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, X, CheckSquare, CalendarDays, StickyNote, ArrowRight } from "lucide-react";
import { useLocation } from "wouter";
import { useTodos } from "@/context/TodoContext";
import { usePlanner } from "@/context/PlannerContext";
import { useNotes } from "@/context/NotesContext";

interface SearchPanelProps {
  open: boolean;
  onClose: () => void;
}

const PRIORITY_COLOR: Record<string, string> = {
  high: "text-rose-500", medium: "text-amber-500", low: "text-emerald-500",
};

export function SearchPanel({ open, onClose }: SearchPanelProps) {
  const [, setLocation] = useLocation();
  const { todos }  = useTodos();
  const { events } = usePlanner();
  const { notes }  = useNotes();

  const [query, setQuery] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open) {
      setQuery("");
      setTimeout(() => inputRef.current?.focus(), 120);
    }
  }, [open]);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    if (open) window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [open, onClose]);

  const q = query.toLowerCase().trim();

  const results = useMemo(() => {
    if (!q) return { todos: [], events: [], notes: [] };
    return {
      todos:  todos.filter((t) => t.title.toLowerCase().includes(q)).slice(0, 5),
      events: events.filter((e) => e.title.toLowerCase().includes(q)).slice(0, 5),
      notes:  notes.filter((n) =>
        n.title.toLowerCase().includes(q) || n.body.toLowerCase().includes(q)
      ).slice(0, 5),
    };
  }, [q, todos, events, notes]);

  const total = results.todos.length + results.events.length + results.notes.length;
  const hasQuery = q.length > 0;

  function go(path: string) {
    onClose();
    setLocation(path);
  }

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black/40 z-30"
            onClick={onClose}
          />

          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ type: "spring", stiffness: 400, damping: 32 }}
            className="absolute top-0 left-0 right-0 z-40 bg-background rounded-b-3xl shadow-2xl flex flex-col"
            style={{ maxHeight: "78dvh" }}
          >
            {/* Search input */}
            <div className="flex items-center gap-3 px-5 pt-5 pb-3 border-b border-border">
              <Search className="w-5 h-5 text-muted-foreground shrink-0" />
              <input
                ref={inputRef}
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search tasks, notes, events…"
                className="flex-1 bg-transparent text-base focus:outline-none placeholder:text-muted-foreground/50 text-foreground"
                autoComplete="off"
                spellCheck={false}
              />
              {query && (
                <button onClick={() => setQuery("")} className="text-muted-foreground hover:text-foreground transition-colors">
                  <X className="w-4 h-4" />
                </button>
              )}
              <button
                onClick={onClose}
                className="text-xs text-muted-foreground font-medium border border-border rounded-lg px-2.5 py-1 hover:bg-muted transition-colors"
              >
                Cancel
              </button>
            </div>

            {/* Results */}
            <div className="flex-1 overflow-y-auto pb-6">
              {!hasQuery && (
                <div className="flex flex-col items-center justify-center py-12 text-center px-6">
                  <Search className="w-10 h-10 text-muted-foreground/20 mb-3" strokeWidth={1.5} />
                  <p className="text-sm text-muted-foreground">Search across all your tasks, notes and events</p>
                </div>
              )}

              {hasQuery && total === 0 && (
                <div className="flex flex-col items-center justify-center py-12 text-center px-6">
                  <p className="text-sm font-medium text-foreground mb-1">No results</p>
                  <p className="text-xs text-muted-foreground">Try a different keyword</p>
                </div>
              )}

              {/* Tasks */}
              {results.todos.length > 0 && (
                <div className="px-4 pt-4">
                  <p className="text-[11px] font-bold uppercase tracking-widest text-muted-foreground/50 mb-2 px-1">
                    Tasks
                  </p>
                  <div className="space-y-1">
                    {results.todos.map((t) => (
                      <button
                        key={t.id}
                        onClick={() => go("/todo")}
                        className="w-full flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-muted transition-colors text-left"
                      >
                        <CheckSquare className={`w-4 h-4 shrink-0 ${t.completed ? "text-muted-foreground" : PRIORITY_COLOR[t.priority]}`} />
                        <div className="flex-1 min-w-0">
                          <p className={`text-sm font-medium truncate ${t.completed ? "line-through text-muted-foreground" : "text-foreground"}`}>
                            {t.title}
                          </p>
                          <p className="text-[11px] text-muted-foreground">{t.category} · {t.priority} priority</p>
                        </div>
                        <ArrowRight className="w-3.5 h-3.5 text-muted-foreground/40 shrink-0" />
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Events */}
              {results.events.length > 0 && (
                <div className="px-4 pt-4">
                  <p className="text-[11px] font-bold uppercase tracking-widest text-muted-foreground/50 mb-2 px-1">
                    Events
                  </p>
                  <div className="space-y-1">
                    {results.events.map((ev) => (
                      <button
                        key={ev.id}
                        onClick={() => go("/planner")}
                        className="w-full flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-muted transition-colors text-left"
                      >
                        <CalendarDays className="w-4 h-4 shrink-0 text-sky-500" />
                        <div className="flex-1 min-w-0">
                          <p className={`text-sm font-medium truncate ${ev.completed ? "line-through text-muted-foreground" : "text-foreground"}`}>
                            {ev.title}
                          </p>
                          <p className="text-[11px] text-muted-foreground">
                            {new Date(ev.date + "T00:00:00").toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" })}
                            {ev.time ? ` · ${ev.time}` : ""}
                          </p>
                        </div>
                        <ArrowRight className="w-3.5 h-3.5 text-muted-foreground/40 shrink-0" />
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Notes */}
              {results.notes.length > 0 && (
                <div className="px-4 pt-4">
                  <p className="text-[11px] font-bold uppercase tracking-widest text-muted-foreground/50 mb-2 px-1">
                    Notes
                  </p>
                  <div className="space-y-1">
                    {results.notes.map((n) => (
                      <button
                        key={n.id}
                        onClick={() => go("/notes")}
                        className="w-full flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-muted transition-colors text-left"
                      >
                        <StickyNote className="w-4 h-4 shrink-0 text-amber-500" />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate text-foreground">{n.title || "Untitled"}</p>
                          <p className="text-[11px] text-muted-foreground truncate">{n.body.slice(0, 60)}</p>
                        </div>
                        <ArrowRight className="w-3.5 h-3.5 text-muted-foreground/40 shrink-0" />
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {hasQuery && total > 0 && (
                <p className="text-[11px] text-muted-foreground/50 text-center mt-4">
                  {total} result{total !== 1 ? "s" : ""}
                </p>
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
