import { useState, useRef, useEffect, useCallback, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Sparkles, X, Send, Plus, StickyNote, CheckSquare,
  CalendarDays, ChevronDown, Loader2, Bot, Trash2,
  RotateCcw, CheckCheck, Tag, Palette, ListTodo,
} from "lucide-react";
import { useTodos } from "@/context/TodoContext";
import { usePlanner } from "@/context/PlannerContext";
import { useNotes, NoteColor } from "@/context/NotesContext";

// ─── Types ────────────────────────────────────────────────────────────────────
interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  actions?: ActionResult[];
  ts: number;
}

interface ActionResult {
  type: string;
  label: string;
  count: number;
  icon: "note" | "todo" | "event" | "delete" | "check" | "organize";
}

interface ApiAction {
  type: string;
  args: Record<string, unknown>;
}

// ─── Suggestion groups ────────────────────────────────────────────────────────
const SUGGESTIONS = [
  { label: "Plan my week",         prompt: "Create a balanced weekly schedule for me with work, exercise, and breaks", icon: "📅" },
  { label: "Morning routine",      prompt: "Set up a morning routine schedule starting at 6am", icon: "🌅" },
  { label: "Shopping list",        prompt: "Make a grocery shopping list as todos for a healthy week", icon: "🛒" },
  { label: "Organise my notes",    prompt: "Look at my existing notes and organise them by adding relevant tags and colours", icon: "🗂️" },
  { label: "Workout plan",         prompt: "Create a 5-day workout schedule in the planner with different muscle groups", icon: "💪" },
  { label: "Study schedule",       prompt: "Build a focused study schedule for this week with deep work sessions", icon: "📚" },
  { label: "Clear completed",      prompt: "Clear all my completed todos and tell me what's still pending", icon: "✅" },
  { label: "Project breakdown",    prompt: "Break my current top priority task into smaller actionable steps as todos", icon: "🎯" },
];

// ─── Action config ─────────────────────────────────────────────────────────────
const ACTION_CFG: Record<ActionResult["icon"], { bg: string; text: string; border: string }> = {
  note:     { bg: "bg-amber-50",   text: "text-amber-700",   border: "border-amber-200" },
  todo:     { bg: "bg-violet-50",  text: "text-violet-700",  border: "border-violet-200" },
  event:    { bg: "bg-sky-50",     text: "text-sky-700",     border: "border-sky-200" },
  delete:   { bg: "bg-rose-50",    text: "text-rose-600",    border: "border-rose-200" },
  check:    { bg: "bg-emerald-50", text: "text-emerald-700", border: "border-emerald-200" },
  organize: { bg: "bg-indigo-50",  text: "text-indigo-700",  border: "border-indigo-200" },
};

function ActionIcon({ icon }: { icon: ActionResult["icon"] }) {
  const cls = "w-3.5 h-3.5 shrink-0";
  if (icon === "note")     return <StickyNote   className={cls} />;
  if (icon === "todo")     return <CheckSquare  className={cls} />;
  if (icon === "event")    return <CalendarDays className={cls} />;
  if (icon === "delete")   return <Trash2       className={cls} />;
  if (icon === "check")    return <CheckCheck   className={cls} />;
  if (icon === "organize") return <Tag          className={cls} />;
  return <Sparkles className={cls} />;
}

// ─── Typing indicator ─────────────────────────────────────────────────────────
function TypingDots() {
  return (
    <div className="flex gap-2.5">
      <div className="w-7 h-7 rounded-full bg-gradient-to-br from-indigo-500 to-violet-500 flex items-center justify-center shrink-0 mt-0.5 shadow-sm">
        <Bot className="w-3.5 h-3.5 text-white" />
      </div>
      <div className="bg-card border border-border rounded-2xl rounded-tl-sm px-4 py-3 flex items-center gap-1.5">
        {[0, 1, 2].map((i) => (
          <motion.span
            key={i}
            className="w-1.5 h-1.5 rounded-full bg-muted-foreground/50"
            animate={{ y: [0, -4, 0] }}
            transition={{ duration: 0.7, repeat: Infinity, delay: i * 0.15 }}
          />
        ))}
      </div>
    </div>
  );
}

// ─── Markdown-lite renderer ───────────────────────────────────────────────────
function RichText({ text }: { text: string }) {
  const lines = text.split("\n");
  return (
    <div className="space-y-0.5">
      {lines.map((line, i) => {
        // Bold: **text**
        const parts = line.split(/(\*\*[^*]+\*\*)/g);
        const rendered = parts.map((p, j) =>
          p.startsWith("**") && p.endsWith("**")
            ? <strong key={j}>{p.slice(2, -2)}</strong>
            : <span key={j}>{p}</span>
        );
        // Bullet point
        if (line.startsWith("• ") || line.startsWith("- ")) {
          return (
            <div key={i} className="flex gap-1.5 items-start">
              <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-current shrink-0 opacity-50" />
              <span>{rendered.map((p) => typeof p === "string" ? p.slice(2) : p)}</span>
            </div>
          );
        }
        if (line === "") return <div key={i} className="h-1" />;
        return <p key={i}>{rendered}</p>;
      })}
    </div>
  );
}

// ─── Message bubble ───────────────────────────────────────────────────────────
function MessageBubble({ msg }: { msg: ChatMessage }) {
  const isUser = msg.role === "user";
  const time = new Date(msg.ts).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className={`flex gap-2.5 ${isUser ? "flex-row-reverse" : "flex-row"}`}
    >
      {!isUser && (
        <div className="w-7 h-7 rounded-full bg-gradient-to-br from-indigo-500 to-violet-500 flex items-center justify-center shrink-0 mt-0.5 shadow-sm">
          <Bot className="w-3.5 h-3.5 text-white" />
        </div>
      )}
      <div className={`flex flex-col gap-1.5 max-w-[82%] ${isUser ? "items-end" : "items-start"}`}>
        {msg.content && (
          <div className={`px-4 py-2.5 rounded-2xl text-sm leading-relaxed ${
            isUser
              ? "bg-indigo-600 text-white rounded-tr-sm"
              : "bg-card border border-border text-foreground rounded-tl-sm"
          }`}>
            {isUser ? msg.content : <RichText text={msg.content} />}
          </div>
        )}
        {/* Action cards */}
        {msg.actions && msg.actions.length > 0 && (
          <div className="flex flex-col gap-1.5 w-full">
            {msg.actions.map((a, i) => {
              const cfg = ACTION_CFG[a.icon];
              return (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -6 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.06 }}
                  className={`flex items-center gap-2 px-3 py-2 rounded-xl border text-xs font-semibold ${cfg.bg} ${cfg.text} ${cfg.border}`}
                >
                  <ActionIcon icon={a.icon} />
                  <span className="flex-1">{a.label}</span>
                  {a.count > 1 && (
                    <span className="font-bold opacity-70">×{a.count}</span>
                  )}
                </motion.div>
              );
            })}
          </div>
        )}
        <span className="text-[10px] text-muted-foreground/40 px-1">{time}</span>
      </div>
    </motion.div>
  );
}

// ─── Main component ───────────────────────────────────────────────────────────
export function AiCompanion() {
  const [open, setOpen]         = useState(false);
  const [input, setInput]       = useState("");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState<string | null>(null);
  const bottomRef               = useRef<HTMLDivElement>(null);
  const inputRef                = useRef<HTMLInputElement>(null);

  const { todos, addTodo, toggleTodo, deleteTodo, editTodo, clearCompleted } = useTodos();
  const { events, addEvent, deleteEvent, toggleEvent } = usePlanner();
  const { notes, addNote, updateNote, deleteNote } = useNotes();

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  useEffect(() => {
    if (open) setTimeout(() => inputRef.current?.focus(), 350);
  }, [open]);

  // ── Rich context snapshot ──────────────────────────────────────────────────
  const appContext = useMemo(() => ({
    todos: todos.map((t) => ({
      id: t.id,
      title: t.title,
      priority: t.priority,
      completed: t.completed,
      dueDate: t.dueDate,
      category: t.category,
    })),
    notes: notes.map((n) => ({
      id: n.id,
      title: n.title,
      color: n.color,
      tags: n.tags,
      pinned: n.pinned,
    })),
    events: events.map((e) => ({
      id: e.id,
      title: e.title,
      date: e.date,
      time: e.time,
      type: e.type,
      completed: e.completed,
    })),
  }), [todos, notes, events]);

  // ── Smart welcome stats ────────────────────────────────────────────────────
  const stats = useMemo(() => ({
    activeTodos:    todos.filter((t) => !t.completed).length,
    highPriority:   todos.filter((t) => !t.completed && t.priority === "high").length,
    totalNotes:     notes.length,
    upcomingEvents: events.filter((e) => !e.completed && e.date >= new Date().toISOString().split("T")[0]).length,
  }), [todos, notes, events]);

  // ── Execute AI actions ─────────────────────────────────────────────────────
  const executeActions = useCallback((apiActions: ApiAction[]): ActionResult[] => {
    const results: ActionResult[] = [];

    for (const action of apiActions) {
      const { type, args } = action;

      // ── Notes ──
      if (type === "create_note") {
        addNote({
          title:  String(args.title ?? ""),
          body:   String(args.body ?? ""),
          color:  (args.color as NoteColor) ?? "default",
          tags:   (args.tags as string[]) ?? [],
          pinned: Boolean(args.pinned ?? false),
        });
        results.push({ type, label: `Note created: "${args.title}"`, count: 1, icon: "note" });
      }

      else if (type === "create_multiple_notes") {
        const noteList = (args.notes as Array<Record<string, unknown>>) ?? [];
        noteList.forEach((n) => addNote({
          title:  String(n.title ?? ""),
          body:   String(n.body ?? ""),
          color:  (n.color as NoteColor) ?? "default",
          tags:   (n.tags as string[]) ?? [],
          pinned: Boolean(n.pinned ?? false),
        }));
        results.push({ type, label: `${noteList.length} note${noteList.length !== 1 ? "s" : ""} created`, count: noteList.length, icon: "note" });
      }

      else if (type === "update_note") {
        const id = String(args.id ?? "");
        const patch: Record<string, unknown> = {};
        if (args.title  !== undefined) patch.title  = args.title;
        if (args.body   !== undefined) patch.body   = args.body;
        if (args.color  !== undefined) patch.color  = args.color;
        if (args.tags   !== undefined) patch.tags   = args.tags;
        if (args.pinned !== undefined) patch.pinned = args.pinned;
        updateNote(id, patch);
        results.push({ type, label: `Note updated: "${args.title ?? id}"`, count: 1, icon: "note" });
      }

      else if (type === "delete_note") {
        deleteNote(String(args.id ?? ""));
        results.push({ type, label: `Note deleted: "${args.title ?? args.id}"`, count: 1, icon: "delete" });
      }

      else if (type === "organize_notes") {
        const patches = (args.patches as Array<Record<string, unknown>>) ?? [];
        patches.forEach((p) => {
          updateNote(String(p.id), {
            ...(p.tags  !== undefined ? { tags:  p.tags as string[] } : {}),
            ...(p.color !== undefined ? { color: p.color as NoteColor } : {}),
          });
        });
        const summary = args.summary ? String(args.summary) : `${patches.length} note${patches.length !== 1 ? "s" : ""} reorganised`;
        results.push({ type, label: summary, count: patches.length, icon: "organize" });
      }

      // ── Todos ──
      else if (type === "create_todo") {
        addTodo({
          title:      String(args.title ?? ""),
          priority:   (args.priority as "high" | "medium" | "low") ?? "medium",
          category:   String(args.category ?? ""),
          dueDate:    args.dueDate ? String(args.dueDate) : null,
          recurrence: "none",
        });
        results.push({ type, label: `Task added: "${args.title}"`, count: 1, icon: "todo" });
      }

      else if (type === "create_multiple_todos") {
        const todoList = (args.todos as Array<Record<string, unknown>>) ?? [];
        todoList.forEach((t) => addTodo({
          title:      String(t.title ?? ""),
          priority:   (t.priority as "high" | "medium" | "low") ?? "medium",
          category:   String(t.category ?? ""),
          dueDate:    t.dueDate ? String(t.dueDate) : null,
          recurrence: "none",
        }));
        results.push({ type, label: `${todoList.length} task${todoList.length !== 1 ? "s" : ""} added to your list`, count: todoList.length, icon: "todo" });
      }

      else if (type === "complete_todo") {
        const ids = (args.ids as string[]) ?? [];
        ids.forEach((id) => {
          const todo = todos.find((t) => t.id === id);
          if (todo && !todo.completed) toggleTodo(id);
        });
        results.push({ type, label: `${ids.length} task${ids.length !== 1 ? "s" : ""} marked complete`, count: ids.length, icon: "check" });
      }

      else if (type === "update_todo") {
        const id = String(args.id ?? "");
        const patch: Record<string, unknown> = {};
        if (args.title    !== undefined) patch.title    = args.title;
        if (args.priority !== undefined) patch.priority = args.priority;
        if (args.category !== undefined) patch.category = args.category;
        if (args.dueDate  !== undefined) patch.dueDate  = args.dueDate;
        editTodo(id, patch);
        results.push({ type, label: `Task updated: "${args.title ?? id}"`, count: 1, icon: "todo" });
      }

      else if (type === "delete_todo") {
        deleteTodo(String(args.id ?? ""));
        results.push({ type, label: `Task deleted: "${args.title ?? args.id}"`, count: 1, icon: "delete" });
      }

      else if (type === "clear_completed_todos") {
        const completedCount = todos.filter((t) => t.completed).length;
        clearCompleted();
        results.push({ type, label: `${completedCount} completed task${completedCount !== 1 ? "s" : ""} cleared`, count: completedCount, icon: "check" });
      }

      // ── Events ──
      else if (type === "create_event") {
        addEvent({
          title:      String(args.title ?? ""),
          type:       (args.type as "event" | "task") ?? "event",
          date:       String(args.date ?? new Date().toISOString().split("T")[0]),
          time:       args.time ? String(args.time) : null,
          color:      (args.color as "sky" | "violet" | "rose" | "emerald" | "amber" | "orange") ?? "sky",
          notes:      args.notes ? String(args.notes) : null,
          recurrence: "none",
        });
        results.push({ type, label: `Event added: "${args.title}"`, count: 1, icon: "event" });
      }

      else if (type === "create_schedule") {
        const evList = (args.events as Array<Record<string, unknown>>) ?? [];
        evList.forEach((e) => addEvent({
          title:      String(e.title ?? ""),
          type:       (e.type as "event" | "task") ?? "event",
          date:       String(e.date ?? new Date().toISOString().split("T")[0]),
          time:       e.time ? String(e.time) : null,
          color:      (e.color as "sky" | "violet" | "rose" | "emerald" | "amber" | "orange") ?? "sky",
          notes:      e.notes ? String(e.notes) : null,
          recurrence: "none",
        }));
        results.push({ type, label: `Schedule created — ${evList.length} event${evList.length !== 1 ? "s" : ""} added to Planner`, count: evList.length, icon: "event" });
      }

      else if (type === "complete_event") {
        toggleEvent(String(args.id ?? ""));
        results.push({ type, label: `Event marked done: "${args.title ?? args.id}"`, count: 1, icon: "check" });
      }

      else if (type === "delete_event") {
        deleteEvent(String(args.id ?? ""));
        results.push({ type, label: `Event removed: "${args.title ?? args.id}"`, count: 1, icon: "delete" });
      }
    }

    return results;
  }, [todos, addTodo, toggleTodo, deleteTodo, editTodo, clearCompleted, events, addEvent, deleteEvent, toggleEvent, notes, addNote, updateNote, deleteNote]);

  // ── Send message ───────────────────────────────────────────────────────────
  async function send(text: string = input.trim()) {
    if (!text || loading) return;
    setInput("");
    setError(null);

    const userMsg: ChatMessage = {
      id: crypto.randomUUID(),
      role: "user",
      content: text,
      ts: Date.now(),
    };
    const nextMessages = [...messages, userMsg];
    setMessages(nextMessages);
    setLoading(true);

    try {
      const apiMessages = nextMessages.map((m) => ({ role: m.role, content: m.content }));

      const res = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: apiMessages, appContext }),
      });

      if (!res.ok) throw new Error((await res.json() as { error?: string }).error ?? "Request failed");
      const data = await res.json() as { reply: string; actions: ApiAction[] };

      const actionResults = executeActions(data.actions ?? []);
      setMessages((prev) => [
        ...prev,
        {
          id: crypto.randomUUID(),
          role: "assistant",
          content: data.reply,
          actions: actionResults,
          ts: Date.now(),
        },
      ]);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  function clearChat() {
    setMessages([]);
    setError(null);
  }

  const isEmpty = messages.length === 0;

  return (
    <>
      {/* ── Floating button ── */}
      <motion.button
        onClick={() => setOpen(true)}
        whileTap={{ scale: 0.88 }}
        data-testid="button-open-ai"
        className="fixed bottom-[88px] right-4 z-40 w-14 h-14 rounded-full bg-gradient-to-br from-indigo-500 to-violet-600 shadow-2xl shadow-indigo-300/50 flex items-center justify-center"
      >
        <Sparkles className="w-6 h-6 text-white" />
        <span className="absolute inset-0 rounded-full animate-ping bg-indigo-400/25 pointer-events-none" />
      </motion.button>

      {/* ── Chat panel ── */}
      <AnimatePresence>
        {open && (
          <>
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/40 z-40"
              onClick={() => setOpen(false)}
            />

            <motion.div
              initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }}
              transition={{ type: "spring", stiffness: 300, damping: 32 }}
              className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[430px] bg-background rounded-t-3xl z-50 shadow-2xl flex flex-col overflow-hidden"
            style={{ height: "88dvh", maxHeight: "88dvh" }}
            >
              {/* ── Header ── */}
              <div className="px-5 pt-5 pb-4 bg-gradient-to-br from-indigo-600 via-indigo-600 to-violet-600 flex items-center justify-between shrink-0">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-white/15 flex items-center justify-center">
                    <Sparkles className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h2 className="text-white font-bold text-base leading-none">AI Companion</h2>
                    <p className="text-white/60 text-[11px] mt-0.5">
                      {stats.activeTodos} tasks · {stats.totalNotes} notes · {stats.upcomingEvents} upcoming
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {messages.length > 0 && (
                    <button
                      onClick={clearChat}
                      className="w-8 h-8 rounded-full bg-white/15 flex items-center justify-center"
                      title="Clear conversation"
                    >
                      <RotateCcw className="w-3.5 h-3.5 text-white" />
                    </button>
                  )}
                  <button
                    onClick={() => setOpen(false)}
                    className="w-8 h-8 rounded-full bg-white/15 flex items-center justify-center"
                  >
                    <ChevronDown className="w-5 h-5 text-white" />
                  </button>
                </div>
              </div>

              {/* ── Messages ── */}
              <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3">

                {/* Welcome / empty state */}
                {isEmpty && (
                  <motion.div
                    initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
                    className="flex flex-col items-center text-center pt-4 pb-2 gap-5"
                  >
                    <div className="w-16 h-16 rounded-3xl bg-gradient-to-br from-indigo-100 to-violet-100 flex items-center justify-center shadow-inner">
                      <Sparkles className="w-8 h-8 text-indigo-500" />
                    </div>
                    <div>
                      <p className="font-bold text-foreground text-lg">Hey! I'm your AI assistant 👋</p>
                      <p className="text-sm text-muted-foreground mt-1.5 leading-relaxed max-w-[260px]">
                        I can create, update, and organise your notes, tasks, and calendar — just tell me what you need.
                      </p>
                    </div>

                    {/* Current data pills */}
                    <div className="flex gap-2 flex-wrap justify-center">
                      {[
                        { icon: <ListTodo className="w-3 h-3" />, label: `${stats.activeTodos} active tasks`, color: "bg-violet-50 text-violet-700 border-violet-200" },
                        { icon: <StickyNote className="w-3 h-3" />, label: `${stats.totalNotes} notes`, color: "bg-amber-50 text-amber-700 border-amber-200" },
                        { icon: <CalendarDays className="w-3 h-3" />, label: `${stats.upcomingEvents} events`, color: "bg-sky-50 text-sky-700 border-sky-200" },
                      ].map((p) => (
                        <span key={p.label} className={`flex items-center gap-1.5 px-3 py-1 rounded-full border text-xs font-semibold ${p.color}`}>
                          {p.icon}{p.label}
                        </span>
                      ))}
                    </div>

                    {/* Centred input */}
                    <div className="w-full">
                      <div className="flex items-center gap-2 bg-background border-2 border-indigo-200 focus-within:border-indigo-500 rounded-2xl px-4 py-3 shadow-sm transition-colors">
                        <input
                          value={input}
                          onChange={(e) => setInput(e.target.value)}
                          onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && send()}
                          placeholder="What would you like to do?"
                          className="flex-1 bg-transparent text-sm focus:outline-none placeholder:text-muted-foreground/60 text-foreground"
                          disabled={loading}
                          autoComplete="off"
                          autoCorrect="off"
                          spellCheck={false}
                        />
                        <motion.button
                          onClick={() => send()}
                          disabled={!input.trim() || loading}
                          whileTap={{ scale: 0.88 }}
                          className="w-8 h-8 rounded-full bg-indigo-600 flex items-center justify-center text-white disabled:opacity-30 disabled:bg-muted-foreground transition-all shrink-0"
                        >
                          {loading
                            ? <Loader2 className="w-3.5 h-3.5 animate-spin" />
                            : <Send className="w-3.5 h-3.5" />
                          }
                        </motion.button>
                      </div>
                    </div>

                    {/* Suggestion chips */}
                    <div className="w-full">
                      <p className="text-[11px] text-muted-foreground font-medium mb-2">Try asking:</p>
                      <div className="flex flex-wrap gap-2">
                        {SUGGESTIONS.map((s) => (
                          <button
                            key={s.label}
                            onClick={() => send(s.prompt)}
                            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-muted border border-border text-xs font-medium text-foreground hover:bg-indigo-50 hover:border-indigo-200 hover:text-indigo-700 transition-colors"
                          >
                            <span>{s.icon}</span>
                            {s.label}
                          </button>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                )}

                {/* Message list */}
                {messages.map((msg) => (
                  <MessageBubble key={msg.id} msg={msg} />
                ))}

                {/* Typing indicator */}
                {loading && (
                  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                    <TypingDots />
                  </motion.div>
                )}

                {/* Error */}
                {error && (
                  <motion.div
                    initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                    className="text-xs text-rose-600 bg-rose-50 border border-rose-200 rounded-2xl px-4 py-3 leading-relaxed"
                  >
                    <strong>Error:</strong> {error}
                  </motion.div>
                )}

                <div ref={bottomRef} />
              </div>

              {/* ── Quick-action bar (shown mid-conversation too) ── */}
              <div className="px-4 pb-2 flex gap-2 overflow-x-auto scrollbar-hide shrink-0">
                {[
                  { label: "New note",   icon: <StickyNote  className="w-3.5 h-3.5" />, prompt: "Create a blank note I can use for ideas" },
                  { label: "Add tasks",  icon: <CheckSquare className="w-3.5 h-3.5" />, prompt: "Add 3 productivity tasks to my todo list" },
                  { label: "Plan week",  icon: <CalendarDays className="w-3.5 h-3.5" />, prompt: "Create a balanced weekly schedule with work, exercise and breaks" },
                  { label: "Organise",   icon: <Palette     className="w-3.5 h-3.5" />, prompt: "Look at my notes and organise them by colour and tags" },
                  { label: "Custom",     icon: <Plus        className="w-3.5 h-3.5" />, prompt: "" },
                ].map((q) => (
                  <button
                    key={q.label}
                    onClick={() => q.prompt ? send(q.prompt) : inputRef.current?.focus()}
                    className="shrink-0 flex items-center gap-1.5 px-3 py-2 rounded-xl bg-muted border border-border text-xs font-medium text-foreground hover:bg-muted/60 transition-colors"
                  >
                    {q.icon}{q.label}
                  </button>
                ))}
              </div>

              {/* ── Input bar ── */}
              <div className="px-4 py-3 border-t-2 border-border bg-background shrink-0">
                <div className="flex items-center gap-3 bg-muted border border-border rounded-2xl px-4 h-13 min-h-[52px] shadow-sm">
                  <input
                    ref={inputRef}
                    data-testid="input-ai-message"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && send()}
                    placeholder="Ask me anything…"
                    className="flex-1 bg-transparent text-sm focus:outline-none placeholder:text-muted-foreground/60 text-foreground"
                    disabled={loading}
                    autoComplete="off"
                    autoCorrect="off"
                    spellCheck={false}
                  />
                  <motion.button
                    data-testid="button-send-ai"
                    onClick={() => send()}
                    disabled={!input.trim() || loading}
                    whileTap={{ scale: 0.88 }}
                    className="w-9 h-9 rounded-full bg-indigo-600 flex items-center justify-center text-white disabled:opacity-30 disabled:bg-muted-foreground transition-all shrink-0 shadow-md"
                  >
                    {loading
                      ? <Loader2 className="w-4 h-4 animate-spin" />
                      : <Send className="w-4 h-4" />
                    }
                  </motion.button>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
