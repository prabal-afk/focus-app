import { motion, AnimatePresence } from "framer-motion";
import {
  Bell, X, CheckCheck, Trash2,
  CheckSquare, CalendarDays, Timer, Sparkles, Info, AlertCircle,
} from "lucide-react";
import { useNotifications, AppNotification, NotifType } from "@/context/NotificationsContext";

// ─── Config ───────────────────────────────────────────────────────────────────
const TYPE_CFG: Record<NotifType, {
  icon: React.ElementType;
  bg: string;
  iconColor: string;
  label: string;
}> = {
  task_complete: { icon: CheckSquare, bg: "bg-emerald-100", iconColor: "text-emerald-600", label: "Task"    },
  due_today:     { icon: AlertCircle, bg: "bg-rose-100",    iconColor: "text-rose-600",    label: "Due Today" },
  due_soon:      { icon: CalendarDays, bg: "bg-amber-100",  iconColor: "text-amber-600",   label: "Upcoming"  },
  timer_done:    { icon: Timer,        bg: "bg-violet-100", iconColor: "text-violet-600",  label: "Timer"    },
  ai:            { icon: Sparkles,     bg: "bg-indigo-100", iconColor: "text-indigo-600",  label: "AI"       },
  info:          { icon: Info,         bg: "bg-sky-100",    iconColor: "text-sky-600",     label: "Info"     },
};

function timeAgo(ts: number) {
  const diff = Date.now() - ts;
  const min  = Math.floor(diff / 60000);
  if (min < 1)  return "just now";
  if (min < 60) return `${min}m ago`;
  const h = Math.floor(min / 60);
  if (h < 24)   return `${h}h ago`;
  const d = Math.floor(h / 24);
  return d === 1 ? "yesterday" : `${d}d ago`;
}

function groupByDay(notifications: AppNotification[]) {
  const today = new Date(); today.setHours(0,0,0,0);
  const yesterday = new Date(today); yesterday.setDate(yesterday.getDate() - 1);

  const groups: { label: string; items: AppNotification[] }[] = [];
  const todayItems     = notifications.filter((n) => n.ts >= today.getTime());
  const yesterdayItems = notifications.filter((n) => n.ts >= yesterday.getTime() && n.ts < today.getTime());
  const olderItems     = notifications.filter((n) => n.ts < yesterday.getTime());

  if (todayItems.length)     groups.push({ label: "Today",     items: todayItems });
  if (yesterdayItems.length) groups.push({ label: "Yesterday", items: yesterdayItems });
  if (olderItems.length)     groups.push({ label: "Earlier",   items: olderItems });
  return groups;
}

// ─── NotifRow ─────────────────────────────────────────────────────────────────
function NotifRow({ notif, onRead }: { notif: AppNotification; onRead: () => void }) {
  const cfg = TYPE_CFG[notif.type];
  return (
    <motion.div
      layout
      initial={{ opacity: 0, x: -8 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 8 }}
      onClick={onRead}
      className={`flex gap-3 px-5 py-3.5 cursor-pointer transition-colors active:bg-muted/60 ${notif.read ? "opacity-60" : ""}`}
    >
      <div className={`w-9 h-9 rounded-xl ${cfg.bg} flex items-center justify-center shrink-0 mt-0.5`}>
        <cfg.icon className={`w-4.5 h-4.5 ${cfg.iconColor}`} strokeWidth={2} />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-start justify-between gap-2">
          <p className={`text-sm leading-snug ${notif.read ? "text-foreground/70" : "text-foreground font-semibold"}`}>
            {notif.title}
          </p>
          {!notif.read && (
            <span className="w-2 h-2 rounded-full bg-indigo-500 shrink-0 mt-1.5" />
          )}
        </div>
        {notif.body && (
          <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed line-clamp-2">{notif.body}</p>
        )}
        <p className="text-[10px] text-muted-foreground/50 mt-1">{timeAgo(notif.ts)}</p>
      </div>
    </motion.div>
  );
}

// ─── Main panel ───────────────────────────────────────────────────────────────
export function NotificationsPanel({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { notifications, unreadCount, markRead, markAllRead, clearAll, browserPermission, requestPermission } = useNotifications();
  const groups = groupByDay(notifications);

  return (
    <AnimatePresence>
      {open && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black/30 z-20"
            onClick={onClose}
          />

          {/* Panel slides down from top */}
          <motion.div
            initial={{ y: "-100%", opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: "-100%", opacity: 0 }}
            transition={{ type: "spring", stiffness: 320, damping: 32 }}
            className="absolute top-0 left-0 right-0 bg-background rounded-b-3xl z-30 shadow-2xl flex flex-col max-h-[78%]"
          >
            {/* Header */}
            <div className="px-5 pt-12 pb-4 border-b border-border flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 bg-indigo-100 rounded-xl flex items-center justify-center">
                  <Bell className="w-5 h-5 text-indigo-600" />
                </div>
                <div>
                  <h2 className="text-lg font-bold leading-none">Notifications</h2>
                  {unreadCount > 0 && (
                    <p className="text-xs text-muted-foreground mt-0.5">{unreadCount} unread</p>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-2">
                {unreadCount > 0 && (
                  <button
                    onClick={markAllRead}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold bg-muted text-muted-foreground hover:bg-indigo-50 hover:text-indigo-700 transition-colors"
                  >
                    <CheckCheck className="w-3.5 h-3.5" />
                    Mark all read
                  </button>
                )}
                {notifications.length > 0 && (
                  <button
                    onClick={clearAll}
                    className="w-8 h-8 rounded-full bg-muted flex items-center justify-center text-muted-foreground hover:bg-rose-50 hover:text-rose-500 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
                <button
                  onClick={onClose}
                  className="w-8 h-8 rounded-full bg-muted flex items-center justify-center text-muted-foreground"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Browser permission banner */}
            {browserPermission === "default" && (
              <motion.div
                initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }}
                className="mx-4 mt-3 px-4 py-3 bg-indigo-50 border border-indigo-200 rounded-2xl flex items-center justify-between gap-3"
              >
                <div className="flex-1">
                  <p className="text-xs font-semibold text-indigo-800">Enable system notifications</p>
                  <p className="text-[11px] text-indigo-600 mt-0.5">Get alerts even when the app is in the background.</p>
                </div>
                <button
                  onClick={requestPermission}
                  className="shrink-0 px-3 py-1.5 rounded-full bg-indigo-600 text-white text-xs font-bold"
                >
                  Allow
                </button>
              </motion.div>
            )}

            {/* Content */}
            <div className="flex-1 overflow-y-auto pb-4">
              {notifications.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-14 gap-3 text-center">
                  <div className="w-14 h-14 bg-muted rounded-3xl flex items-center justify-center">
                    <Bell className="w-7 h-7 text-muted-foreground/30" strokeWidth={1.5} />
                  </div>
                  <div>
                    <p className="font-semibold text-foreground">All caught up!</p>
                    <p className="text-sm text-muted-foreground mt-1">No notifications yet.</p>
                  </div>
                </div>
              ) : (
                <AnimatePresence>
                  {groups.map((group) => (
                    <div key={group.label}>
                      <p className="px-5 pt-4 pb-1.5 text-[11px] font-bold uppercase tracking-widest text-muted-foreground/50">
                        {group.label}
                      </p>
                      {group.items.map((n) => (
                        <NotifRow key={n.id} notif={n} onRead={() => markRead(n.id)} />
                      ))}
                    </div>
                  ))}
                </AnimatePresence>
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
