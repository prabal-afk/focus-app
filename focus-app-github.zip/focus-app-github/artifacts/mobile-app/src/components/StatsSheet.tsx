import { useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, CheckSquare, StickyNote, CalendarDays, TrendingUp, Flame } from "lucide-react";
import { useTodos } from "@/context/TodoContext";
import { usePlanner } from "@/context/PlannerContext";
import { useNotes } from "@/context/NotesContext";

interface StatsSheetProps {
  open: boolean;
  onClose: () => void;
}

function dayStr(offset: number): string {
  const d = new Date();
  d.setDate(d.getDate() + offset);
  return d.toISOString().split("T")[0];
}

const DAY_LABELS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

export function StatsSheet({ open, onClose }: StatsSheetProps) {
  const { todos }  = useTodos();
  const { events } = usePlanner();
  const { notes }  = useNotes();

  const stats = useMemo(() => {
    const now = Date.now();
    const weekStart = now - 7 * 24 * 3600 * 1000;

    const completedTotal = todos.filter((t) => t.completed).length;
    const activeTotal    = todos.filter((t) => !t.completed).length;
    const totalTodos     = todos.length;
    const completionRate = totalTodos > 0 ? Math.round((completedTotal / totalTodos) * 100) : 0;

    const completedThisWeek = todos.filter(
      (t) => t.completed && t.completedAt && t.completedAt >= weekStart
    ).length;

    const notesThisWeek = notes.filter((n) => n.createdAt >= weekStart).length;

    const todayStr = dayStr(0);
    const weekStart7 = dayStr(-6);
    const eventsThisWeek = events.filter((e) => e.date >= weekStart7 && e.date <= todayStr).length;

    const chartDays = Array.from({ length: 7 }, (_, i) => {
      const d = dayStr(i - 6);
      const dateObj = new Date(d + "T00:00:00");
      const label = DAY_LABELS[dateObj.getDay()];
      const count = todos.filter(
        (t) => t.completed && t.completedAt &&
          new Date(t.completedAt).toISOString().split("T")[0] === d
      ).length;
      return { d, label, count, isToday: d === todayStr };
    });

    const maxBar = Math.max(...chartDays.map((c) => c.count), 1);

    const categoryMap: Record<string, number> = {};
    todos.filter((t) => t.completed).forEach((t) => {
      categoryMap[t.category] = (categoryMap[t.category] ?? 0) + 1;
    });
    const topCategory = Object.entries(categoryMap).sort((a, b) => b[1] - a[1])[0];

    const streak = (() => {
      let s = 0;
      for (let i = 0; i >= -30; i--) {
        const d = dayStr(i);
        const hadActivity = todos.some(
          (t) => t.completedAt && new Date(t.completedAt).toISOString().split("T")[0] === d
        ) || notes.some((n) => new Date(n.createdAt).toISOString().split("T")[0] === d);
        if (hadActivity) s++;
        else if (i < 0) break;
      }
      return s;
    })();

    return {
      completedTotal, activeTotal, totalTodos, completionRate,
      completedThisWeek, notesThisWeek, eventsThisWeek,
      chartDays, maxBar, topCategory, streak,
    };
  }, [todos, events, notes]);

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black/40 z-30"
            onClick={onClose}
          />

          <motion.div
            initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }}
            transition={{ type: "spring", stiffness: 300, damping: 32 }}
            className="absolute bottom-0 left-0 right-0 z-40 bg-background rounded-t-3xl flex flex-col overflow-hidden"
            style={{ maxHeight: "80dvh" }}
          >
            {/* Handle */}
            <div className="flex justify-center pt-3 pb-1 shrink-0">
              <div className="w-10 h-1 rounded-full bg-border" />
            </div>

            {/* Header */}
            <div className="flex items-center justify-between px-5 pt-2 pb-4 shrink-0">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-indigo-500" />
                <h2 className="text-lg font-bold text-foreground">Your Stats</h2>
              </div>
              <button
                onClick={onClose}
                className="w-8 h-8 rounded-full bg-muted flex items-center justify-center"
              >
                <X className="w-4 h-4 text-muted-foreground" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto px-5 pb-8 space-y-5">

              {/* Summary cards */}
              <div className="grid grid-cols-3 gap-3">
                <StatCard
                  icon={<CheckSquare className="w-4 h-4 text-violet-600" />}
                  bg="bg-violet-50"
                  label="Completed"
                  value={String(stats.completedTotal)}
                  sub={`${stats.completionRate}% rate`}
                />
                <StatCard
                  icon={<StickyNote className="w-4 h-4 text-amber-600" />}
                  bg="bg-amber-50"
                  label="Notes"
                  value={String(notes.length)}
                  sub={`${stats.notesThisWeek} this week`}
                />
                <StatCard
                  icon={<CalendarDays className="w-4 h-4 text-sky-600" />}
                  bg="bg-sky-50"
                  label="Events"
                  value={String(events.length)}
                  sub={`${stats.eventsThisWeek} this week`}
                />
              </div>

              {/* Streak */}
              <div className="flex items-center gap-3 p-4 rounded-2xl bg-gradient-to-r from-orange-50 to-amber-50 border border-orange-100">
                <div className="w-10 h-10 rounded-2xl bg-orange-100 flex items-center justify-center shrink-0">
                  <Flame className="w-5 h-5 text-orange-500" />
                </div>
                <div>
                  <p className="font-bold text-foreground text-base">{stats.streak} day streak</p>
                  <p className="text-xs text-muted-foreground">
                    {stats.streak === 0
                      ? "Complete a task or add a note to start your streak"
                      : stats.streak === 1
                      ? "Great start! Keep going tomorrow"
                      : `You've been productive ${stats.streak} days in a row 🔥`}
                  </p>
                </div>
              </div>

              {/* 7-day bar chart */}
              <div>
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest mb-3">
                  Tasks completed — last 7 days
                </p>
                <div className="flex items-end gap-2 h-24">
                  {stats.chartDays.map(({ d, label, count, isToday }) => {
                    const pct = count / stats.maxBar;
                    const minH = count > 0 ? 8 : 4;
                    return (
                      <div key={d} className="flex-1 flex flex-col items-center gap-1.5">
                        <span className="text-[10px] text-muted-foreground font-medium">
                          {count > 0 ? count : ""}
                        </span>
                        <div className="w-full flex items-end justify-center" style={{ height: 56 }}>
                          <motion.div
                            initial={{ height: 0 }}
                            animate={{ height: Math.max(minH, Math.round(pct * 56)) }}
                            transition={{ duration: 0.5, ease: "easeOut", delay: 0.05 }}
                            className={`w-full rounded-t-lg ${
                              isToday
                                ? "bg-indigo-500"
                                : count > 0
                                ? "bg-indigo-200"
                                : "bg-border"
                            }`}
                          />
                        </div>
                        <span className={`text-[10px] ${isToday ? "font-bold text-indigo-600" : "text-muted-foreground"}`}>
                          {label}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* This week summary */}
              <div className="bg-muted rounded-2xl p-4 space-y-3">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">This week</p>
                <div className="space-y-2">
                  <SummaryRow label="Tasks completed" value={stats.completedThisWeek} color="text-violet-600" />
                  <SummaryRow label="Notes created"   value={stats.notesThisWeek}    color="text-amber-600" />
                  <SummaryRow label="Events planned"  value={stats.eventsThisWeek}   color="text-sky-600" />
                  {stats.activeTotal > 0 && (
                    <SummaryRow label="Active tasks remaining" value={stats.activeTotal} color="text-rose-500" />
                  )}
                  {stats.topCategory && (
                    <SummaryRow label={`Top category: ${stats.topCategory[0]}`} value={stats.topCategory[1]} color="text-emerald-600" />
                  )}
                </div>
              </div>

            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

function StatCard({ icon, bg, label, value, sub }: { icon: React.ReactNode; bg: string; label: string; value: string; sub: string }) {
  return (
    <div className="flex flex-col gap-2 p-3 rounded-2xl bg-card border border-border">
      <div className={`w-7 h-7 rounded-xl ${bg} flex items-center justify-center`}>{icon}</div>
      <p className="text-xl font-bold text-foreground leading-none">{value}</p>
      <div>
        <p className="text-[11px] font-semibold text-foreground">{label}</p>
        <p className="text-[10px] text-muted-foreground">{sub}</p>
      </div>
    </div>
  );
}

function SummaryRow({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div className="flex items-center justify-between">
      <p className="text-sm text-foreground">{label}</p>
      <p className={`text-sm font-bold ${color}`}>{value}</p>
    </div>
  );
}
