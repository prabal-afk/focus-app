import { Link, useLocation } from "wouter";
import { LayoutDashboard, CheckSquare, CalendarDays, StickyNote, Timer } from "lucide-react";
import { motion } from "framer-motion";

const navItems = [
  { href: "/", icon: LayoutDashboard, label: "Home" },
  { href: "/todo", icon: CheckSquare, label: "ToDo" },
  { href: "/planner", icon: CalendarDays, label: "Planner" },
  { href: "/notes", icon: StickyNote, label: "Notes" },
  { href: "/timer", icon: Timer, label: "Timer" },
];

export function BottomNav() {
  const [location] = useLocation();

  return (
    <div className="absolute bottom-0 left-0 right-0 h-16 bg-card border-t border-border z-50 px-1">
      <div className="flex items-center justify-around h-full">
        {navItems.map((item) => {
          const isActive = location === item.href;
          const Icon = item.icon;

          return (
            <Link
              key={item.href}
              href={item.href}
              className="relative flex flex-col items-center justify-center flex-1 h-full text-xs font-medium gap-1"
              data-testid={`nav-${item.label.toLowerCase()}`}
            >
              <div className="relative flex items-center justify-center">
                {isActive && (
                  <motion.div
                    layoutId="bottom-nav-indicator"
                    className="absolute -inset-2 bg-primary/10 rounded-full -z-10"
                    transition={{ type: "spring", stiffness: 300, damping: 30 }}
                  />
                )}
                <Icon
                  size={22}
                  className={`transition-colors duration-200 ${
                    isActive ? "text-primary" : "text-muted-foreground"
                  }`}
                  strokeWidth={isActive ? 2.5 : 2}
                />
              </div>
              <span
                className={`transition-colors duration-200 text-[10px] ${
                  isActive ? "text-primary font-semibold" : "text-muted-foreground"
                }`}
              >
                {item.label}
              </span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
