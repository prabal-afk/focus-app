import { createContext, useContext, useState, useEffect, useCallback } from "react";
import { Recurrence } from "./TodoContext";

export type EventType = "event" | "task";
export type EventColor = "sky" | "violet" | "rose" | "emerald" | "amber" | "orange";

export interface PlannerEvent {
  id: string;
  title: string;
  type: EventType;
  date: string;      // YYYY-MM-DD
  time: string | null;
  color: EventColor;
  notes: string | null;
  completed: boolean;
  createdAt: number;
  recurrence: Recurrence;
}

interface PlannerContextValue {
  events: PlannerEvent[];
  addEvent: (data: Omit<PlannerEvent, "id" | "createdAt" | "completed">) => void;
  deleteEvent: (id: string) => void;
  toggleEvent: (id: string) => void;
  editEvent: (id: string, data: Partial<Omit<PlannerEvent, "id" | "createdAt">>) => void;
  getEventsForDate: (date: string) => PlannerEvent[];
  getUpcomingEvents: (limit?: number) => PlannerEvent[];
}

const PlannerContext = createContext<PlannerContextValue | null>(null);

const STORAGE_KEY = "planner_events_v2";
const fmt = (d: Date) => d.toISOString().split("T")[0];

function nextDateStr(dateStr: string, recurrence: Recurrence): string {
  const d = new Date(dateStr + "T00:00:00");
  if (recurrence === "daily")   d.setDate(d.getDate() + 1);
  if (recurrence === "weekly")  d.setDate(d.getDate() + 7);
  if (recurrence === "monthly") d.setMonth(d.getMonth() + 1);
  return d.toISOString().split("T")[0];
}

export function PlannerProvider({ children }: { children: React.ReactNode }) {
  const [events, setEvents] = useState<PlannerEvent[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as PlannerEvent[];
        return parsed.map((e) => ({ ...e, recurrence: e.recurrence ?? "none" }));
      }
    } catch {}
    return [];
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(events));
  }, [events]);

  const addEvent = useCallback((data: Omit<PlannerEvent, "id" | "createdAt" | "completed">) => {
    setEvents((prev) => [
      { ...data, id: crypto.randomUUID(), completed: false, createdAt: Date.now() },
      ...prev,
    ]);
  }, []);

  const deleteEvent = useCallback((id: string) => {
    setEvents((prev) => prev.filter((e) => e.id !== id));
  }, []);

  const toggleEvent = useCallback((id: string) => {
    setEvents((prev) => {
      const ev = prev.find((e) => e.id === id);
      const completing = ev && !ev.completed;

      const next = prev.map((e) =>
        e.id === id ? { ...e, completed: !e.completed } : e
      );

      if (completing && ev && ev.recurrence !== "none") {
        const nextEv: PlannerEvent = {
          ...ev,
          id: crypto.randomUUID(),
          completed: false,
          createdAt: Date.now(),
          date: nextDateStr(ev.date, ev.recurrence),
        };
        return [...next, nextEv];
      }
      return next;
    });
  }, []);

  const editEvent = useCallback(
    (id: string, data: Partial<Omit<PlannerEvent, "id" | "createdAt">>) => {
      setEvents((prev) => prev.map((e) => (e.id === id ? { ...e, ...data } : e)));
    },
    []
  );

  const getEventsForDate = useCallback(
    (date: string) =>
      events
        .filter((e) => e.date === date)
        .sort((a, b) => (a.time ?? "99:99").localeCompare(b.time ?? "99:99")),
    [events]
  );

  const getUpcomingEvents = useCallback(
    (limit = 4) => {
      const todayStr = fmt(new Date());
      return events
        .filter((e) => e.date >= todayStr && !e.completed)
        .sort((a, b) => {
          const d = a.date.localeCompare(b.date);
          if (d !== 0) return d;
          return (a.time ?? "99:99").localeCompare(b.time ?? "99:99");
        })
        .slice(0, limit);
    },
    [events]
  );

  return (
    <PlannerContext.Provider
      value={{ events, addEvent, deleteEvent, toggleEvent, editEvent, getEventsForDate, getUpcomingEvents }}
    >
      {children}
    </PlannerContext.Provider>
  );
}

const NOOP = () => {};
const FALLBACK: PlannerContextValue = {
  events: [],
  addEvent: NOOP,
  deleteEvent: NOOP,
  toggleEvent: NOOP,
  editEvent: NOOP,
  getEventsForDate: () => [],
  getUpcomingEvents: () => [],
};

export function usePlanner() {
  return useContext(PlannerContext) ?? FALLBACK;
}
