import { createContext, useContext, useState, useCallback, useEffect, ReactNode } from "react";

export type NotifType = "task_complete" | "due_today" | "due_soon" | "timer_done" | "ai" | "info";

export interface AppNotification {
  id: string;
  type: NotifType;
  title: string;
  body: string;
  ts: number;
  read: boolean;
}

interface NotificationsContextValue {
  notifications: AppNotification[];
  unreadCount: number;
  addNotification: (n: Omit<AppNotification, "id" | "ts" | "read">) => void;
  fireNotification: (n: Omit<AppNotification, "id" | "ts" | "read">) => void;
  markRead: (id: string) => void;
  markAllRead: () => void;
  clearAll: () => void;
  requestPermission: () => void;
  browserPermission: NotificationPermission;
}

const NotificationsContext = createContext<NotificationsContextValue | null>(null);
const STORAGE_KEY = "app_notifications_v2";
const MAX_STORED = 60;

export function NotificationsProvider({ children }: { children: ReactNode }) {
  const [notifications, setNotifications] = useState<AppNotification[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch { return []; }
  });

  const [browserPermission, setBrowserPermission] = useState<NotificationPermission>(
    () => ("Notification" in window ? Notification.permission : "denied")
  );

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(notifications.slice(0, MAX_STORED)));
  }, [notifications]);

  const addNotification = useCallback((n: Omit<AppNotification, "id" | "ts" | "read">) => {
    const notif: AppNotification = {
      ...n,
      id: crypto.randomUUID(),
      ts: Date.now(),
      read: false,
    };
    setNotifications((prev) => [notif, ...prev].slice(0, MAX_STORED));
  }, []);

  const fireNotification = useCallback((n: Omit<AppNotification, "id" | "ts" | "read">) => {
    // In-app notification
    const notif: AppNotification = {
      ...n,
      id: crypto.randomUUID(),
      ts: Date.now(),
      read: false,
    };
    setNotifications((prev) => [notif, ...prev].slice(0, MAX_STORED));

    // Browser notification
    if ("Notification" in window && Notification.permission === "granted") {
      try {
        new Notification(n.title, {
          body: n.body,
          icon: "/favicon.ico",
          badge: "/favicon.ico",
          tag: n.type,
        });
      } catch {
        // Some browsers block Notification in iframes — silently ignore
      }
    }
  }, []);

  const markRead = useCallback((id: string) => {
    setNotifications((prev) =>
      prev.map((n) => n.id === id ? { ...n, read: true } : n)
    );
  }, []);

  const markAllRead = useCallback(() => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  }, []);

  const clearAll = useCallback(() => {
    setNotifications([]);
  }, []);

  const requestPermission = useCallback(async () => {
    if (!("Notification" in window)) return;
    const result = await Notification.requestPermission();
    setBrowserPermission(result);
  }, []);

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <NotificationsContext.Provider value={{
      notifications, unreadCount,
      addNotification, fireNotification,
      markRead, markAllRead, clearAll,
      requestPermission, browserPermission,
    }}>
      {children}
    </NotificationsContext.Provider>
  );
}

const NOOP = () => {};
const FALLBACK: NotificationsContextValue = {
  notifications: [], unreadCount: 0,
  addNotification: NOOP, fireNotification: NOOP,
  markRead: NOOP, markAllRead: NOOP, clearAll: NOOP,
  requestPermission: NOOP, browserPermission: "default",
};

export function useNotifications() {
  return useContext(NotificationsContext) ?? FALLBACK;
}
