import { createContext, useContext, useState, useEffect, useCallback } from "react";

export type Priority = "low" | "medium" | "high";
export type FilterStatus = "all" | "active" | "completed";
export type SortBy = "manual" | "created" | "priority" | "dueDate" | "alpha";
export type Recurrence = "none" | "daily" | "weekly" | "monthly";

export interface Subtask {
  id: string;
  title: string;
  completed: boolean;
}

export interface Todo {
  id: string;
  title: string;
  completed: boolean;
  priority: Priority;
  category: string;
  dueDate: string | null;
  createdAt: number;
  completedAt: number | null;
  recurrence: Recurrence;
  subtasks: Subtask[];
}

interface TodoContextValue {
  todos: Todo[];
  addTodo: (data: Omit<Todo, "id" | "createdAt" | "completed" | "completedAt" | "subtasks">) => void;
  toggleTodo: (id: string) => void;
  deleteTodo: (id: string) => void;
  editTodo: (id: string, data: Partial<Omit<Todo, "id" | "createdAt">>) => void;
  clearCompleted: () => void;
  addSubtask: (todoId: string, title: string) => void;
  toggleSubtask: (todoId: string, subtaskId: string) => void;
  deleteSubtask: (todoId: string, subtaskId: string) => void;
  reorderTodos: (orderedIds: string[]) => void;
  bulkComplete: (ids: string[]) => void;
  bulkDelete: (ids: string[]) => void;
}

const TodoContext = createContext<TodoContextValue | null>(null);

const STORAGE_KEY = "todos_v2";

function nextDateStr(dateStr: string, recurrence: Recurrence): string {
  const d = new Date(dateStr + "T00:00:00");
  if (recurrence === "daily")   d.setDate(d.getDate() + 1);
  if (recurrence === "weekly")  d.setDate(d.getDate() + 7);
  if (recurrence === "monthly") d.setMonth(d.getMonth() + 1);
  return d.toISOString().split("T")[0];
}

export function TodoProvider({ children }: { children: React.ReactNode }) {
  const [todos, setTodos] = useState<Todo[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as Todo[];
        return parsed.map((t) => ({
          ...t,
          completedAt: t.completedAt ?? null,
          recurrence: t.recurrence ?? "none",
          subtasks: t.subtasks ?? [],
        }));
      }
    } catch {}
    return [];
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(todos));
  }, [todos]);

  const addTodo = useCallback((data: Omit<Todo, "id" | "createdAt" | "completed" | "completedAt" | "subtasks">) => {
    const todo: Todo = {
      ...data,
      id: crypto.randomUUID(),
      completed: false,
      completedAt: null,
      createdAt: Date.now(),
      subtasks: [],
    };
    setTodos((prev) => [todo, ...prev]);
  }, []);

  const toggleTodo = useCallback((id: string) => {
    setTodos((prev) => {
      const todo = prev.find((t) => t.id === id);
      const completing = todo && !todo.completed;

      const next = prev.map((t) =>
        t.id === id
          ? { ...t, completed: !t.completed, completedAt: completing ? Date.now() : null }
          : t
      );

      if (completing && todo && todo.recurrence !== "none" && todo.dueDate) {
        const nextTodo: Todo = {
          ...todo,
          id: crypto.randomUUID(),
          completed: false,
          completedAt: null,
          createdAt: Date.now(),
          dueDate: nextDateStr(todo.dueDate, todo.recurrence),
          subtasks: [],
        };
        return [...next, nextTodo];
      }
      return next;
    });
  }, []);

  const deleteTodo = useCallback((id: string) => {
    setTodos((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const editTodo = useCallback(
    (id: string, data: Partial<Omit<Todo, "id" | "createdAt">>) => {
      setTodos((prev) =>
        prev.map((t) => (t.id === id ? { ...t, ...data } : t))
      );
    },
    []
  );

  const clearCompleted = useCallback(() => {
    setTodos((prev) => prev.filter((t) => !t.completed));
  }, []);

  const addSubtask = useCallback((todoId: string, title: string) => {
    const subtask: Subtask = { id: crypto.randomUUID(), title, completed: false };
    setTodos((prev) =>
      prev.map((t) =>
        t.id === todoId ? { ...t, subtasks: [...t.subtasks, subtask] } : t
      )
    );
  }, []);

  const toggleSubtask = useCallback((todoId: string, subtaskId: string) => {
    setTodos((prev) =>
      prev.map((t) =>
        t.id === todoId
          ? {
              ...t,
              subtasks: t.subtasks.map((s) =>
                s.id === subtaskId ? { ...s, completed: !s.completed } : s
              ),
            }
          : t
      )
    );
  }, []);

  const deleteSubtask = useCallback((todoId: string, subtaskId: string) => {
    setTodos((prev) =>
      prev.map((t) =>
        t.id === todoId
          ? { ...t, subtasks: t.subtasks.filter((s) => s.id !== subtaskId) }
          : t
      )
    );
  }, []);

  const reorderTodos = useCallback((orderedIds: string[]) => {
    setTodos((prev) => {
      const idSet = new Set(orderedIds);
      const ordered = orderedIds.map((id) => prev.find((t) => t.id === id)!).filter(Boolean);
      const rest = prev.filter((t) => !idSet.has(t.id));
      return [...ordered, ...rest];
    });
  }, []);

  const bulkComplete = useCallback((ids: string[]) => {
    const idSet = new Set(ids);
    setTodos((prev) =>
      prev.map((t) =>
        idSet.has(t.id) && !t.completed
          ? { ...t, completed: true, completedAt: Date.now() }
          : t
      )
    );
  }, []);

  const bulkDelete = useCallback((ids: string[]) => {
    const idSet = new Set(ids);
    setTodos((prev) => prev.filter((t) => !idSet.has(t.id)));
  }, []);

  return (
    <TodoContext.Provider
      value={{
        todos,
        addTodo,
        toggleTodo,
        deleteTodo,
        editTodo,
        clearCompleted,
        addSubtask,
        toggleSubtask,
        deleteSubtask,
        reorderTodos,
        bulkComplete,
        bulkDelete,
      }}
    >
      {children}
    </TodoContext.Provider>
  );
}

const NOOP = () => {};

const FALLBACK_CONTEXT: TodoContextValue = {
  todos: [],
  addTodo: NOOP,
  toggleTodo: NOOP,
  deleteTodo: NOOP,
  editTodo: NOOP,
  clearCompleted: NOOP,
  addSubtask: NOOP,
  toggleSubtask: NOOP,
  deleteSubtask: NOOP,
  reorderTodos: NOOP,
  bulkComplete: NOOP,
  bulkDelete: NOOP,
};

export function useTodos() {
  const ctx = useContext(TodoContext);
  return ctx ?? FALLBACK_CONTEXT;
}
