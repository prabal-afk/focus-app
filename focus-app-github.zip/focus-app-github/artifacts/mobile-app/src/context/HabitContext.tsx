import { createContext, useContext, useState, useEffect, useCallback, useMemo } from "react";

export interface Habit {
  id: string;
  name: string;
  emoji: string;
  createdAt: number;
}

type HabitLog = Record<string, string[]>;

interface HabitContextValue {
  habits: Habit[];
  addHabit: (name: string, emoji: string) => void;
  deleteHabit: (id: string) => void;
  toggleHabitForDate: (habitId: string, date: string) => void;
  isCompletedForDate: (habitId: string, date: string) => boolean;
  getStreak: (habitId: string) => number;
  getLast30Days: (habitId: string) => { date: string; completed: boolean }[];
  getTodayCompletedCount: () => number;
}

const HabitContext = createContext<HabitContextValue | null>(null);

const HABITS_KEY = "habits_v1";
const LOG_KEY = "habit_log_v1";

const fmt = (d: Date) => d.toISOString().split("T")[0];

export function HabitProvider({ children }: { children: React.ReactNode }) {
  const [habits, setHabits] = useState<Habit[]>(() => {
    try {
      const raw = localStorage.getItem(HABITS_KEY);
      if (raw) return JSON.parse(raw) as Habit[];
    } catch {}
    return [];
  });

  const [habitLog, setHabitLog] = useState<HabitLog>(() => {
    try {
      const raw = localStorage.getItem(LOG_KEY);
      if (raw) return JSON.parse(raw) as HabitLog;
    } catch {}
    return {};
  });

  useEffect(() => {
    localStorage.setItem(HABITS_KEY, JSON.stringify(habits));
  }, [habits]);

  useEffect(() => {
    localStorage.setItem(LOG_KEY, JSON.stringify(habitLog));
  }, [habitLog]);

  const addHabit = useCallback((name: string, emoji: string) => {
    const habit: Habit = {
      id: crypto.randomUUID(),
      name: name.trim(),
      emoji,
      createdAt: Date.now(),
    };
    setHabits((prev) => [habit, ...prev]);
  }, []);

  const deleteHabit = useCallback((id: string) => {
    setHabits((prev) => prev.filter((h) => h.id !== id));
    setHabitLog((prev) => {
      const next = { ...prev };
      delete next[id];
      return next;
    });
  }, []);

  const toggleHabitForDate = useCallback((habitId: string, date: string) => {
    setHabitLog((prev) => {
      const dates = prev[habitId] ?? [];
      const has = dates.includes(date);
      return {
        ...prev,
        [habitId]: has ? dates.filter((d) => d !== date) : [...dates, date],
      };
    });
  }, []);

  const isCompletedForDate = useCallback(
    (habitId: string, date: string) => {
      return (habitLog[habitId] ?? []).includes(date);
    },
    [habitLog]
  );

  const getStreak = useCallback(
    (habitId: string) => {
      const dates = new Set(habitLog[habitId] ?? []);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const todayStr = fmt(today);

      let cursor = dates.has(todayStr)
        ? new Date(today)
        : new Date(today.getTime() - 86400000);

      let streak = 0;
      while (true) {
        const ds = fmt(cursor);
        if (!dates.has(ds)) break;
        streak++;
        cursor = new Date(cursor.getTime() - 86400000);
      }
      return streak;
    },
    [habitLog]
  );

  const getLast30Days = useCallback(
    (habitId: string) => {
      const dates = new Set(habitLog[habitId] ?? []);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const result: { date: string; completed: boolean }[] = [];
      for (let i = 29; i >= 0; i--) {
        const d = new Date(today.getTime() - i * 86400000);
        const ds = fmt(d);
        result.push({ date: ds, completed: dates.has(ds) });
      }
      return result;
    },
    [habitLog]
  );

  const getTodayCompletedCount = useCallback(() => {
    const todayStr = fmt(new Date());
    return habits.filter((h) => (habitLog[h.id] ?? []).includes(todayStr)).length;
  }, [habits, habitLog]);

  const value = useMemo(
    () => ({
      habits,
      addHabit,
      deleteHabit,
      toggleHabitForDate,
      isCompletedForDate,
      getStreak,
      getLast30Days,
      getTodayCompletedCount,
    }),
    [habits, addHabit, deleteHabit, toggleHabitForDate, isCompletedForDate, getStreak, getLast30Days, getTodayCompletedCount]
  );

  return <HabitContext.Provider value={value}>{children}</HabitContext.Provider>;
}

const NOOP = () => {};
const FALLBACK: HabitContextValue = {
  habits: [],
  addHabit: NOOP,
  deleteHabit: NOOP,
  toggleHabitForDate: NOOP,
  isCompletedForDate: () => false,
  getStreak: () => 0,
  getLast30Days: () => [],
  getTodayCompletedCount: () => 0,
};

export function useHabits() {
  const ctx = useContext(HabitContext);
  return ctx ?? FALLBACK;
}
