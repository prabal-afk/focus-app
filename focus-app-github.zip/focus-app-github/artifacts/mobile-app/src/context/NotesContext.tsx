import { createContext, useContext, useState, useEffect, useCallback, ReactNode } from "react";

// ─── Types ────────────────────────────────────────────────────────────────────
export type NoteColor = "default" | "yellow" | "rose" | "sky" | "emerald" | "violet";

export interface Note {
  id: string;
  title: string;
  body: string;
  color: NoteColor;
  tags: string[];
  pinned: boolean;
  createdAt: number;
  updatedAt: number;
}

interface NotesContextValue {
  notes: Note[];
  allTags: string[];
  addNote: (data: Omit<Note, "id" | "createdAt" | "updatedAt">) => Note;
  updateNote: (id: string, patch: Partial<Omit<Note, "id" | "createdAt">>) => void;
  deleteNote: (id: string) => void;
  togglePin: (id: string) => void;
  getRecentNotes: (n: number) => Note[];
}

// ─── Seed data ────────────────────────────────────────────────────────────────
const STORAGE_KEY = "app_notes_v2";

// ─── Provider ─────────────────────────────────────────────────────────────────
const NotesContext = createContext<NotesContextValue | null>(null);

export function NotesProvider({ children }: { children: ReactNode }) {
  const [notes, setNotes] = useState<Note[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? (JSON.parse(raw) as Note[]) : [];
    } catch { return []; }
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(notes));
  }, [notes]);

  const allTags = Array.from(new Set(notes.flatMap((n) => n.tags))).sort();

  const addNote = useCallback((data: Omit<Note, "id" | "createdAt" | "updatedAt">): Note => {
    const note: Note = {
      ...data,
      id: `n_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    setNotes((prev) => [note, ...prev]);
    return note;
  }, []);

  const updateNote = useCallback((id: string, patch: Partial<Omit<Note, "id" | "createdAt">>) => {
    setNotes((prev) =>
      prev.map((n) => n.id === id ? { ...n, ...patch, updatedAt: Date.now() } : n)
    );
  }, []);

  const deleteNote = useCallback((id: string) => {
    setNotes((prev) => prev.filter((n) => n.id !== id));
  }, []);

  const togglePin = useCallback((id: string) => {
    setNotes((prev) =>
      prev.map((n) => n.id === id ? { ...n, pinned: !n.pinned, updatedAt: Date.now() } : n)
    );
  }, []);

  const getRecentNotes = useCallback((count: number) => {
    return [...notes].sort((a, b) => b.updatedAt - a.updatedAt).slice(0, count);
  }, [notes]);

  return (
    <NotesContext.Provider value={{ notes, allTags, addNote, updateNote, deleteNote, togglePin, getRecentNotes }}>
      {children}
    </NotesContext.Provider>
  );
}

// ─── Hook ─────────────────────────────────────────────────────────────────────
const NOOP_CTX: NotesContextValue = {
  notes: [], allTags: [],
  addNote: () => ({ id: "", title: "", body: "", color: "default", tags: [], pinned: false, createdAt: 0, updatedAt: 0 }),
  updateNote: () => {}, deleteNote: () => {}, togglePin: () => {},
  getRecentNotes: () => [],
};

export function useNotes(): NotesContextValue {
  return useContext(NotesContext) ?? NOOP_CTX;
}
