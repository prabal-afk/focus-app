import { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Timer, Play, Pause, RotateCcw, Check,
  Wind, Zap, Brain, Coffee, Settings2, ChevronUp, ChevronDown, Flame,
} from "lucide-react";
import { useNotifications } from "@/context/NotificationsContext";
import { useSettings } from "@/context/SettingsContext";

// ─── Types ────────────────────────────────────────────────────────────────────
type TimerMode = "idle" | "running" | "paused" | "done";
type PomodoroPhase = "focus" | "shortBreak" | "longBreak";

interface Template {
  id: string;
  name: string;
  subtitle: string;
  icon: React.ElementType;
  durationSec: number;
  color: string;           // tailwind bg class for accent
  ring: string;            // hex for SVG stroke
  bg: string;              // gradient bg when running
  textColor: string;
  isPomo?: boolean;
  isBreathing?: boolean;
  breathPattern?: [number, number, number, number]; // [inhale, hold, exhale, hold]
  shortBreakSec?: number;
  longBreakSec?: number;
  pomoRounds?: number;
}

const TEMPLATES: Template[] = [
  {
    id: "pomodoro",
    name: "Pomodoro",
    subtitle: "25 min work · 5 min break",
    icon: Flame,
    durationSec: 25 * 60,
    color: "bg-rose-500",
    ring: "#f43f5e",
    bg: "from-rose-600 to-rose-400",
    textColor: "text-rose-600",
    isPomo: true,
    shortBreakSec: 5 * 60,
    longBreakSec: 15 * 60,
    pomoRounds: 4,
  },
  {
    id: "deep-work",
    name: "Deep Work",
    subtitle: "90 min intense focus",
    icon: Brain,
    durationSec: 90 * 60,
    color: "bg-violet-500",
    ring: "#8b5cf6",
    bg: "from-violet-600 to-violet-400",
    textColor: "text-violet-600",
  },
  {
    id: "quick-sprint",
    name: "Quick Sprint",
    subtitle: "15 min power focus",
    icon: Zap,
    durationSec: 15 * 60,
    color: "bg-amber-500",
    ring: "#f59e0b",
    bg: "from-amber-500 to-yellow-400",
    textColor: "text-amber-600",
  },
  {
    id: "calming",
    name: "Calming",
    subtitle: "10 min mindful session",
    icon: Wind,
    durationSec: 10 * 60,
    color: "bg-emerald-500",
    ring: "#10b981",
    bg: "from-emerald-600 to-teal-400",
    textColor: "text-emerald-600",
    isBreathing: true,
    breathPattern: [4, 4, 6, 2],
  },
  {
    id: "box-breathing",
    name: "Box Breathing",
    subtitle: "4-4-4-4 rhythm",
    icon: Wind,
    durationSec: 8 * 60,
    color: "bg-sky-500",
    ring: "#0ea5e9",
    bg: "from-sky-600 to-blue-400",
    textColor: "text-sky-600",
    isBreathing: true,
    breathPattern: [4, 4, 4, 4],
  },
  {
    id: "power-break",
    name: "Power Break",
    subtitle: "5 min recharge",
    icon: Coffee,
    durationSec: 5 * 60,
    color: "bg-orange-500",
    ring: "#f97316",
    bg: "from-orange-500 to-amber-400",
    textColor: "text-orange-600",
  },
  {
    id: "custom",
    name: "Custom",
    subtitle: "Set your own time",
    icon: Settings2,
    durationSec: 20 * 60,
    color: "bg-slate-500",
    ring: "#64748b",
    bg: "from-slate-600 to-slate-400",
    textColor: "text-slate-600",
  },
];

// ─── Helpers ──────────────────────────────────────────────────────────────────
const RING_R = 96;
const RING_CIRC = 2 * Math.PI * RING_R;

function pad(n: number) { return String(n).padStart(2, "0"); }
function secToDisplay(s: number) {
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return h > 0 ? `${pad(h)}:${pad(m)}:${pad(sec)}` : `${pad(m)}:${pad(sec)}`;
}

const PHASE_LABELS: Record<PomodoroPhase, string> = {
  focus: "Focus", shortBreak: "Short Break", longBreak: "Long Break",
};

// ─── Breathing guide ──────────────────────────────────────────────────────────
const BREATH_LABELS = ["Inhale", "Hold", "Exhale", "Hold"];

function BreathingGuide({
  pattern, elapsed, color,
}: {
  pattern: [number, number, number, number];
  elapsed: number;
  color: string;
}) {
  const cycle = pattern.reduce((a, b) => a + b, 0);
  const pos = elapsed % cycle;
  let acc = 0, phase = 0;
  for (let i = 0; i < 4; i++) {
    if (pos < acc + pattern[i]) { phase = i; break; }
    acc += pattern[i];
  }
  const phaseElapsed = pos - acc;
  const phaseDur = pattern[phase];
  const phaseProgress = phaseElapsed / phaseDur;

  const scale = phase === 0 ? 0.7 + 0.3 * phaseProgress      // inhale → grow
              : phase === 1 ? 1.0                               // hold big
              : phase === 2 ? 1.0 - 0.3 * phaseProgress        // exhale → shrink
              : 0.7;                                            // hold small

  return (
    <div className="flex flex-col items-center gap-3">
      <motion.div
        animate={{ scale }}
        transition={{ duration: 0.4, ease: "easeInOut" }}
        className={`w-20 h-20 rounded-full ${color} opacity-20`}
      />
      <div className="text-center -mt-16">
        <p className="text-white font-bold text-lg">{BREATH_LABELS[phase]}</p>
        <p className="text-white/60 text-sm">{phaseDur - phaseElapsed}s</p>
      </div>
    </div>
  );
}

// ─── SVG ring ─────────────────────────────────────────────────────────────────
function ProgressRing({
  progress, color, mode, children,
}: {
  progress: number;
  color: string;
  mode: TimerMode;
  children: React.ReactNode;
}) {
  const offset = RING_CIRC * (1 - Math.max(0, Math.min(1, progress)));
  return (
    <div className="relative w-56 h-56 flex items-center justify-center">
      <svg className="absolute inset-0 -rotate-90" width="224" height="224" viewBox="0 0 224 224">
        {/* Track */}
        <circle cx="112" cy="112" r={RING_R} fill="none"
          stroke="rgba(255,255,255,0.15)" strokeWidth="10" />
        {/* Progress */}
        <motion.circle
          cx="112" cy="112" r={RING_R} fill="none"
          stroke={mode === "idle" ? "rgba(255,255,255,0.3)" : "white"}
          strokeWidth="10"
          strokeLinecap="round"
          strokeDasharray={RING_CIRC}
          animate={{ strokeDashoffset: offset }}
          transition={{ duration: 0.5, ease: "linear" }}
        />
      </svg>
      <div className="relative z-10 flex flex-col items-center justify-center">
        {children}
      </div>
    </div>
  );
}

// ─── Custom time picker ───────────────────────────────────────────────────────
function CustomPicker({ value, onChange }: { value: number; onChange: (v: number) => void }) {
  const mins = Math.floor(value / 60);

  function adjust(delta: number) {
    const next = Math.max(1, Math.min(180, mins + delta));
    onChange(next * 60);
  }

  return (
    <div className="flex flex-col items-center gap-1">
      <button onClick={() => adjust(5)}
        className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center active:scale-95">
        <ChevronUp className="w-5 h-5 text-white" />
      </button>
      <div className="text-white font-bold text-2xl w-16 text-center tabular-nums">
        {pad(mins)}<span className="text-sm font-medium opacity-60"> min</span>
      </div>
      <button onClick={() => adjust(-5)}
        className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center active:scale-95">
        <ChevronDown className="w-5 h-5 text-white" />
      </button>
    </div>
  );
}

// ─── Session dots (Pomodoro) ──────────────────────────────────────────────────
function SessionDots({ total, done, phase }: { total: number; done: number; phase: PomodoroPhase }) {
  return (
    <div className="flex gap-2 items-center">
      {Array.from({ length: total }).map((_, i) => (
        <motion.div
          key={i}
          animate={{ scale: i === done && phase === "focus" ? [1, 1.3, 1] : 1 }}
          transition={{ repeat: Infinity, duration: 1.5 }}
          className={`w-3 h-3 rounded-full border-2 border-white/60 transition-all ${
            i < done ? "bg-white" : "bg-white/20"
          }`}
        />
      ))}
    </div>
  );
}

// ─── Main ─────────────────────────────────────────────────────────────────────
export default function TimerPage() {
  const { fireNotification } = useNotifications();
  const { settings } = useSettings();
  const [selectedId, setSelectedId] = useState("pomodoro");
  const [mode, setMode]             = useState<TimerMode>("idle");
  const [remaining, setRemaining]   = useState<number>(TEMPLATES[0].durationSec);
  const [elapsed, setElapsed]       = useState(0);
  const [pomoPhase, setPomoPhase]   = useState<PomodoroPhase>("focus");
  const [pomoDone, setPomoDone]     = useState(0);
  const [sessionsToday, setSessionsToday] = useState(0);
  const [customSec, setCustomSec]   = useState(20 * 60);
  const [showCustom, setShowCustom] = useState(false);

  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const tpl = TEMPLATES.find((t) => t.id === selectedId)!;

  // ── Effective duration for current phase ──
  const effectiveDuration = useCallback(() => {
    if (selectedId === "custom") return customSec;
    if (tpl.isPomo) {
      if (pomoPhase === "focus") return tpl.durationSec;
      if (pomoPhase === "longBreak") return tpl.longBreakSec!;
      return tpl.shortBreakSec!;
    }
    return tpl.durationSec;
  }, [selectedId, tpl, pomoPhase, customSec]);

  // ── Reset when template or custom time changes ──
  useEffect(() => {
    stop();
    setPomoPhase("focus");
    setPomoDone(0);
    const dur = selectedId === "custom" ? customSec : tpl.durationSec;
    setRemaining(dur);
    setElapsed(0);
    setShowCustom(selectedId === "custom");
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedId, customSec]);

  // ── Tick ──
  useEffect(() => {
    if (mode === "running") {
      intervalRef.current = setInterval(() => {
        setRemaining((r) => {
          if (r <= 1) {
            handlePhaseEnd();
            return 0;
          }
          return r - 1;
        });
        setElapsed((e) => e + 1);
      }, 1000);
    }
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode, pomoPhase]);

  function stop() {
    if (intervalRef.current) clearInterval(intervalRef.current);
    setMode("idle");
  }

  function handlePhaseEnd() {
    if (intervalRef.current) clearInterval(intervalRef.current);
    setMode("done");
    setSessionsToday((s) => s + 1);

    // Fire notification
    if (settings.notifyTimer) {
      const isPomoBreak = tpl.isPomo && pomoPhase !== "focus";
      fireNotification({
        type: "timer_done",
        title: isPomoBreak ? "Break over! ☕" : `${tpl.name} complete! 🎉`,
        body: isPomoBreak
          ? "Time to get back to work."
          : `Great focus session — ${Math.round((tpl.isPomo ? tpl.durationSec : effectiveDuration()) / 60)} minutes done.`,
      });
    }

    if (tpl.isPomo) {
      setPomoDone((prev) => {
        const newDone = prev + (pomoPhase === "focus" ? 1 : 0);
        const isLong = newDone > 0 && newDone % (tpl.pomoRounds ?? 4) === 0;
        setTimeout(() => {
          const nextPhase: PomodoroPhase =
            pomoPhase !== "focus" ? "focus"
            : isLong ? "longBreak"
            : "shortBreak";
          setPomoPhase(nextPhase);
          const dur = nextPhase === "focus"
            ? tpl.durationSec
            : nextPhase === "longBreak"
            ? tpl.longBreakSec!
            : tpl.shortBreakSec!;
          setRemaining(dur);
          setElapsed(0);
          setMode("idle");
        }, 1200);
        return newDone;
      });
    } else {
      setTimeout(() => {
        setRemaining(effectiveDuration());
        setElapsed(0);
        setMode("idle");
      }, 1200);
    }
  }

  function handleStartPause() {
    if (mode === "idle" || mode === "paused") {
      setMode("running");
    } else if (mode === "running") {
      setMode("paused");
    }
  }

  function handleReset() {
    stop();
    setPomoPhase("focus");
    setPomoDone(0);
    const dur = selectedId === "custom" ? customSec : tpl.durationSec;
    setRemaining(dur);
    setElapsed(0);
  }

  const total = effectiveDuration();
  const progress = total > 0 ? (total - remaining) / total : 0;

  const phaseLabel = tpl.isPomo
    ? PHASE_LABELS[pomoPhase]
    : mode === "done" ? "Done!" : mode === "idle" ? "Ready" : tpl.name;

  const isRunning = mode === "running";
  const isDone    = mode === "done";

  return (
    <div className="flex flex-col h-full bg-background overflow-hidden">
      {/* ── Animated full-screen bg when running ── */}
      <AnimatePresence>
        {(isRunning || isDone) && (
          <motion.div
            key="timer-bg"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
            className={`absolute inset-0 bg-gradient-to-br ${tpl.bg} z-0`}
          />
        )}
      </AnimatePresence>

      {/* ── Header ── */}
      <div className={`px-5 pt-12 pb-4 relative z-10 transition-colors duration-500 ${isRunning || isDone ? "" : "border-b border-border"}`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
              isRunning || isDone ? "bg-white/20" : "bg-rose-100"
            }`}>
              <Timer className={`w-5 h-5 ${isRunning || isDone ? "text-white" : "text-rose-600"}`} />
            </div>
            <h1 className={`text-2xl font-bold transition-colors ${isRunning || isDone ? "text-white" : "text-foreground"}`}>
              Timer
            </h1>
          </div>
          {sessionsToday > 0 && (
            <motion.div
              initial={{ scale: 0 }} animate={{ scale: 1 }}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold ${
                isRunning || isDone ? "bg-white/20 text-white" : "bg-muted text-muted-foreground"
              }`}
            >
              <Check className="w-3 h-3" />
              {sessionsToday} today
            </motion.div>
          )}
        </div>
      </div>

      {/* ── Content ── */}
      <div className="flex-1 relative z-10 flex flex-col overflow-hidden">
        <AnimatePresence mode="wait">
          {!isRunning && !isDone ? (
            /* ── IDLE / PAUSED VIEW ── */
            <motion.div
              key="idle"
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="flex-1 flex flex-col overflow-hidden"
            >
              {/* Template selector */}
              <div className="px-5 pt-3 pb-2">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Choose a Template</p>
                <div className="flex gap-3 overflow-x-auto pb-2 -mx-5 px-5 snap-x scrollbar-hide">
                  {TEMPLATES.map((t) => {
                    const Icon = t.icon;
                    const active = t.id === selectedId;
                    return (
                      <button
                        key={t.id}
                        data-testid={`template-${t.id}`}
                        onClick={() => setSelectedId(t.id)}
                        className={`snap-start shrink-0 flex flex-col gap-2 p-3 rounded-2xl border-2 transition-all w-28 text-left ${
                          active
                            ? `border-transparent ${t.color} text-white shadow-lg`
                            : "border-border bg-card text-foreground hover:border-primary/30"
                        }`}
                      >
                        <Icon className={`w-5 h-5 ${active ? "text-white" : t.textColor}`} />
                        <div>
                          <p className={`text-xs font-bold leading-tight ${active ? "text-white" : ""}`}>{t.name}</p>
                          <p className={`text-[10px] leading-tight mt-0.5 ${active ? "text-white/70" : "text-muted-foreground"}`}>
                            {t.subtitle}
                          </p>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Timer face */}
              <div className="flex-1 flex flex-col items-center justify-center gap-6 pb-20 px-5">
                {/* Custom picker or ring */}
                {showCustom ? (
                  <div className={`w-56 h-56 rounded-full bg-gradient-to-br ${tpl.bg} flex items-center justify-center shadow-2xl`}>
                    <CustomPicker value={customSec} onChange={setCustomSec} />
                  </div>
                ) : (
                  <div className={`w-56 h-56 rounded-full bg-gradient-to-br ${tpl.bg} flex flex-col items-center justify-center shadow-2xl shadow-black/10`}>
                    <p className="text-white font-bold text-4xl tabular-nums tracking-tight">
                      {secToDisplay(remaining)}
                    </p>
                    <p className="text-white/60 text-xs font-semibold uppercase tracking-widest mt-1">{phaseLabel}</p>
                    {tpl.isPomo && (
                      <div className="mt-3">
                        <SessionDots total={tpl.pomoRounds!} done={pomoDone % tpl.pomoRounds!} phase={pomoPhase} />
                      </div>
                    )}
                  </div>
                )}

                {/* Template details */}
                <div className="text-center">
                  <p className="font-bold text-base">{tpl.name}</p>
                  <p className="text-sm text-muted-foreground">{tpl.subtitle}</p>
                  {tpl.isBreathing && tpl.breathPattern && (
                    <p className="text-xs text-muted-foreground mt-1">
                      {tpl.breathPattern.join("-")} breathing pattern
                    </p>
                  )}
                  {tpl.isPomo && (
                    <p className="text-xs text-muted-foreground mt-1">
                      Round {(pomoDone % tpl.pomoRounds!) + 1} of {tpl.pomoRounds}
                      {pomoPhase !== "focus" && ` · ${PHASE_LABELS[pomoPhase]}`}
                    </p>
                  )}
                </div>

                {/* Controls */}
                <div className="flex items-center gap-5">
                  <button
                    data-testid="button-reset"
                    onClick={handleReset}
                    className="w-12 h-12 rounded-full bg-muted flex items-center justify-center text-muted-foreground hover:bg-muted/80 active:scale-95 transition-all"
                  >
                    <RotateCcw className="w-5 h-5" />
                  </button>

                  <motion.button
                    data-testid="button-start-pause"
                    onClick={handleStartPause}
                    whileTap={{ scale: 0.93 }}
                    className={`w-20 h-20 rounded-full ${tpl.color} text-white flex items-center justify-center shadow-xl active:scale-95 transition-all`}
                    style={{ boxShadow: `0 8px 32px ${tpl.ring}55` }}
                  >
                    <Play className="w-8 h-8 fill-white ml-1" />
                  </motion.button>

                  <div className="w-12 h-12" /> {/* spacer */}
                </div>
              </div>
            </motion.div>

          ) : (
            /* ── RUNNING / DONE VIEW ── */
            <motion.div
              key="running"
              initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.96 }}
              className="flex-1 flex flex-col items-center justify-between pb-24 pt-4 px-5"
            >
              {/* Phase label */}
              <AnimatePresence mode="wait">
                <motion.div
                  key={phaseLabel}
                  initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 8 }}
                  className="text-center"
                >
                  <p className="text-white/70 text-sm font-semibold uppercase tracking-widest">
                    {phaseLabel}
                  </p>
                  {tpl.isPomo && (
                    <p className="text-white/50 text-xs mt-0.5">
                      Round {(pomoDone % tpl.pomoRounds!) + 1} of {tpl.pomoRounds}
                    </p>
                  )}
                </motion.div>
              </AnimatePresence>

              {/* Ring + time */}
              <div className="flex flex-col items-center gap-6">
                <ProgressRing progress={progress} color={tpl.ring} mode={mode}>
                  <AnimatePresence mode="wait">
                    {isDone ? (
                      <motion.div key="done" initial={{ scale: 0 }} animate={{ scale: 1 }} exit={{ scale: 0 }}
                        className="flex flex-col items-center gap-1">
                        <Check className="w-14 h-14 text-white" strokeWidth={2.5} />
                        <p className="text-white font-bold text-sm">Complete!</p>
                      </motion.div>
                    ) : (
                      <motion.div key="time" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center">
                        <p className="text-white font-bold text-4xl tabular-nums tracking-tighter leading-none">
                          {secToDisplay(remaining)}
                        </p>
                        <p className="text-white/50 text-xs mt-1 font-medium uppercase tracking-widest">remaining</p>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </ProgressRing>

                {/* Breathing guide */}
                {tpl.isBreathing && tpl.breathPattern && isRunning && (
                  <BreathingGuide pattern={tpl.breathPattern} elapsed={elapsed} color={tpl.color} />
                )}

                {/* Pomodoro session dots */}
                {tpl.isPomo && (
                  <SessionDots total={tpl.pomoRounds!} done={pomoDone % tpl.pomoRounds!} phase={pomoPhase} />
                )}
              </div>

              {/* Controls */}
              <div className="flex items-center gap-5">
                <button
                  data-testid="button-reset-running"
                  onClick={handleReset}
                  className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center text-white active:scale-95 transition-all"
                >
                  <RotateCcw className="w-5 h-5" />
                </button>

                <motion.button
                  data-testid="button-start-pause-running"
                  onClick={handleStartPause}
                  whileTap={{ scale: 0.93 }}
                  className="w-20 h-20 rounded-full bg-white text-foreground flex items-center justify-center shadow-2xl active:scale-95 transition-all"
                >
                  {isRunning
                    ? <Pause className="w-8 h-8 fill-foreground" />
                    : <Play className="w-8 h-8 fill-foreground ml-1" />
                  }
                </motion.button>

                <div className="w-12 h-12" />
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
