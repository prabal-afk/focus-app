import { useState, useEffect, useMemo } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import {
  CheckSquare, CalendarDays, StickyNote, Timer,
  Bell, Settings, Check, ArrowRight, Clock, Pin, Search, TrendingUp,
  Sun, Flame,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useTodos } from "@/context/TodoContext";
import { usePlanner, EventColor } from "@/context/PlannerContext";
import { useNotes } from "@/context/NotesContext";
import { useSettings } from "@/context/SettingsContext";
import { useNotifications } from "@/context/NotificationsContext";
import { useHabits } from "@/context/HabitContext";
import { AiCompanion } from "@/components/AiCompanion";
import { NotificationsPanel } from "@/components/NotificationsPanel";
import { SettingsPanel } from "@/components/SettingsPanel";
import { SearchPanel } from "@/components/SearchPanel";
import { StatsSheet } from "@/components/StatsSheet";

const widgets = [
  { href: "/todo",    label: "ToDo List", description: "Track your tasks",       icon: CheckSquare,  color: "bg-violet-500", light: "bg-violet-50", text: "text-violet-600", shadow: "shadow-violet-200" },
  { href: "/planner", label: "Planner",   description: "Organise your day",      icon: CalendarDays, color: "bg-sky-500",    light: "bg-sky-50",    text: "text-sky-600",    shadow: "shadow-sky-200"   },
  { href: "/notes",   label: "Notes",     description: "Capture your thoughts",  icon: StickyNote,   color: "bg-amber-500",  light: "bg-amber-50",  text: "text-amber-600",  shadow: "shadow-amber-200" },
  { href: "/timer",   label: "Timer",     description: "Stay focused",           icon: Timer,        color: "bg-rose-500",   light: "bg-rose-50",   text: "text-rose-600",   shadow: "shadow-rose-200"  },
  { href: "/habits",  label: "Habits",    description: "Build daily streaks",    icon: Flame,        color: "bg-emerald-500",light: "bg-emerald-50",text: "text-emerald-600",shadow: "shadow-emerald-200"},
];

const containerVariants = { hidden: {}, show: { transition: { staggerChildren: 0.07 } } };
const itemVariants = {
  hidden: { opacity: 0, y: 16 },
  show:   { opacity: 1, y: 0, transition: { type: "spring", stiffness: 300, damping: 24 } },
};

const PRIORITY_DOT: Record<string, string> = {
  high: "bg-rose-500", medium: "bg-amber-400", low: "bg-emerald-500",
};

const EVENT_COLOR_DOT: Record<EventColor, string> = {
  sky: "bg-sky-500", violet: "bg-violet-500", rose: "bg-rose-500",
  emerald: "bg-emerald-500", amber: "bg-amber-500", orange: "bg-orange-500",
};
const EVENT_COLOR_PILL: Record<EventColor, string> = {
  sky: "bg-sky-100 text-sky-700", violet: "bg-violet-100 text-violet-700",
  rose: "bg-rose-100 text-rose-700", emerald: "bg-emerald-100 text-emerald-700",
  amber: "bg-amber-100 text-amber-700", orange: "bg-orange-100 text-orange-700",
};

function greeting() {
  const h = new Date().getHours();
  if (h < 12) return "Good morning";
  if (h < 17) return "Good afternoon";
  return "Good evening";
}

export default function Home() {
  const [, setLocation] = useLocation();
  const { todos, toggleTodo } = useTodos();
  const { getUpcomingEvents, events } = usePlanner();
  const { getRecentNotes } = useNotes();
  const { settings } = useSettings();
  const { unreadCount, addNotification } = useNotifications();
  const { habits, getTodayCompletedCount } = useHabits();

  const [showNotifs, setShowNotifs] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [showStats, setShowStats] = useState(false);

  // ── ToDo stats ──
  const activeTodos  = todos.filter((t) => !t.completed).slice(0, 3);
  const activeCount  = todos.filter((t) => !t.completed).length;
  const doneCount    = todos.filter((t) =>  t.completed).length;
  const total        = todos.length;
  const progressPct  = total > 0 ? Math.round((doneCount / total) * 100) : 0;

  // ── Planner upcoming ──
  const upcoming = getUpcomingEvents(4);

  // ── Recent notes ──
  const recentNotes = getRecentNotes(3);

  // ── Today's combined feed ──
  const todayStr = new Date().toISOString().split("T")[0];

  type TodayItem =
    | { kind: "todo"; id: string; title: string; priority: string; completed: boolean; sortKey: string }
    | { kind: "event"; id: string; title: string; time: string | null; color: EventColor; type: string; sortKey: string };

  const todayItems = useMemo<TodayItem[]>(() => {
    const todoItems: TodayItem[] = todos
      .filter((t) => !t.completed && t.dueDate === todayStr)
      .map((t) => ({ kind: "todo", id: t.id, title: t.title, priority: t.priority, completed: t.completed, sortKey: "23:59" }));

    const eventItems: TodayItem[] = events
      .filter((e) => e.date === todayStr && !e.completed)
      .map((e) => ({ kind: "event", id: e.id, title: e.title, time: e.time, color: e.color, type: e.type, sortKey: e.time ?? "00:00" }));

    return [...todoItems, ...eventItems].sort((a, b) => a.sortKey.localeCompare(b.sortKey));
  }, [todos, events, todayStr]);

  // ── Habits today ──
  const habitsDoneToday = getTodayCompletedCount();

  // ── Due-date notifications on mount (once per todo per day) ──
  useEffect(() => {
    if (!settings.notifyDueDate) return;

    const dueToday = todos.filter((t) => !t.completed && t.dueDate === todayStr);
    const dueSoon  = todos.filter((t) => {
      if (t.completed || !t.dueDate) return false;
      const diff = (new Date(t.dueDate).getTime() - new Date(todayStr).getTime()) / 86400000;
      return diff === 1;
    });

    dueToday.forEach((t) => {
      const key = `home_notif_today_${t.id}_${todayStr}`;
      if (sessionStorage.getItem(key)) return;
      sessionStorage.setItem(key, "1");
      addNotification({
        type: "due_today",
        title: "Due today",
        body: `"${t.title}" is due today${t.priority === "high" ? " — high priority!" : "."}`,
      });
    });
    dueSoon.forEach((t) => {
      const key = `home_notif_soon_${t.id}_${todayStr}`;
      if (sessionStorage.getItem(key)) return;
      sessionStorage.setItem(key, "1");
      addNotification({
        type: "due_soon",
        title: "Due tomorrow",
        body: `"${t.title}" is due tomorrow.`,
      });
    });
  // Only run once on mount
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function formatEventDate(dateStr: string, time: string | null) {
    const today = new Date(); today.setHours(0,0,0,0);
    const d = new Date(dateStr + "T00:00:00");
    const diff = Math.round((d.getTime() - today.getTime()) / 86400000);
    const dayLabel =
      diff === 0 ? "Today" :
      diff === 1 ? "Tomorrow" :
      d.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" });
    const timeLabel = time
      ? new Date(`2000-01-01T${time}`).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })
      : null;
    return timeLabel ? `${dayLabel} · ${timeLabel}` : dayLabel;
  }

  function fmtTime(time: string) {
    return new Date(`2000-01-01T${time}`).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
  }

  const displayName = settings.name ? `, ${settings.name}` : "";

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      className="flex flex-col h-full bg-background relative overflow-hidden"
    >
      {/* ── Greeting Header ── */}
      <div className="px-5 pt-12 pb-5 bg-background relative">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-foreground leading-snug">
              {greeting()}{displayName} 👋
            </h1>
          </div>
          <div className="flex gap-2 pt-1">
            <button
              onClick={() => setShowSearch(true)}
              className="w-10 h-10 rounded-full bg-card border border-border shadow-sm flex items-center justify-center"
              aria-label="Search"
            >
              <Search className="w-4.5 h-4.5 text-foreground" />
            </button>
            <button
              onClick={() => setShowStats(true)}
              className="w-10 h-10 rounded-full bg-card border border-border shadow-sm flex items-center justify-center"
              aria-label="Stats"
            >
              <TrendingUp className="w-4.5 h-4.5 text-foreground" />
            </button>
            <button
              onClick={() => setShowNotifs(true)}
              className="relative w-10 h-10 rounded-full bg-card border border-border shadow-sm flex items-center justify-center"
            >
              <Bell className="w-4.5 h-4.5 text-foreground" />
              {unreadCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-rose-500 text-white text-[9px] font-bold flex items-center justify-center leading-none">
                  {unreadCount > 9 ? "9+" : unreadCount}
                </span>
              )}
            </button>
            <button
              onClick={() => setShowSettings(true)}
              className="w-10 h-10 rounded-full bg-card border border-border shadow-sm flex items-center justify-center"
            >
              <Settings className="w-4.5 h-4.5 text-foreground" />
            </button>
          </div>
        </div>

        {/* Stat pills */}
        <div className="flex gap-2 flex-wrap">
          <div className="flex items-center gap-1.5 bg-violet-50 dark:bg-violet-900/20 border border-violet-100 dark:border-violet-800 rounded-full px-3 py-1.5">
            <CheckSquare className="w-3.5 h-3.5 text-violet-600" />
            <span className="text-xs font-semibold text-violet-700 dark:text-violet-300">
              {todos.filter(t => !t.completed).length} task{todos.filter(t => !t.completed).length !== 1 ? "s" : ""} left
            </span>
          </div>
          <div className="flex items-center gap-1.5 bg-sky-50 dark:bg-sky-900/20 border border-sky-100 dark:border-sky-800 rounded-full px-3 py-1.5">
            <CalendarDays className="w-3.5 h-3.5 text-sky-600" />
            <span className="text-xs font-semibold text-sky-700 dark:text-sky-300">
              {upcoming.length} upcoming
            </span>
          </div>
          {habits.length > 0 && (
            <div
              onClick={() => setLocation("/habits")}
              className="flex items-center gap-1.5 bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-100 dark:border-emerald-800 rounded-full px-3 py-1.5 cursor-pointer"
            >
              <Flame className="w-3.5 h-3.5 text-emerald-600" />
              <span className="text-xs font-semibold text-emerald-700 dark:text-emerald-300">
                {habitsDoneToday}/{habits.length} habits
              </span>
            </div>
          )}
          {unreadCount > 0 && (
            <div className="flex items-center gap-1.5 bg-rose-50 dark:bg-rose-900/20 border border-rose-100 dark:border-rose-800 rounded-full px-3 py-1.5">
              <Bell className="w-3.5 h-3.5 text-rose-500" />
              <span className="text-xs font-semibold text-rose-600 dark:text-rose-300">
                {unreadCount} new
              </span>
            </div>
          )}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-5 pb-28 space-y-5">

        {/* ── Today's Feed ── */}
        {todayItems.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.04 }}
            className="bg-gradient-to-br from-orange-50 to-amber-50 dark:from-orange-900/20 dark:to-amber-900/20 border border-orange-100 dark:border-orange-800 rounded-3xl p-5 shadow-sm"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-orange-100 rounded-xl flex items-center justify-center">
                  <Sun className="w-4 h-4 text-orange-600" />
                </div>
                <h3 className="font-bold text-base">Today</h3>
                <span className="text-xs text-muted-foreground font-medium">
                  {new Date().toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" })}
                </span>
              </div>
              <span className="text-xs font-medium text-orange-600 bg-orange-100 px-2.5 py-1 rounded-full">
                {todayItems.length} item{todayItems.length !== 1 ? "s" : ""}
              </span>
            </div>

            <ul className="space-y-2.5">
              {todayItems.map((item) => (
                <li key={`${item.kind}-${item.id}`} className="flex items-center gap-3">
                  {item.kind === "todo" ? (
                    <>
                      <button
                        onClick={() => toggleTodo(item.id)}
                        className="w-5 h-5 rounded-full border-2 border-orange-300 bg-white flex items-center justify-center shrink-0 transition-all hover:border-orange-500"
                      >
                        {item.completed && <Check className="w-2.5 h-2.5 text-orange-500" strokeWidth={3} />}
                      </button>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground truncate">{item.title}</p>
                      </div>
                      <span className={`w-2 h-2 rounded-full shrink-0 ${PRIORITY_DOT[item.priority]}`} />
                      <span
                        onClick={() => setLocation("/todo")}
                        className="text-[10px] font-semibold text-orange-500 bg-orange-100 px-2 py-0.5 rounded-full cursor-pointer"
                      >
                        Task
                      </span>
                    </>
                  ) : (
                    <>
                      <span className={`w-5 h-5 rounded-full shrink-0 flex items-center justify-center ${EVENT_COLOR_DOT[item.color].replace("bg-", "bg-").replace("-500", "-100")}`}>
                        <span className={`w-2 h-2 rounded-full ${EVENT_COLOR_DOT[item.color]}`} />
                      </span>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground truncate">{item.title}</p>
                        {item.time && (
                          <p className="text-[11px] text-muted-foreground flex items-center gap-1 mt-0.5">
                            <Clock className="w-3 h-3" />{fmtTime(item.time)}
                          </p>
                        )}
                      </div>
                      <span
                        onClick={() => setLocation("/planner")}
                        className={`text-[10px] font-semibold px-2 py-0.5 rounded-full cursor-pointer ${EVENT_COLOR_PILL[item.color]}`}
                      >
                        {item.type === "event" ? "Event" : "Task"}
                      </span>
                    </>
                  )}
                </li>
              ))}
            </ul>
          </motion.div>
        )}

        {/* ── ToDo Summary Card ── */}
        <motion.div
          initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.08 }}
          className="bg-card border border-border rounded-3xl p-5 shadow-sm"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-violet-100 rounded-xl flex items-center justify-center">
                <CheckSquare className="w-4 h-4 text-violet-600" />
              </div>
              <h3 className="font-bold text-base">Tasks</h3>
            </div>
            <button onClick={() => setLocation("/todo")}
              className="flex items-center gap-1 text-xs font-medium text-violet-600">
              View all <ArrowRight className="w-3 h-3" />
            </button>
          </div>
          <div className="mb-4">
            <div className="flex items-center justify-between text-xs text-muted-foreground mb-1.5">
              <span>{doneCount} of {total} completed</span>
              <span className="font-semibold text-violet-600">{progressPct}%</span>
            </div>
            <div className="h-2 bg-muted rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-violet-500 rounded-full"
                initial={{ width: 0 }}
                animate={{ width: `${progressPct}%` }}
                transition={{ duration: 0.6, ease: "easeOut" }}
              />
            </div>
          </div>
          {activeTodos.length === 0 ? (
            <div className="flex items-center gap-2 py-1 text-sm text-muted-foreground">
              <Check className="w-4 h-4 text-emerald-500" /> All tasks done — great work!
            </div>
          ) : (
            <ul className="space-y-2">
              {activeTodos.map((todo) => (
                <li key={todo.id} className="flex items-center gap-3">
                  <span className={`w-2 h-2 rounded-full shrink-0 ${PRIORITY_DOT[todo.priority]}`} />
                  <span className="text-sm text-foreground truncate">{todo.title}</span>
                </li>
              ))}
              {activeCount > 3 && (
                <li className="text-xs text-muted-foreground pl-5">
                  +{activeCount - 3} more task{activeCount - 3 > 1 ? "s" : ""}
                </li>
              )}
            </ul>
          )}
        </motion.div>

        {/* ── Planner Upcoming Card ── */}
        <motion.div
          initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.14 }}
          className="bg-card border border-border rounded-3xl p-5 shadow-sm"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-sky-100 rounded-xl flex items-center justify-center">
                <CalendarDays className="w-4 h-4 text-sky-600" />
              </div>
              <h3 className="font-bold text-base">Upcoming</h3>
            </div>
            <button onClick={() => setLocation("/planner")}
              className="flex items-center gap-1 text-xs font-medium text-sky-600">
              View all <ArrowRight className="w-3 h-3" />
            </button>
          </div>
          {upcoming.length === 0 ? (
            <div className="flex items-center gap-2 py-1 text-sm text-muted-foreground">
              <CalendarDays className="w-4 h-4 text-sky-300" /> Nothing coming up — enjoy the calm!
            </div>
          ) : (
            <ul className="space-y-3">
              {upcoming.map((ev) => (
                <li key={ev.id} className="flex items-start gap-3">
                  <span className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${EVENT_COLOR_DOT[ev.color]}`} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground truncate">{ev.title}</p>
                    <div className="flex items-center gap-1.5 mt-0.5">
                      <Clock className="w-3 h-3 text-muted-foreground" />
                      <span className="text-[11px] text-muted-foreground">
                        {formatEventDate(ev.date, ev.time)}
                      </span>
                      <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded-full ${EVENT_COLOR_PILL[ev.color]}`}>
                        {ev.type === "event" ? "Event" : "Task"}
                      </span>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </motion.div>

        {/* ── Recent Notes Card ── */}
        <motion.div
          initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
          className="bg-card border border-border rounded-3xl p-5 shadow-sm"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-amber-100 rounded-xl flex items-center justify-center">
                <StickyNote className="w-4 h-4 text-amber-600" />
              </div>
              <h3 className="font-bold text-base">Notes</h3>
            </div>
            <button onClick={() => setLocation("/notes")}
              className="flex items-center gap-1 text-xs font-medium text-amber-600">
              View all <ArrowRight className="w-3 h-3" />
            </button>
          </div>
          {recentNotes.length === 0 ? (
            <div className="flex items-center gap-2 py-1 text-sm text-muted-foreground">
              <StickyNote className="w-4 h-4 text-amber-300" /> No notes yet — start capturing ideas!
            </div>
          ) : (
            <ul className="space-y-2.5">
              {recentNotes.map((note) => (
                <li key={note.id} onClick={() => setLocation("/notes")}
                  className="flex items-start gap-3 cursor-pointer group">
                  <span className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${
                    note.color === "yellow"  ? "bg-amber-400"   :
                    note.color === "rose"    ? "bg-rose-400"    :
                    note.color === "sky"     ? "bg-sky-400"     :
                    note.color === "emerald" ? "bg-emerald-400" :
                    note.color === "violet"  ? "bg-violet-400"  : "bg-slate-400"
                  }`} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <p className="text-sm font-medium text-foreground truncate">
                        {note.title || "Untitled"}
                      </p>
                      {note.pinned && <Pin className="w-3 h-3 text-amber-500 shrink-0" />}
                    </div>
                    {note.body && (
                      <p className="text-[11px] text-muted-foreground truncate mt-0.5">{note.body}</p>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </motion.div>

        {/* ── Widget Grid ── */}
        <div>
          <h3 className="text-xs font-semibold text-muted-foreground mb-4 uppercase tracking-wider">Your Spaces</h3>
          <motion.div
            className="grid grid-cols-2 gap-4"
            variants={containerVariants} initial="hidden" animate="show"
          >
            {widgets.map((w) => {
              const Icon = w.icon;
              return (
                <motion.button
                  key={w.href}
                  variants={itemVariants}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setLocation(w.href)}
                  className={`${w.light} rounded-3xl p-5 text-left shadow-md ${w.shadow} border border-white/60 flex flex-col gap-4 cursor-pointer`}
                >
                  <div className={`w-11 h-11 ${w.color} rounded-2xl flex items-center justify-center shadow-md`}>
                    <Icon className="w-5 h-5 text-white" strokeWidth={2.5} />
                  </div>
                  <div>
                    <p className={`font-bold text-base ${w.text}`}>{w.label}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{w.description}</p>
                  </div>
                </motion.button>
              );
            })}
          </motion.div>
        </div>
      </div>

      {/* ── AI Companion ── */}
      <AiCompanion />

      {/* ── Panels ── */}
      <SearchPanel open={showSearch} onClose={() => setShowSearch(false)} />
      <StatsSheet open={showStats} onClose={() => setShowStats(false)} />
      <NotificationsPanel open={showNotifs} onClose={() => setShowNotifs(false)} />
      <SettingsPanel open={showSettings} onClose={() => setShowSettings(false)} />
    </motion.div>
  );
}
