import { motion } from "framer-motion";
import { Search, MapPin, TrendingUp, Star } from "lucide-react";
import { Input } from "@/components/ui/input";

export default function Explore() {
  const categories = [
    { id: 1, name: "Trending", icon: TrendingUp, color: "bg-orange-100 text-orange-600" },
    { id: 2, name: "Local", icon: MapPin, color: "bg-blue-100 text-blue-600" },
    { id: 3, name: "Featured", icon: Star, color: "bg-purple-100 text-purple-600" },
  ];

  const items = Array.from({ length: 8 }).map((_, i) => ({
    id: i,
    title: `Discover ${i + 1}`,
    subtitle: "New and noteworthy",
    image: `https://picsum.photos/seed/${i + 100}/400/300`,
  }));

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      className="flex flex-col h-full bg-background"
    >
      <div className="px-4 pt-12 pb-4 sticky top-0 bg-background/80 backdrop-blur-xl z-10 border-b border-border">
        <h1 className="text-2xl font-bold mb-4">Explore</h1>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input 
            placeholder="Search anything..." 
            className="pl-9 bg-card border-none shadow-sm rounded-xl h-10"
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-6 space-y-8 pb-24">
        {/* Categories */}
        <div className="flex gap-3 overflow-x-auto pb-2 -mx-4 px-4 snap-x">
          {categories.map((cat) => (
            <div key={cat.id} className="snap-start shrink-0 flex flex-col items-center gap-2">
              <div className={`w-14 h-14 rounded-full flex items-center justify-center ${cat.color}`}>
                <cat.icon className="w-6 h-6" />
              </div>
              <span className="text-xs font-medium text-muted-foreground">{cat.name}</span>
            </div>
          ))}
        </div>

        {/* Grid */}
        <div>
          <h2 className="text-lg font-bold mb-4">Recommended for you</h2>
          <div className="grid grid-cols-2 gap-4">
            {items.map((item) => (
              <motion.div 
                key={item.id}
                whileTap={{ scale: 0.96 }}
                className="bg-card rounded-2xl overflow-hidden shadow-sm border border-border"
              >
                <div className="aspect-[4/3] bg-muted relative">
                  <img 
                    src={item.image} 
                    alt={item.title}
                    className="w-full h-full object-cover"
                    loading="lazy"
                  />
                </div>
                <div className="p-3">
                  <h3 className="font-semibold text-sm line-clamp-1">{item.title}</h3>
                  <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{item.subtitle}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </motion.div>
  );
}
