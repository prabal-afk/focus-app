import { useState, useMemo, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  CalendarDays, Plus, ChevronLeft, ChevronRight,
  Clock, FileText, CheckSquare, Trash2, X, Check, GripVertical, RefreshCw,
} from "lucide-react";
import {
  DndContext,
  DragOverlay,
  PointerSensor,
  TouchSensor,
  useSensor,
  useSensors,
  useDroppable,
  useDraggable,
  DragStartEvent,
  DragEndEvent,
  DragOverEvent,
} from "@dnd-kit/core";
import { CSS } from "@dnd-kit/utilities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { usePlanner, EventColor, EventType, PlannerEvent } from "@/context/PlannerContext";
import { Recurrence } from "@/context/TodoContext";

// ─── colour config ────────────────────────────────────────────────────────────
const COLOR_CONFIG: Record<EventColor, { bg: string; text: string; dot: string; pill: string; ring: string }> = {
  sky:     { bg: "bg-sky-500",     text: "text-sky-600",     dot: "bg-sky-500",     pill: "bg-sky-100 text-sky-700",       ring: "ring-sky-400"     },
  violet:  { bg: "bg-violet-500",  text: "text-violet-600",  dot: "bg-violet-500",  pill: "bg-violet-100 text-violet-700", ring: "ring-violet-400"  },
  rose:    { bg: "bg-rose-500",    text: "text-rose-600",    dot: "bg-rose-500",    pill: "bg-rose-100 text-rose-700",     ring: "ring-rose-400"    },
  emerald: { bg: "bg-emerald-500", text: "text-emerald-600", dot: "bg-emerald-500", pill: "bg-emerald-100 text-emerald-700", ring: "ring-emerald-400" },
  amber:   { bg: "bg-amber-500",   text: "text-amber-600",   dot: "bg-amber-500",   pill: "bg-amber-100 text-amber-700",   ring: "ring-amber-400"   },
  orange:  { bg: "bg-orange-500",  text: "text-orange-600",  dot: "bg-orange-500",  pill: "bg-orange-100 text-orange-700", ring: "ring-orange-400"  },
};

const COLORS: EventColor[] = ["sky", "violet", "rose", "emerald", "amber", "orange"];
const DAYS = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"];
const MONTHS = [
  "January","February","March","April","May","June",
  "July","August","September","October","November","December",
];

function fmt(y: number, m: number, d: number) {
  return `${y}-${String(m + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
}
function todayStr() {
  const n = new Date();
  return fmt(n.getFullYear(), n.getMonth(), n.getDate());
}
function buildCalendarDays(year: number, month: number) {
  const first = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const cells: (number | null)[] = Array(first).fill(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);
  while (cells.length % 7 !== 0) cells.push(null);
  return cells;
}

// ─── Toast ────────────────────────────────────────────────────────────────────
function RescheduleToast({ message, onDone }: { message: string; onDone: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 32 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 32 }}
      onAnimationComplete={() => setTimeout(onDone, 1800)}
      className="absolute bottom-20 left-1/2 -translate-x-1/2 z-50 bg-foreground text-background text-xs font-semibold px-4 py-2 rounded-full shadow-xl whitespace-nowrap"
    >
      {message}
    </motion.div>
  );
}

// ─── Droppable calendar cell ──────────────────────────────────────────────────
function DroppableDay({
  dateStr, day, isToday, isSelected, dots, isOver,
  onClick,
}: {
  dateStr: string; day: number; isToday: boolean; isSelected: boolean;
  dots: EventColor[]; isOver: boolean; onClick: () => void;
}) {
  const { setNodeRef } = useDroppable({ id: dateStr });

  return (
    <div
      ref={setNodeRef}
      onClick={onClick}
      data-testid={`cal-day-${dateStr}`}
      className={`flex flex-col items-center py-1 rounded-xl transition-all cursor-pointer select-none ${
        isOver ? "bg-sky-50 ring-2 ring-sky-400 ring-inset scale-105" : ""
      }`}
    >
      <span
        className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium transition-all ${
          isSelected
            ? "bg-sky-500 text-white font-bold"
            : isToday
            ? "bg-sky-100 text-sky-700 font-bold"
            : "text-foreground hover:bg-muted"
        }`}
      >
        {day}
      </span>
      <div className="flex gap-0.5 mt-0.5 h-1.5">
        {dots.slice(0, 3).map((c, i) => (
          <span key={i} className={`w-1 h-1 rounded-full ${COLOR_CONFIG[c].dot}`} />
        ))}
      </div>
    </div>
  );
}

// ─── Draggable event card ─────────────────────────────────────────────────────
function DraggableEventCard({
  event, onToggle, onDelete,
}: {
  event: PlannerEvent; onToggle: () => void; onDelete: () => void;
}) {
  const { attributes, listeners, setNodeRef, transform, isDragging } =
    useDraggable({ id: event.id, data: { event } });

  const style = transform
    ? { transform: CSS.Translate.toString(transform) }
    : undefined;

  return (
    <motion.li
      ref={setNodeRef}
      style={style}
      layout
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: isDragging ? 0.35 : 1, y: 0 }}
      exit={{ opacity: 0, height: 0 }}
      className={`rounded-2xl border border-border bg-card overflow-hidden touch-none ${isDragging ? "shadow-2xl z-50" : ""}`}
      data-testid={`event-card-${event.id}`}
    >
      <EventCardContent
        event={event}
        onToggle={onToggle}
        onDelete={onDelete}
        dragHandleProps={{ ...attributes, ...listeners }}
      />
    </motion.li>
  );
}

// ─── Shared card content (used in both draggable card and DragOverlay) ────────
function EventCardContent({
  event, onToggle, onDelete, dragHandleProps, isOverlay,
}: {
  event: PlannerEvent;
  onToggle?: () => void;
  onDelete?: () => void;
  dragHandleProps?: Record<string, unknown>;
  isOverlay?: boolean;
}) {
  const [expanded, setExpanded] = useState(false);
  const cc = COLOR_CONFIG[event.color];

  const timeLabel = event.time
    ? new Date(`2000-01-01T${event.time}`).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })
    : null;

  return (
    <>
      <div className="flex items-center gap-2 p-4">
        {/* Drag handle */}
        <div
          {...(dragHandleProps ?? {})}
          className="flex items-center justify-center text-muted-foreground/40 hover:text-muted-foreground cursor-grab active:cursor-grabbing shrink-0 touch-none"
          data-testid={`drag-handle-${event.id}`}
        >
          <GripVertical className="w-4 h-4" />
        </div>

        {/* Color bar */}
        <div className={`w-1 self-stretch rounded-full ${cc.bg} shrink-0`} />

        {/* Toggle button */}
        {onToggle && (
          <button
            data-testid={`button-toggle-event-${event.id}`}
            onClick={onToggle}
            className={`w-7 h-7 rounded-full border-2 flex items-center justify-center shrink-0 transition-all ${
              event.completed ? `${cc.bg} border-transparent` : "border-border bg-background"
            }`}
          >
            {event.completed
              ? <Check className="w-3.5 h-3.5 text-white" strokeWidth={3} />
              : event.type === "event"
              ? <CalendarDays className={`w-3.5 h-3.5 ${cc.text}`} />
              : <CheckSquare className={`w-3.5 h-3.5 ${cc.text}`} />
            }
          </button>
        )}

        <div className="flex-1 min-w-0">
          <p className={`text-sm font-semibold leading-snug ${event.completed && !isOverlay ? "line-through text-muted-foreground" : "text-foreground"}`}>
            {event.title}
          </p>
          <div className="flex items-center gap-2 mt-1 flex-wrap">
            <span className={`text-[11px] font-medium px-2 py-0.5 rounded-full ${cc.pill}`}>
              {event.type === "event" ? "Event" : "Task"}
            </span>
            {timeLabel && (
              <span className="text-[11px] text-muted-foreground flex items-center gap-1">
                <Clock className="w-3 h-3" />{timeLabel}
              </span>
            )}
          </div>
        </div>

        {onDelete && !isOverlay && (
          <button
            data-testid={`button-expand-event-${event.id}`}
            onClick={() => setExpanded((v) => !v)}
            className="w-8 h-8 flex items-center justify-center text-muted-foreground rounded-lg hover:bg-muted shrink-0"
          >
            <ChevronRight className={`w-4 h-4 transition-transform ${expanded ? "rotate-90" : ""}`} />
          </button>
        )}
      </div>

      <AnimatePresence>
        {expanded && onDelete && !isOverlay && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4 pt-0 flex flex-col gap-2 border-t border-border/60">
              {event.notes && (
                <p className="text-xs text-muted-foreground mt-2 leading-relaxed">{event.notes}</p>
              )}
              <button
                data-testid={`button-delete-event-${event.id}`}
                onClick={onDelete}
                className="self-end flex items-center gap-1.5 text-xs font-medium text-rose-500 px-3 py-1.5 rounded-lg bg-rose-50 hover:bg-rose-100"
              >
                <Trash2 className="w-3.5 h-3.5" /> Delete
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

// ─── Main Planner component ───────────────────────────────────────────────────
export default function Planner() {
  const { events, addEvent, deleteEvent, toggleEvent, editEvent, getEventsForDate } = usePlanner();
  const now = new Date();
  const [viewYear, setViewYear]       = useState(now.getFullYear());
  const [viewMonth, setViewMonth]     = useState(now.getMonth());
  const [selectedDate, setSelectedDate] = useState(todayStr());
  const [showSheet, setShowSheet]     = useState(false);
  const [activeEvent, setActiveEvent] = useState<PlannerEvent | null>(null);
  const [overDate, setOverDate]       = useState<string | null>(null);
  const [toast, setToast]             = useState<string | null>(null);

  // sheet form
  const [newTitle, setNewTitle]   = useState("");
  const [newType, setNewType]     = useState<EventType>("event");
  const [newDate, setNewDate]     = useState(selectedDate);
  const [newTime, setNewTime]     = useState("");
  const [newColor, setNewColor]   = useState<EventColor>("sky");
  const [newNotes, setNewNotes]   = useState("");
  const [newRecurrence, setNewRecurrence] = useState<Recurrence>("none");

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 8 } }),
    useSensor(TouchSensor,   { activationConstraint: { delay: 200, tolerance: 8 } }),
  );

  const calCells = useMemo(() => buildCalendarDays(viewYear, viewMonth), [viewYear, viewMonth]);

  const dotMap = useMemo(() => {
    const map: Record<string, EventColor[]> = {};
    events.forEach((e) => {
      if (!map[e.date]) map[e.date] = [];
      if (map[e.date].length < 3) map[e.date].push(e.color);
    });
    return map;
  }, [events]);

  const selectedEvents = useMemo(() => getEventsForDate(selectedDate), [getEventsForDate, selectedDate]);

  const today = todayStr();

  // ── DnD handlers ──
  const handleDragStart = useCallback((e: DragStartEvent) => {
    const ev = (e.active.data.current as { event: PlannerEvent })?.event;
    if (ev) setActiveEvent(ev);
  }, []);

  const handleDragOver = useCallback((e: DragOverEvent) => {
    setOverDate(e.over ? String(e.over.id) : null);
  }, []);

  const handleDragEnd = useCallback((e: DragEndEvent) => {
    const { active, over } = e;
    setActiveEvent(null);
    setOverDate(null);

    if (!over) return;
    const targetDate = String(over.id);
    const ev = (active.data.current as { event: PlannerEvent })?.event;
    if (!ev || ev.date === targetDate) return;

    editEvent(ev.id, { date: targetDate });
    setSelectedDate(targetDate);

    // navigate calendar to the target month if needed
    const [ty, tm] = targetDate.split("-").map(Number);
    setViewYear(ty);
    setViewMonth(tm - 1);

    const label = new Date(targetDate + "T00:00:00").toLocaleDateString("en-US", {
      weekday: "short", month: "short", day: "numeric",
    });
    setToast(`Moved to ${label}`);
  }, [editEvent]);

  // ── Nav ──
  function prevMonth() {
    if (viewMonth === 0) { setViewYear((y) => y - 1); setViewMonth(11); }
    else setViewMonth((m) => m - 1);
  }
  function nextMonth() {
    if (viewMonth === 11) { setViewYear((y) => y + 1); setViewMonth(0); }
    else setViewMonth((m) => m + 1);
  }

  function openSheet(date: string) {
    setNewDate(date);
    setNewTitle(""); setNewType("event"); setNewTime("");
    setNewColor("sky"); setNewNotes(""); setNewRecurrence("none");
    setShowSheet(true);
  }

  function handleAdd() {
    if (!newTitle.trim()) return;
    addEvent({ title: newTitle.trim(), type: newType, date: newDate, time: newTime || null, color: newColor, notes: newNotes.trim() || null, recurrence: newRecurrence });
    setNewRecurrence("none");
    setShowSheet(false);
  }

  return (
    <DndContext
      sensors={sensors}
      onDragStart={handleDragStart}
      onDragOver={handleDragOver}
      onDragEnd={handleDragEnd}
    >
      <div className="flex flex-col h-full bg-background relative">
        {/* Header */}
        <div className="px-5 pt-12 pb-3 sticky top-0 bg-background/90 backdrop-blur-xl z-10 border-b border-border">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 bg-sky-100 rounded-xl flex items-center justify-center">
                <CalendarDays className="w-5 h-5 text-sky-600" />
              </div>
              <div>
                <h1 className="text-2xl font-bold leading-none">Planner</h1>
                {activeEvent && (
                  <motion.p
                    initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                    className="text-xs text-sky-600 font-medium mt-0.5"
                  >
                    Drop on a day to reschedule
                  </motion.p>
                )}
              </div>
            </div>
            <Button
              size="icon"
              data-testid="button-add-event"
              onClick={() => openSheet(selectedDate)}
              className="rounded-full w-10 h-10 bg-sky-500 hover:bg-sky-600 text-white shadow-md shadow-sky-200"
            >
              <Plus className="w-5 h-5" />
            </Button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto pb-28">
          {/* Month navigation */}
          <div className="px-5 pt-4 pb-2 flex items-center justify-between">
            <button data-testid="button-prev-month" onClick={prevMonth}
              className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-muted transition-colors">
              <ChevronLeft className="w-4 h-4 text-muted-foreground" />
            </button>
            <span className="font-bold text-base">{MONTHS[viewMonth]} {viewYear}</span>
            <button data-testid="button-next-month" onClick={nextMonth}
              className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-muted transition-colors">
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            </button>
          </div>

          {/* Day-of-week header */}
          <div className="grid grid-cols-7 px-3 mb-1">
            {DAYS.map((d) => (
              <div key={d} className="text-center text-[11px] font-semibold text-muted-foreground py-1">{d}</div>
            ))}
          </div>

          {/* Calendar grid — each day is a drop target */}
          <div className={`grid grid-cols-7 px-3 gap-y-1 transition-all ${activeEvent ? "pb-2" : ""}`}>
            {calCells.map((day, idx) => {
              if (day === null) return <div key={`empty-${idx}`} />;
              const dateStr = fmt(viewYear, viewMonth, day);
              return (
                <DroppableDay
                  key={dateStr}
                  dateStr={dateStr}
                  day={day}
                  isToday={dateStr === today}
                  isSelected={dateStr === selectedDate}
                  dots={dotMap[dateStr] ?? []}
                  isOver={overDate === dateStr}
                  onClick={() => setSelectedDate(dateStr)}
                />
              );
            })}
          </div>

          {/* Drag hint banner — appears when dragging */}
          <AnimatePresence>
            {activeEvent && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="mx-5 mt-2 rounded-2xl bg-sky-50 border border-sky-200 px-4 py-2.5 flex items-center gap-2"
              >
                <CalendarDays className="w-4 h-4 text-sky-500 shrink-0" />
                <p className="text-xs text-sky-700 font-medium">
                  Drag <span className="font-bold">"{activeEvent.title}"</span> onto any day to reschedule it
                </p>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Selected day events */}
          <div className="mt-4 px-5">
            <div className="flex items-center justify-between mb-3">
              <h2 className="font-bold text-base">
                {selectedDate === today
                  ? "Today"
                  : new Date(selectedDate + "T00:00:00").toLocaleDateString("en-US", {
                      weekday: "short", month: "short", day: "numeric",
                    })}
              </h2>
              <button onClick={() => openSheet(selectedDate)}
                className="text-xs font-semibold text-sky-600 flex items-center gap-1">
                <Plus className="w-3.5 h-3.5" /> Add
              </button>
            </div>

            {selectedEvents.length === 0 ? (
              <div className={`flex flex-col items-center py-8 gap-2 text-center rounded-2xl border-2 border-dashed transition-colors ${
                overDate === selectedDate ? "border-sky-400 bg-sky-50" : "border-border"
              }`}>
                <CalendarDays className={`w-6 h-6 ${overDate === selectedDate ? "text-sky-400" : "text-muted-foreground/30"}`} strokeWidth={1.5} />
                <p className="text-sm text-muted-foreground">
                  {overDate === selectedDate ? "Release to add here" : "Nothing scheduled"}
                </p>
              </div>
            ) : (
              <div className="space-y-2">
                <AnimatePresence initial={false}>
                  {selectedEvents.map((ev) => (
                    <DraggableEventCard
                      key={ev.id}
                      event={ev}
                      onToggle={() => toggleEvent(ev.id)}
                      onDelete={() => deleteEvent(ev.id)}
                    />
                  ))}
                </AnimatePresence>
              </div>
            )}
          </div>
        </div>

        {/* Drag overlay — floating preview */}
        <DragOverlay dropAnimation={{ duration: 180, easing: "ease" }}>
          {activeEvent && (
            <div className="rounded-2xl border-2 border-sky-400 bg-card shadow-2xl shadow-sky-200/60 overflow-hidden opacity-95 rotate-1 scale-105">
              <EventCardContent event={activeEvent} isOverlay />
            </div>
          )}
        </DragOverlay>

        {/* Toast */}
        <AnimatePresence>
          {toast && <RescheduleToast message={toast} onDone={() => setToast(null)} />}
        </AnimatePresence>

        {/* Add Event Sheet */}
        <AnimatePresence>
          {showSheet && (
            <>
              <motion.div
                initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                className="absolute inset-0 bg-black/40 z-20"
                onClick={() => setShowSheet(false)}
              />
              <motion.div
                initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }}
                transition={{ type: "spring", stiffness: 300, damping: 30 }}
                className="absolute bottom-0 left-0 right-0 bg-background rounded-t-3xl z-30 shadow-2xl max-h-[90%] overflow-y-auto"
              >
                <div className="flex items-center justify-between px-5 pt-5 pb-4 border-b border-border">
                  <h2 className="text-lg font-bold">New Entry</h2>
                  <button data-testid="button-close-sheet" onClick={() => setShowSheet(false)}
                    className="w-8 h-8 rounded-full bg-muted flex items-center justify-center">
                    <X className="w-4 h-4 text-muted-foreground" />
                  </button>
                </div>

                <div className="px-5 py-5 space-y-4 pb-8">
                  {/* Type toggle */}
                  <div className="flex gap-2 p-1 bg-muted rounded-xl">
                    {(["event", "task"] as EventType[]).map((t) => (
                      <button key={t} data-testid={`type-${t}`} onClick={() => setNewType(t)}
                        className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-sm font-semibold transition-all ${
                          newType === t ? "bg-background shadow-sm text-foreground" : "text-muted-foreground"
                        }`}>
                        {t === "event" ? <CalendarDays className="w-4 h-4" /> : <CheckSquare className="w-4 h-4" />}
                        {t === "event" ? "Event" : "Task"}
                      </button>
                    ))}
                  </div>

                  <Input data-testid="input-event-title"
                    placeholder={newType === "event" ? "Event name…" : "Task title…"}
                    value={newTitle} onChange={(e) => setNewTitle(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleAdd()}
                    className="h-12 text-base rounded-xl border-border bg-muted/40" autoFocus />

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <p className="text-xs font-medium text-muted-foreground mb-1.5 flex items-center gap-1">
                        <CalendarDays className="w-3.5 h-3.5" /> Date
                      </p>
                      <Input data-testid="input-event-date" type="date" value={newDate}
                        onChange={(e) => setNewDate(e.target.value)}
                        className="h-11 rounded-xl border-border bg-muted/40 text-sm" />
                    </div>
                    <div>
                      <p className="text-xs font-medium text-muted-foreground mb-1.5 flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5" /> Time (optional)
                      </p>
                      <Input data-testid="input-event-time" type="time" value={newTime}
                        onChange={(e) => setNewTime(e.target.value)}
                        className="h-11 rounded-xl border-border bg-muted/40 text-sm" />
                    </div>
                  </div>

                  <div>
                    <p className="text-xs font-medium text-muted-foreground mb-2">Colour</p>
                    <div className="flex gap-3">
                      {COLORS.map((c) => (
                        <button key={c} data-testid={`color-${c}`} onClick={() => setNewColor(c)}
                          className={`w-8 h-8 rounded-full ${COLOR_CONFIG[c].bg} flex items-center justify-center transition-transform ${
                            newColor === c ? "ring-2 ring-offset-2 ring-foreground/30 scale-110" : ""
                          }`}>
                          {newColor === c && <Check className="w-4 h-4 text-white" strokeWidth={3} />}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <p className="text-xs font-medium text-muted-foreground mb-1.5 flex items-center gap-1">
                      <FileText className="w-3.5 h-3.5" /> Notes (optional)
                    </p>
                    <textarea data-testid="input-event-notes" placeholder="Add a note…"
                      value={newNotes} onChange={(e) => setNewNotes(e.target.value)} rows={2}
                      className="w-full rounded-xl border border-border bg-muted/40 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-sky-400 resize-none" />
                  </div>

                  {/* Recurrence */}
                  <div>
                    <p className="text-xs font-medium text-muted-foreground mb-2 flex items-center gap-1">
                      <RefreshCw className="w-3.5 h-3.5" /> Repeat
                    </p>
                    <div className="flex gap-2">
                      {(["none", "daily", "weekly", "monthly"] as Recurrence[]).map((r) => (
                        <button
                          key={r}
                          onClick={() => setNewRecurrence(r)}
                          className={`flex-1 py-2 rounded-xl text-xs font-semibold border transition-all ${
                            newRecurrence === r
                              ? "bg-sky-500 text-white border-sky-500"
                              : "bg-muted/40 text-muted-foreground border-border"
                          }`}
                        >
                          {r === "none" ? "None" : r.charAt(0).toUpperCase() + r.slice(1)}
                        </button>
                      ))}
                    </div>
                  </div>

                  <Button data-testid="button-submit-event" onClick={handleAdd}
                    disabled={!newTitle.trim()}
                    className="w-full h-12 rounded-xl font-semibold text-base bg-sky-500 hover:bg-sky-600 text-white shadow-md shadow-sky-200 disabled:opacity-50">
                    Save
                  </Button>
                </div>
              </motion.div>
            </>
          )}
        </AnimatePresence>
      </div>
    </DndContext>
  );
}
