import { useState, useMemo, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  CheckSquare, Plus, Trash2, ChevronDown, X, Flag, CalendarDays, Tag,
  Check, SlidersHorizontal, RefreshCw, GripVertical, CheckCheck, ListChecks,
} from "lucide-react";
import {
  DndContext, closestCenter, PointerSensor, TouchSensor, useSensor, useSensors,
  DragEndEvent,
} from "@dnd-kit/core";
import {
  SortableContext, verticalListSortingStrategy, useSortable, arrayMove,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  useTodos, Priority, FilterStatus, SortBy, Recurrence,
  Todo as TodoType, Subtask,
} from "@/context/TodoContext";
import { useNotifications } from "@/context/NotificationsContext";
import { useSettings } from "@/context/SettingsContext";

const PRIORITY_CONFIG: Record<Priority, { label: string; color: string; dot: string }> = {
  high:   { label: "High",   color: "text-rose-600",    dot: "bg-rose-500"    },
  medium: { label: "Medium", color: "text-amber-600",   dot: "bg-amber-400"   },
  low:    { label: "Low",    color: "text-emerald-600", dot: "bg-emerald-500" },
};

const CATEGORIES = ["Work", "Personal", "Health", "Shopping", "Other"];

function priorityWeight(p: Priority) {
  return p === "high" ? 0 : p === "medium" ? 1 : 2;
}

// ─── Sortable wrapper ───────────────────────────────────────────────────────
function SortableTodoItem(props: TodoItemProps) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } =
    useSortable({ id: props.todo.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    zIndex: isDragging ? 50 : undefined,
    opacity: isDragging ? 0.85 : 1,
  };

  return (
    <div ref={setNodeRef} style={style} {...attributes}>
      <TodoItem {...props} dragListeners={listeners} isDragging={isDragging} />
    </div>
  );
}

// ─── Main page ───────────────────────────────────────────────────────────────
export default function Todo() {
  const {
    todos, addTodo, toggleTodo, deleteTodo, clearCompleted,
    reorderTodos, bulkComplete, bulkDelete,
  } = useTodos();
  const { fireNotification } = useNotifications();
  const { settings } = useSettings();

  function handleToggle(todo: TodoType) {
    toggleTodo(todo.id);
    if (!todo.completed && settings.notifyTaskComplete) {
      fireNotification({
        type: "task_complete",
        title: "Task completed! ✅",
        body: `"${todo.title}" marked as done.`,
      });
    }
  }

  const [filterStatus, setFilterStatus] = useState<FilterStatus>("all");
  const [filterPriority, setFilterPriority] = useState<Priority | "all">("all");
  const [filterCategory, setFilterCategory] = useState<string>("all");
  const [sortBy, setSortBy] = useState<SortBy>("manual");
  const [showFilters, setShowFilters] = useState(false);
  const [showAddSheet, setShowAddSheet] = useState(false);

  // Bulk-select state
  const [selectMode, setSelectMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  // New-task form
  const [newTitle, setNewTitle] = useState("");
  const [newPriority, setNewPriority] = useState<Priority>("medium");
  const [newCategory, setNewCategory] = useState("Personal");
  const [newDueDate, setNewDueDate] = useState("");
  const [newRecurrence, setNewRecurrence] = useState<Recurrence>("none");

  const allCategories = useMemo(() => {
    const cats = Array.from(new Set(todos.map((t) => t.category).filter(Boolean)));
    return ["all", ...cats];
  }, [todos]);

  const isFiltered =
    filterStatus !== "all" || filterPriority !== "all" || filterCategory !== "all";
  const isDragEnabled = sortBy === "manual" && !isFiltered;

  const filtered = useMemo(() => {
    let list = [...todos];
    if (filterStatus === "active")    list = list.filter((t) => !t.completed);
    if (filterStatus === "completed") list = list.filter((t) =>  t.completed);
    if (filterPriority !== "all")     list = list.filter((t) => t.priority === filterPriority);
    if (filterCategory !== "all")     list = list.filter((t) => t.category === filterCategory);

    if (sortBy === "priority") list.sort((a, b) => priorityWeight(a.priority) - priorityWeight(b.priority));
    else if (sortBy === "alpha")   list.sort((a, b) => a.title.localeCompare(b.title));
    else if (sortBy === "created") list.sort((a, b) => b.createdAt - a.createdAt);
    else if (sortBy === "dueDate") {
      list.sort((a, b) => {
        if (!a.dueDate && !b.dueDate) return 0;
        if (!a.dueDate) return 1;
        if (!b.dueDate) return -1;
        return a.dueDate.localeCompare(b.dueDate);
      });
    }
    // manual: preserve array order

    return list;
  }, [todos, filterStatus, filterPriority, filterCategory, sortBy]);

  const activeCount    = todos.filter((t) => !t.completed).length;
  const completedCount = todos.filter((t) =>  t.completed).length;

  function handleAdd() {
    if (!newTitle.trim()) return;
    addTodo({
      title: newTitle.trim(),
      priority: newPriority,
      category: newCategory,
      dueDate: newDueDate || null,
      recurrence: newRecurrence,
    });
    setNewTitle(""); setNewPriority("medium"); setNewCategory("Personal");
    setNewDueDate(""); setNewRecurrence("none");
    setShowAddSheet(false);
  }

  function enterSelectMode(firstId: string) {
    setSelectMode(true);
    setSelectedIds(new Set([firstId]));
  }

  function toggleSelect(id: string) {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }

  function exitSelectMode() {
    setSelectMode(false);
    setSelectedIds(new Set());
  }

  function handleBulkComplete() {
    bulkComplete(Array.from(selectedIds));
    exitSelectMode();
  }

  function handleBulkDelete() {
    bulkDelete(Array.from(selectedIds));
    exitSelectMode();
  }

  // DnD sensors — touch needs a short delay so scroll isn't blocked
  const sensors = useSensors(
    useSensor(TouchSensor, { activationConstraint: { delay: 200, tolerance: 8 } }),
    useSensor(PointerSensor, { activationConstraint: { distance: 6 } }),
  );

  function handleDragEnd(event: DragEndEvent) {
    const { active, over } = event;
    if (!over || active.id === over.id) return;
    const oldIdx = filtered.findIndex((t) => t.id === active.id);
    const newIdx = filtered.findIndex((t) => t.id === over.id);
    if (oldIdx === -1 || newIdx === -1) return;
    const reordered = arrayMove(filtered, oldIdx, newIdx);
    reorderTodos(reordered.map((t) => t.id));
  }

  const listContent = (
    <ul className="divide-y divide-border">
      {filtered.map((todo) =>
        isDragEnabled ? (
          <SortableTodoItem
            key={todo.id}
            todo={todo}
            onToggle={() => handleToggle(todo)}
            onDelete={() => deleteTodo(todo.id)}
            selectMode={selectMode}
            selected={selectedIds.has(todo.id)}
            onSelect={() => toggleSelect(todo.id)}
            onLongPress={() => enterSelectMode(todo.id)}
            showDragHandle={true}
          />
        ) : (
          <TodoItem
            key={todo.id}
            todo={todo}
            onToggle={() => handleToggle(todo)}
            onDelete={() => deleteTodo(todo.id)}
            selectMode={selectMode}
            selected={selectedIds.has(todo.id)}
            onSelect={() => toggleSelect(todo.id)}
            onLongPress={() => enterSelectMode(todo.id)}
            showDragHandle={false}
          />
        )
      )}
    </ul>
  );

  return (
    <div className="flex flex-col h-full bg-background">
      {/* Header */}
      <div className="px-5 pt-12 pb-3 sticky top-0 bg-background/90 backdrop-blur-xl z-10 border-b border-border">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-violet-100 rounded-xl flex items-center justify-center">
              <CheckSquare className="w-5 h-5 text-violet-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold leading-none">ToDo List</h1>
              <p className="text-xs text-muted-foreground mt-0.5">
                {activeCount} remaining · {completedCount} done
              </p>
            </div>
          </div>
          <div className="flex gap-2">
            {selectMode ? (
              <Button
                variant="ghost"
                size="icon"
                onClick={exitSelectMode}
                className="rounded-full w-10 h-10 border border-border bg-card"
              >
                <X className="w-4 h-4" />
              </Button>
            ) : (
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setShowFilters((v) => !v)}
                className={`rounded-full w-10 h-10 border border-border ${showFilters ? "bg-violet-100 text-violet-600 border-violet-200" : "bg-card"}`}
              >
                <SlidersHorizontal className="w-4 h-4" />
              </Button>
            )}
            <Button
              size="icon"
              onClick={() => setShowAddSheet(true)}
              className="rounded-full w-10 h-10 bg-violet-500 hover:bg-violet-600 text-white shadow-md shadow-violet-200"
            >
              <Plus className="w-5 h-5" />
            </Button>
          </div>
        </div>

        {/* Status tabs */}
        <div className="flex gap-1 p-1 bg-muted rounded-xl">
          {(["all", "active", "completed"] as FilterStatus[]).map((s) => (
            <button
              key={s}
              onClick={() => setFilterStatus(s)}
              className={`flex-1 py-1.5 text-xs font-semibold rounded-lg capitalize transition-all ${
                filterStatus === s ? "bg-background text-foreground shadow-sm" : "text-muted-foreground"
              }`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Filters */}
      <AnimatePresence>
        {showFilters && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden border-b border-border bg-muted/30"
          >
            <div className="px-5 py-4 space-y-3">
              <div>
                <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider mb-2">Priority</p>
                <div className="flex gap-2 flex-wrap">
                  {(["all", "high", "medium", "low"] as const).map((p) => (
                    <button key={p} onClick={() => setFilterPriority(p)}
                      className={`px-3 py-1 rounded-full text-xs font-medium border transition-all ${filterPriority === p ? "bg-violet-500 text-white border-violet-500" : "bg-background text-muted-foreground border-border"}`}>
                      {p === "all" ? "All" : PRIORITY_CONFIG[p].label}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider mb-2">Category</p>
                <div className="flex gap-2 flex-wrap">
                  {allCategories.map((c) => (
                    <button key={c} onClick={() => setFilterCategory(c)}
                      className={`px-3 py-1 rounded-full text-xs font-medium border transition-all ${filterCategory === c ? "bg-violet-500 text-white border-violet-500" : "bg-background text-muted-foreground border-border"}`}>
                      {c === "all" ? "All" : c}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider mb-2">Sort by</p>
                <div className="flex gap-2 flex-wrap">
                  {([
                    { value: "manual",   label: "Manual ↕" },
                    { value: "created",  label: "Newest"   },
                    { value: "priority", label: "Priority" },
                    { value: "dueDate",  label: "Due Date" },
                    { value: "alpha",    label: "A–Z"      },
                  ] as { value: SortBy; label: string }[]).map((opt) => (
                    <button key={opt.value} onClick={() => setSortBy(opt.value)}
                      className={`px-3 py-1 rounded-full text-xs font-medium border transition-all ${sortBy === opt.value ? "bg-violet-500 text-white border-violet-500" : "bg-background text-muted-foreground border-border"}`}>
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Hint bar when drag is enabled */}
      {isDragEnabled && !selectMode && (
        <div className="px-5 py-2 bg-violet-50 dark:bg-violet-900/10 border-b border-violet-100 dark:border-violet-800 flex items-center gap-2">
          <GripVertical className="w-3.5 h-3.5 text-violet-400" />
          <span className="text-[11px] text-violet-500 font-medium">Drag to reorder · Long-press to multi-select</span>
        </div>
      )}

      {/* Select-mode banner */}
      {selectMode && (
        <div className="px-5 py-2 bg-violet-50 dark:bg-violet-900/10 border-b border-violet-100 dark:border-violet-800 flex items-center gap-2">
          <CheckCheck className="w-3.5 h-3.5 text-violet-500" />
          <span className="text-[11px] text-violet-600 font-semibold">{selectedIds.size} selected — tap items to select</span>
        </div>
      )}

      {/* List */}
      <div className="flex-1 overflow-y-auto pb-28">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full gap-3 text-center px-8">
            <div className="w-16 h-16 bg-violet-100 rounded-2xl flex items-center justify-center">
              <Check className="w-8 h-8 text-violet-300" strokeWidth={1.5} />
            </div>
            <p className="font-semibold text-foreground">All clear!</p>
            <p className="text-sm text-muted-foreground">No tasks match the current filters.</p>
          </div>
        ) : isDragEnabled ? (
          <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
            <SortableContext items={filtered.map((t) => t.id)} strategy={verticalListSortingStrategy}>
              <AnimatePresence initial={false}>{listContent}</AnimatePresence>
            </SortableContext>
          </DndContext>
        ) : (
          <AnimatePresence initial={false}>{listContent}</AnimatePresence>
        )}

        {completedCount > 0 && filterStatus !== "active" && !selectMode && (
          <div className="px-5 py-4 flex justify-center">
            <button
              onClick={clearCompleted}
              className="text-xs text-muted-foreground font-medium hover:text-destructive transition-colors"
            >
              Clear {completedCount} completed task{completedCount > 1 ? "s" : ""}
            </button>
          </div>
        )}
      </div>

      {/* Bulk-action bar */}
      <AnimatePresence>
        {selectMode && selectedIds.size > 0 && (
          <motion.div
            initial={{ y: 80, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 80, opacity: 0 }}
            transition={{ type: "spring", stiffness: 300, damping: 28 }}
            className="absolute bottom-16 left-0 right-0 mx-4 bg-card border border-border rounded-2xl shadow-2xl p-3 flex gap-2 z-40"
          >
            <button
              onClick={handleBulkComplete}
              className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl bg-violet-500 text-white text-sm font-semibold shadow-sm shadow-violet-200"
            >
              <CheckCheck className="w-4 h-4" />
              Complete ({selectedIds.size})
            </button>
            <button
              onClick={handleBulkDelete}
              className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl bg-rose-500 text-white text-sm font-semibold shadow-sm shadow-rose-200"
            >
              <Trash2 className="w-4 h-4" />
              Delete ({selectedIds.size})
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Add Task Sheet */}
      <AnimatePresence>
        {showAddSheet && (
          <>
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/40 z-20"
              onClick={() => setShowAddSheet(false)}
            />
            <motion.div
              initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
              className="absolute bottom-0 left-0 right-0 bg-background rounded-t-3xl z-30 shadow-2xl"
            >
              <div className="flex items-center justify-between px-5 pt-5 pb-4 border-b border-border">
                <h2 className="text-lg font-bold">New Task</h2>
                <button onClick={() => setShowAddSheet(false)}
                  className="w-8 h-8 rounded-full bg-muted flex items-center justify-center">
                  <X className="w-4 h-4 text-muted-foreground" />
                </button>
              </div>

              <div className="px-5 py-5 space-y-4 pb-8">
                <Input
                  placeholder="What needs to be done?"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleAdd()}
                  className="h-12 text-base rounded-xl border-border bg-muted/40 focus:bg-background"
                  autoFocus
                />

                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Flag className="w-4 h-4 text-muted-foreground" />
                    <p className="text-sm font-medium text-muted-foreground">Priority</p>
                  </div>
                  <div className="flex gap-2">
                    {(["low", "medium", "high"] as Priority[]).map((p) => (
                      <button key={p} onClick={() => setNewPriority(p)}
                        className={`flex-1 py-2 rounded-xl text-sm font-semibold border transition-all ${
                          newPriority === p
                            ? p === "high"   ? "bg-rose-500 text-white border-rose-500"
                            : p === "medium" ? "bg-amber-500 text-white border-amber-500"
                            :                  "bg-emerald-500 text-white border-emerald-500"
                            : "bg-muted/40 text-muted-foreground border-border"
                        }`}>
                        {PRIORITY_CONFIG[p].label}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Tag className="w-4 h-4 text-muted-foreground" />
                    <p className="text-sm font-medium text-muted-foreground">Category</p>
                  </div>
                  <div className="flex gap-2 flex-wrap">
                    {CATEGORIES.map((c) => (
                      <button key={c} onClick={() => setNewCategory(c)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                          newCategory === c ? "bg-violet-500 text-white border-violet-500" : "bg-muted/40 text-muted-foreground border-border"
                        }`}>
                        {c}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <CalendarDays className="w-4 h-4 text-muted-foreground" />
                    <p className="text-sm font-medium text-muted-foreground">Due Date (optional)</p>
                  </div>
                  <Input
                    type="date"
                    value={newDueDate}
                    onChange={(e) => setNewDueDate(e.target.value)}
                    className="h-11 rounded-xl border-border bg-muted/40"
                  />
                </div>

                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <RefreshCw className="w-4 h-4 text-muted-foreground" />
                    <p className="text-sm font-medium text-muted-foreground">Repeat</p>
                  </div>
                  <div className="flex gap-2">
                    {(["none", "daily", "weekly", "monthly"] as Recurrence[]).map((r) => (
                      <button key={r} onClick={() => setNewRecurrence(r)}
                        className={`flex-1 py-2 rounded-xl text-xs font-semibold border transition-all ${
                          newRecurrence === r ? "bg-violet-500 text-white border-violet-500" : "bg-muted/40 text-muted-foreground border-border"
                        }`}>
                        {r === "none" ? "None" : r.charAt(0).toUpperCase() + r.slice(1)}
                      </button>
                    ))}
                  </div>
                </div>

                <Button
                  onClick={handleAdd}
                  disabled={!newTitle.trim()}
                  className="w-full h-12 rounded-xl font-semibold text-base bg-violet-500 hover:bg-violet-600 text-white shadow-md shadow-violet-200 disabled:opacity-50"
                >
                  Add Task
                </Button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}

// ─── TodoItem ─────────────────────────────────────────────────────────────────
interface TodoItemProps {
  todo: TodoType;
  onToggle: () => void;
  onDelete: () => void;
  selectMode: boolean;
  selected: boolean;
  onSelect: () => void;
  onLongPress: () => void;
  showDragHandle: boolean;
  dragListeners?: Record<string, unknown>;
  isDragging?: boolean;
}

function TodoItem({
  todo, onToggle, onDelete, selectMode, selected, onSelect, onLongPress,
  showDragHandle, dragListeners, isDragging,
}: TodoItemProps) {
  const { addSubtask, toggleSubtask, deleteSubtask } = useTodos();
  const [expanded, setExpanded] = useState(false);
  const [subtaskInput, setSubtaskInput] = useState("");

  const pc = PRIORITY_CONFIG[todo.priority];

  const isOverdue =
    !todo.completed && todo.dueDate &&
    todo.dueDate < new Date().toISOString().split("T")[0];

  const dueDateLabel = todo.dueDate
    ? new Date(todo.dueDate + "T00:00:00").toLocaleDateString("en-US", { month: "short", day: "numeric" })
    : null;

  const subtaskDone  = todo.subtasks.filter((s) => s.completed).length;
  const subtaskTotal = todo.subtasks.length;
  const subtaskPct   = subtaskTotal > 0 ? (subtaskDone / subtaskTotal) * 100 : 0;

  // Long-press detection
  const pressTimer  = useRef<ReturnType<typeof setTimeout>>();
  const pressStart  = useRef<{ x: number; y: number } | null>(null);
  const didLongPress = useRef(false);

  const onPressStart = (e: React.PointerEvent) => {
    if (selectMode) return;
    didLongPress.current = false;
    pressStart.current = { x: e.clientX, y: e.clientY };
    pressTimer.current = setTimeout(() => {
      didLongPress.current = true;
      onLongPress();
    }, 500);
  };

  const onPressMove = (e: React.PointerEvent) => {
    if (!pressStart.current) return;
    const dx = Math.abs(e.clientX - pressStart.current.x);
    const dy = Math.abs(e.clientY - pressStart.current.y);
    if (dx > 10 || dy > 10) {
      clearTimeout(pressTimer.current);
    }
  };

  const onPressEnd = () => {
    clearTimeout(pressTimer.current);
    pressStart.current = null;
  };

  function handleRowClick() {
    if (selectMode) { onSelect(); return; }
    if (didLongPress.current) return;
  }

  function handleAddSubtask() {
    if (!subtaskInput.trim()) return;
    addSubtask(todo.id, subtaskInput.trim());
    setSubtaskInput("");
  }

  return (
    <motion.li
      layout
      initial={{ opacity: 0, x: -16 }}
      animate={{ opacity: isDragging ? 0.85 : 1, x: 0, scale: isDragging ? 1.02 : 1 }}
      exit={{ opacity: 0, x: 16, height: 0 }}
      transition={{ duration: 0.2 }}
      className={`bg-card px-4 py-4 select-none transition-colors ${
        selected ? "bg-violet-50 dark:bg-violet-900/20" : ""
      } ${isDragging ? "shadow-lg rounded-xl" : ""}`}
      onPointerDown={onPressStart}
      onPointerMove={onPressMove}
      onPointerUp={onPressEnd}
      onPointerLeave={onPressEnd}
      onClick={handleRowClick}
    >
      <div className="flex items-start gap-3">
        {/* Drag handle or select circle */}
        {showDragHandle && !selectMode ? (
          <button
            {...(dragListeners as React.HTMLAttributes<HTMLButtonElement>)}
            className="mt-1 w-6 h-6 flex items-center justify-center text-muted-foreground/40 hover:text-muted-foreground cursor-grab active:cursor-grabbing shrink-0 touch-none"
            onClick={(e) => e.stopPropagation()}
          >
            <GripVertical className="w-4 h-4" />
          </button>
        ) : selectMode ? (
          <button
            onClick={(e) => { e.stopPropagation(); onSelect(); }}
            className={`mt-0.5 w-6 h-6 rounded-full border-2 flex items-center justify-center shrink-0 transition-all ${
              selected ? "bg-violet-500 border-violet-500" : "border-border bg-background"
            }`}
          >
            {selected && <Check className="w-3 h-3 text-white" strokeWidth={3} />}
          </button>
        ) : null}

        {/* Checkbox */}
        {!selectMode && (
          <button
            onClick={(e) => { e.stopPropagation(); onToggle(); }}
            className={`mt-0.5 w-6 h-6 rounded-full border-2 flex items-center justify-center shrink-0 transition-all ${
              todo.completed ? "bg-violet-500 border-violet-500" : "border-border bg-background"
            }`}
          >
            {todo.completed && <Check className="w-3.5 h-3.5 text-white" strokeWidth={3} />}
          </button>
        )}

        {/* Content */}
        <div className="flex-1 min-w-0">
          <p className={`text-sm font-medium leading-snug transition-all ${
            todo.completed ? "line-through text-muted-foreground" : "text-foreground"
          }`}>
            {todo.title}
          </p>

          <div className="flex items-center gap-2 mt-1.5 flex-wrap">
            <div className="flex items-center gap-1">
              <span className={`w-2 h-2 rounded-full ${pc.dot}`} />
              <span className={`text-[11px] font-medium ${pc.color}`}>{pc.label}</span>
            </div>
            {todo.category && (
              <span className="text-[11px] font-medium text-muted-foreground bg-muted px-2 py-0.5 rounded-full">
                {todo.category}
              </span>
            )}
            {dueDateLabel && (
              <span className={`text-[11px] font-medium px-2 py-0.5 rounded-full ${
                isOverdue ? "bg-rose-100 text-rose-600" : "bg-sky-50 text-sky-600"
              }`}>
                {isOverdue ? "Overdue · " : ""}{dueDateLabel}
              </span>
            )}
            {subtaskTotal > 0 && (
              <span className="flex items-center gap-1 text-[11px] text-muted-foreground">
                <ListChecks className="w-3 h-3" />
                {subtaskDone}/{subtaskTotal}
              </span>
            )}
          </div>

          {/* Subtask mini progress bar */}
          {subtaskTotal > 0 && (
            <div className="mt-2 h-1 bg-muted rounded-full overflow-hidden">
              <div
                className="h-full bg-violet-400 rounded-full transition-all duration-300"
                style={{ width: `${subtaskPct}%` }}
              />
            </div>
          )}
        </div>

        {/* Expand button (hidden in select mode) */}
        {!selectMode && (
          <button
            onClick={(e) => { e.stopPropagation(); setExpanded((v) => !v); }}
            className="w-8 h-8 flex items-center justify-center text-muted-foreground rounded-lg hover:bg-muted transition-colors shrink-0"
          >
            <ChevronDown className={`w-4 h-4 transition-transform ${expanded ? "rotate-180" : ""}`} />
          </button>
        )}
      </div>

      {/* Expanded section: subtasks + delete */}
      <AnimatePresence>
        {expanded && !selectMode && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.15 }}
            className="overflow-hidden"
          >
            <div className="pt-3 pl-9 space-y-3">
              {/* Subtask list */}
              {todo.subtasks.length > 0 && (
                <ul className="space-y-2">
                  {todo.subtasks.map((sub) => (
                    <li key={sub.id} className="flex items-center gap-2">
                      <button
                        onClick={() => toggleSubtask(todo.id, sub.id)}
                        className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 transition-all ${
                          sub.completed ? "bg-violet-400 border-violet-400" : "border-border bg-background"
                        }`}
                      >
                        {sub.completed && <Check className="w-2.5 h-2.5 text-white" strokeWidth={3} />}
                      </button>
                      <span className={`text-xs flex-1 ${sub.completed ? "line-through text-muted-foreground" : "text-foreground"}`}>
                        {sub.title}
                      </span>
                      <button
                        onClick={() => deleteSubtask(todo.id, sub.id)}
                        className="w-5 h-5 flex items-center justify-center text-muted-foreground hover:text-rose-500 transition-colors"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </li>
                  ))}
                </ul>
              )}

              {/* Add subtask */}
              <div className="flex items-center gap-2">
                <input
                  className="flex-1 text-xs h-8 px-3 rounded-lg bg-muted border border-border outline-none focus:border-violet-400 transition-colors placeholder:text-muted-foreground/60"
                  placeholder="Add a subtask…"
                  value={subtaskInput}
                  onChange={(e) => setSubtaskInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") { e.preventDefault(); handleAddSubtask(); }
                  }}
                />
                <button
                  onClick={handleAddSubtask}
                  disabled={!subtaskInput.trim()}
                  className="w-8 h-8 rounded-lg bg-violet-100 text-violet-600 flex items-center justify-center disabled:opacity-40 hover:bg-violet-200 transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Delete */}
              <div className="flex justify-end pt-1">
                <button
                  onClick={onDelete}
                  className="flex items-center gap-1.5 text-xs font-medium text-rose-500 hover:text-rose-700 transition-colors px-3 py-1.5 rounded-lg bg-rose-50 hover:bg-rose-100"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  Delete task
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.li>
  );
}
