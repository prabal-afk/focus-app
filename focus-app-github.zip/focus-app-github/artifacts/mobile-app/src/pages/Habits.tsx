import { useState, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Flame, Plus, X, Trash2, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useHabits } from "@/context/HabitContext";

const EMOJIS = ["🏃", "💧", "📚", "🧘", "🍎", "😴", "💪", "🎯", "✍️", "🧹", "🎵", "🌿", "☀️", "🧠", "💊", "🥗", "🚴", "🛁", "📝", "🙏"];

function HeatmapCell({ completed, date }: { completed: boolean; date: string }) {
  const d = new Date(date + "T00:00:00");
  const label = d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
  return (
    <div
      title={label}
      className={`w-5 h-5 rounded-sm transition-colors ${
        completed ? "bg-emerald-500" : "bg-muted"
      }`}
    />
  );
}

function HabitCard({ habitId }: { habitId: string }) {
  const { habits, deleteHabit, toggleHabitForDate, isCompletedForDate, getStreak, getLast30Days } = useHabits();
  const habit = habits.find((h) => h.id === habitId);
  if (!habit) return null;

  const todayStr = new Date().toISOString().split("T")[0];
  const doneToday = isCompletedForDate(habitId, todayStr);
  const streak = getStreak(habitId);
  const last30 = getLast30Days(habitId);
  const doneCount = last30.filter((d) => d.completed).length;

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8, height: 0 }}
      className="bg-card border border-border rounded-3xl p-5 shadow-sm"
    >
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 bg-emerald-100 rounded-2xl flex items-center justify-center text-xl">
            {habit.emoji}
          </div>
          <div>
            <p className="font-bold text-base text-foreground">{habit.name}</p>
            <div className="flex items-center gap-2 mt-0.5">
              {streak > 0 && (
                <span className="flex items-center gap-1 text-[11px] font-semibold text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full">
                  🔥 {streak} day{streak !== 1 ? "s" : ""}
                </span>
              )}
              <span className="text-[11px] text-muted-foreground">{doneCount}/30 this month</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => toggleHabitForDate(habitId, todayStr)}
            className={`w-10 h-10 rounded-2xl flex items-center justify-center transition-all shadow-sm ${
              doneToday
                ? "bg-emerald-500 text-white shadow-emerald-200"
                : "bg-muted text-muted-foreground border border-border"
            }`}
          >
            <Check className="w-5 h-5" strokeWidth={doneToday ? 3 : 2} />
          </button>
          <button
            onClick={() => deleteHabit(habitId)}
            className="w-8 h-8 rounded-xl flex items-center justify-center text-muted-foreground hover:text-rose-500 hover:bg-rose-50 transition-colors"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 30-day heatmap */}
      <div>
        <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-2">Last 30 days</p>
        <div className="grid grid-cols-[repeat(10,_1fr)] gap-1">
          {last30.map((item) => (
            <HeatmapCell key={item.date} completed={item.completed} date={item.date} />
          ))}
        </div>
        <div className="flex items-center justify-between mt-2">
          <span className="text-[10px] text-muted-foreground">30 days ago</span>
          <div className="flex items-center gap-1.5">
            <div className="w-3 h-3 rounded-sm bg-muted" />
            <span className="text-[10px] text-muted-foreground">None</span>
            <div className="w-3 h-3 rounded-sm bg-emerald-500 ml-1" />
            <span className="text-[10px] text-muted-foreground">Done</span>
          </div>
          <span className="text-[10px] text-muted-foreground">Today</span>
        </div>
      </div>
    </motion.div>
  );
}

export default function Habits() {
  const { habits, addHabit } = useHabits();
  const [showAdd, setShowAdd] = useState(false);
  const [newName, setNewName] = useState("");
  const [newEmoji, setNewEmoji] = useState("🎯");

  const todayStr = new Date().toISOString().split("T")[0];
  const { isCompletedForDate } = useHabits();
  const doneToday = habits.filter((h) => isCompletedForDate(h.id, todayStr)).length;

  function handleAdd() {
    if (!newName.trim()) return;
    addHabit(newName.trim(), newEmoji);
    setNewName("");
    setNewEmoji("🎯");
    setShowAdd(false);
  }

  return (
    <div className="flex flex-col h-full bg-background">
      {/* Header */}
      <div className="px-5 pt-12 pb-4 sticky top-0 bg-background/90 backdrop-blur-xl z-10 border-b border-border">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-emerald-100 rounded-xl flex items-center justify-center">
              <Flame className="w-5 h-5 text-emerald-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold leading-none">Habits</h1>
              <p className="text-xs text-muted-foreground mt-0.5">
                {habits.length === 0
                  ? "No habits yet"
                  : `${doneToday}/${habits.length} done today`}
              </p>
            </div>
          </div>
          <Button
            size="icon"
            onClick={() => setShowAdd(true)}
            className="rounded-full w-10 h-10 bg-emerald-500 hover:bg-emerald-600 text-white shadow-md shadow-emerald-200"
          >
            <Plus className="w-5 h-5" />
          </Button>
        </div>
      </div>

      {/* List */}
      <div className="flex-1 overflow-y-auto px-5 py-5 pb-28 space-y-4">
        {habits.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full gap-3 text-center px-8">
            <div className="w-16 h-16 bg-emerald-100 rounded-2xl flex items-center justify-center text-3xl">
              🎯
            </div>
            <p className="font-semibold text-foreground">No habits yet</p>
            <p className="text-sm text-muted-foreground">Tap + to add your first daily habit and start building streaks.</p>
          </div>
        ) : (
          <AnimatePresence initial={false}>
            {habits.map((h) => (
              <HabitCard key={h.id} habitId={h.id} />
            ))}
          </AnimatePresence>
        )}
      </div>

      {/* Add Sheet */}
      <AnimatePresence>
        {showAdd && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/40 z-20"
              onClick={() => setShowAdd(false)}
            />
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
              className="absolute bottom-0 left-0 right-0 bg-background rounded-t-3xl z-30 shadow-2xl"
            >
              <div className="flex items-center justify-between px-5 pt-5 pb-4 border-b border-border">
                <h2 className="text-lg font-bold">New Habit</h2>
                <button
                  onClick={() => setShowAdd(false)}
                  className="w-8 h-8 rounded-full bg-muted flex items-center justify-center"
                >
                  <X className="w-4 h-4 text-muted-foreground" />
                </button>
              </div>

              <div className="px-5 py-5 space-y-5 pb-8">
                <Input
                  placeholder="What habit do you want to build?"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleAdd()}
                  className="h-12 text-base rounded-xl border-border bg-muted/40 focus:bg-background"
                  autoFocus
                />

                <div>
                  <p className="text-sm font-medium text-muted-foreground mb-3">Pick an emoji</p>
                  <div className="grid grid-cols-[repeat(10,_1fr)] gap-2">
                    {EMOJIS.map((em) => (
                      <button
                        key={em}
                        onClick={() => setNewEmoji(em)}
                        className={`w-9 h-9 rounded-xl text-lg flex items-center justify-center transition-all ${
                          newEmoji === em
                            ? "bg-emerald-100 ring-2 ring-emerald-500"
                            : "bg-muted hover:bg-muted/70"
                        }`}
                      >
                        {em}
                      </button>
                    ))}
                  </div>
                </div>

                <Button
                  onClick={handleAdd}
                  disabled={!newName.trim()}
                  className="w-full h-12 rounded-xl font-semibold text-base bg-emerald-500 hover:bg-emerald-600 text-white shadow-md shadow-emerald-200 disabled:opacity-50"
                >
                  Add Habit
                </Button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
