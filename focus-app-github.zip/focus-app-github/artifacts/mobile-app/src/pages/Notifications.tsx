import { motion } from "framer-motion";
import { UserPlus, Star, Heart } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export default function Notifications() {
  const groups = [
    {
      title: "Today",
      items: [
        { id: 1, type: 'follow', user: "Sarah Jenkins", action: "started following you", time: "2h", icon: UserPlus, color: "text-blue-500 bg-blue-100" },
        { id: 2, type: 'like', user: "Mike Chen", action: "liked your post", time: "4h", icon: Heart, color: "text-red-500 bg-red-100" },
      ]
    },
    {
      title: "Yesterday",
      items: [
        { id: 3, type: 'star', user: "Design Team", action: "featured your design", time: "1d", icon: Star, color: "text-yellow-500 bg-yellow-100" },
        { id: 4, type: 'like', user: "Alex Lincoln", action: "liked your comment", time: "1d", icon: Heart, color: "text-red-500 bg-red-100" },
      ]
    }
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      className="flex flex-col h-full bg-background"
    >
      <div className="px-4 pt-12 pb-4 sticky top-0 bg-background/80 backdrop-blur-xl z-10 border-b border-border flex justify-between items-center">
        <h1 className="text-2xl font-bold">Notifications</h1>
        <button className="text-sm text-primary font-medium">Mark all read</button>
      </div>

      <div className="flex-1 overflow-y-auto pb-24">
        {groups.map((group) => (
          <div key={group.title} className="mb-6">
            <h2 className="px-4 py-3 text-sm font-semibold text-muted-foreground uppercase tracking-wider bg-muted/30">
              {group.title}
            </h2>
            <div className="divide-y divide-border">
              {group.items.map((item) => (
                <motion.div 
                  key={item.id}
                  whileTap={{ backgroundColor: "var(--elevate-1)" }}
                  className="flex gap-4 p-4 bg-card cursor-pointer transition-colors"
                >
                  <div className="relative shrink-0">
                    <Avatar className="w-12 h-12 border border-border">
                      <AvatarImage src={`https://i.pravatar.cc/150?u=${item.id + 20}`} />
                      <AvatarFallback>{item.user[0]}</AvatarFallback>
                    </Avatar>
                    <div className={`absolute -bottom-1 -right-1 w-5 h-5 rounded-full border-2 border-card flex items-center justify-center ${item.color}`}>
                      <item.icon className="w-3 h-3" />
                    </div>
                  </div>
                  <div className="flex-1 min-w-0 flex flex-col justify-center">
                    <p className="text-sm text-foreground leading-snug">
                      <span className="font-semibold">{item.user}</span> {item.action}
                    </p>
                    <p className="text-xs text-muted-foreground mt-0.5">{item.time}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </motion.div>
  );
}
