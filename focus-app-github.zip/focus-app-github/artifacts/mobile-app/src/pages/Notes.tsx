import { useState, useMemo, useRef, useEffect } from "react";
import { motion, AnimatePresence, useMotionValue, useTransform, useAnimation } from "framer-motion";
import {
  StickyNote, Plus, Search, X, Pin, PinOff, Trash2,
  LayoutGrid, List, Tag, Check, ChevronDown, Clock,
} from "lucide-react";
import { useNotes, NoteColor, Note } from "@/context/NotesContext";

// ─── Color config ─────────────────────────────────────────────────────────────
const COLOR_CFG: Record<NoteColor, { card: string; header: string; dot: string; label: string }> = {
  default: { card: "bg-card",        header: "bg-card",          dot: "bg-slate-400",   label: "Default"  },
  yellow:  { card: "bg-amber-50",    header: "bg-amber-100",     dot: "bg-amber-400",   label: "Yellow"   },
  rose:    { card: "bg-rose-50",     header: "bg-rose-100",      dot: "bg-rose-400",    label: "Rose"     },
  sky:     { card: "bg-sky-50",      header: "bg-sky-100",       dot: "bg-sky-400",     label: "Sky"      },
  emerald: { card: "bg-emerald-50",  header: "bg-emerald-100",   dot: "bg-emerald-400", label: "Emerald"  },
  violet:  { card: "bg-violet-50",   header: "bg-violet-100",    dot: "bg-violet-400",  label: "Violet"   },
};
const NOTE_COLORS: NoteColor[] = ["default", "yellow", "rose", "sky", "emerald", "violet"];

// ─── Helpers ──────────────────────────────────────────────────────────────────
function timeAgo(ts: number) {
  const diff = Date.now() - ts;
  const min = Math.floor(diff / 60000);
  if (min < 1)  return "just now";
  if (min < 60) return `${min}m ago`;
  const h = Math.floor(min / 60);
  if (h < 24)   return `${h}h ago`;
  const d = Math.floor(h / 24);
  if (d < 7)    return `${d}d ago`;
  return new Date(ts).toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

type SortKey = "updated" | "created" | "alpha";
const SORT_LABELS: Record<SortKey, string> = {
  updated: "Last edited", created: "Date created", alpha: "A → Z",
};

// ─── Tag chip ─────────────────────────────────────────────────────────────────
function TagChip({ label, active, onClick }: { label: string; active: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`shrink-0 px-3 py-1.5 rounded-full text-xs font-semibold border transition-all ${
        active
          ? "bg-amber-500 text-white border-amber-500 shadow-sm"
          : "bg-card border-border text-muted-foreground hover:border-amber-300"
      }`}
    >
      {label}
    </button>
  );
}

// ─── Centered delete dialog ────────────────────────────────────────────────────
function DeleteDialog({ note, onConfirm, onCancel }: { note: Note; onConfirm: () => void; onCancel: () => void }) {
  return (
    <AnimatePresence>
      <motion.div
        key="overlay"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="absolute inset-0 bg-black/50 z-50 flex items-center justify-center px-8"
        onClick={onCancel}
      >
        <motion.div
          key="dialog"
          initial={{ opacity: 0, scale: 0.88, y: 12 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.92, y: 8 }}
          transition={{ type: "spring", stiffness: 380, damping: 28 }}
          onClick={(e) => e.stopPropagation()}
          className="w-full max-w-xs bg-background rounded-3xl shadow-2xl overflow-hidden"
        >
          {/* Icon + heading */}
          <div className="flex flex-col items-center pt-8 pb-5 px-6 text-center">
            <div className="w-14 h-14 rounded-2xl bg-rose-100 flex items-center justify-center mb-4">
              <Trash2 className="w-7 h-7 text-rose-500" />
            </div>
            <p className="text-lg font-bold text-foreground leading-snug">Delete note?</p>
            {note.title && (
              <p className="text-sm text-muted-foreground mt-1 line-clamp-1">"{note.title}"</p>
            )}
            <p className="text-xs text-muted-foreground/70 mt-2">This can't be undone.</p>
          </div>

          {/* Divider + buttons */}
          <div className="border-t border-border flex">
            <button
              onClick={onCancel}
              className="flex-1 py-4 text-sm font-semibold text-foreground border-r border-border active:bg-muted transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={onConfirm}
              data-testid="button-confirm-delete-note"
              className="flex-1 py-4 text-sm font-bold text-rose-500 active:bg-rose-50 transition-colors"
            >
              Delete
            </button>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

// ─── Swipeable list row ────────────────────────────────────────────────────────
function SwipeableNoteRow({ note, onOpen, onDelete }: { note: Note; onOpen: () => void; onDelete: () => void }) {
  const x = useMotionValue(0);
  const deleteOpacity = useTransform(x, [-100, -40], [1, 0]);
  const controls = useAnimation();

  async function handleDragEnd() {
    if (x.get() < -80) {
      await controls.start({ x: -100 });
    } else {
      controls.start({ x: 0 });
    }
  }

  const cc = COLOR_CFG[note.color];

  return (
    <div className="relative overflow-hidden rounded-2xl">
      {/* Red delete background */}
      <div className="absolute inset-0 bg-rose-500 flex items-center justify-end pr-5 rounded-2xl">
        <motion.div style={{ opacity: deleteOpacity }} className="flex flex-col items-center gap-1">
          <Trash2 className="w-5 h-5 text-white" />
          <span className="text-[10px] font-bold text-white">Delete</span>
        </motion.div>
      </div>

      {/* Card */}
      <motion.div
        drag="x"
        dragConstraints={{ left: -110, right: 0 }}
        dragElastic={{ left: 0.1, right: 0 }}
        animate={controls}
        style={{ x }}
        onDragEnd={handleDragEnd}
        onClick={() => { if (Math.abs(x.get()) < 5) onOpen(); else controls.start({ x: 0 }); }}
        className={`${cc.card} border border-border/60 rounded-2xl p-3 flex items-start gap-3 cursor-pointer relative`}
      >
        {/* Color accent */}
        {note.color !== "default" && (
          <div className={`w-1 self-stretch rounded-full ${cc.dot} shrink-0`} />
        )}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-0.5">
            {note.pinned && <Pin className="w-3 h-3 text-amber-500 shrink-0" />}
            {note.title && (
              <p className="font-bold text-sm text-foreground line-clamp-1">{note.title}</p>
            )}
          </div>
          {note.body && (
            <p className="text-xs text-muted-foreground leading-relaxed line-clamp-2">{note.body}</p>
          )}
          <div className="flex items-center gap-2 mt-1.5">
            <span className="text-[10px] text-muted-foreground/60 flex items-center gap-1">
              <Clock className="w-2.5 h-2.5" />{timeAgo(note.updatedAt)}
            </span>
            {note.tags.slice(0, 2).map((t) => (
              <span key={t} className="text-[10px] font-medium px-1.5 py-0.5 rounded-full bg-black/5 text-foreground/60">#{t}</span>
            ))}
          </div>
        </div>
        {/* Direct delete button */}
        <button
          onPointerDown={(e) => e.stopPropagation()}
          onClick={(e) => { e.stopPropagation(); onDelete(); }}
          className="w-8 h-8 rounded-full flex items-center justify-center text-muted-foreground hover:bg-rose-50 hover:text-rose-500 transition-colors shrink-0 self-center"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </motion.div>
    </div>
  );
}

// ─── Grid note card ─────────────────────────────────────────────────────────
function GridNoteCard({ note, onOpen, onDelete }: { note: Note; onOpen: () => void; onDelete: () => void }) {
  const [showActions, setShowActions] = useState(false);
  const cc = COLOR_CFG[note.color];
  const longPressTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  function startPress() {
    longPressTimer.current = setTimeout(() => setShowActions(true), 420);
  }
  function cancelPress() {
    if (longPressTimer.current) clearTimeout(longPressTimer.current);
  }

  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.92 }}
      className={`${cc.card} rounded-2xl border border-border/60 overflow-hidden cursor-pointer active:shadow-md transition-shadow relative`}
      onPointerDown={startPress}
      onPointerUp={cancelPress}
      onPointerLeave={cancelPress}
      onClick={() => { if (!showActions) onOpen(); }}
      data-testid={`note-card-${note.id}`}
    >
      {/* Color header stripe */}
      {note.color !== "default" && (
        <div className={`${cc.header} px-3 pt-2.5 pb-1.5 flex items-center justify-between`}>
          {note.pinned ? <Pin className="w-3 h-3 text-amber-500" /> : <span />}
          <span className={`w-2 h-2 rounded-full ${cc.dot}`} />
        </div>
      )}
      <div className={`p-3 ${note.color !== "default" ? "pt-1.5" : "pt-3"}`}>
        {note.color === "default" && note.pinned && (
          <Pin className="w-3.5 h-3.5 text-amber-500 mb-1.5" />
        )}
        {note.title && (
          <p className="font-bold text-sm text-foreground leading-snug mb-1 line-clamp-2">{note.title}</p>
        )}
        {note.body && (
          <p className="text-xs text-muted-foreground leading-relaxed line-clamp-4">{note.body}</p>
        )}
        {note.tags.length > 0 && (
          <div className="flex flex-wrap gap-1 mt-2">
            {note.tags.slice(0, 3).map((t) => (
              <span key={t} className="text-[10px] font-medium px-1.5 py-0.5 rounded-full bg-black/5 text-foreground/60">#{t}</span>
            ))}
          </div>
        )}
        <p className="text-[10px] text-muted-foreground/60 mt-2 flex items-center gap-1">
          <Clock className="w-2.5 h-2.5" />{timeAgo(note.updatedAt)}
        </p>
      </div>

      {/* Quick-action overlay on long press */}
      <AnimatePresence>
        {showActions && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black/30 backdrop-blur-[2px] rounded-2xl flex items-center justify-center gap-3"
            onClick={(e) => { e.stopPropagation(); setShowActions(false); }}
          >
            <motion.button
              initial={{ scale: 0.7 }} animate={{ scale: 1 }} exit={{ scale: 0.7 }}
              onClick={(e) => { e.stopPropagation(); setShowActions(false); onOpen(); }}
              className="w-11 h-11 rounded-full bg-white/90 flex items-center justify-center shadow-lg"
            >
              <Check className="w-5 h-5 text-foreground" />
            </motion.button>
            <motion.button
              initial={{ scale: 0.7 }} animate={{ scale: 1 }} exit={{ scale: 0.7 }}
              transition={{ delay: 0.04 }}
              onClick={(e) => { e.stopPropagation(); setShowActions(false); onDelete(); }}
              className="w-11 h-11 rounded-full bg-rose-500 flex items-center justify-center shadow-lg"
            >
              <Trash2 className="w-5 h-5 text-white" />
            </motion.button>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

// ─── Editor sheet ─────────────────────────────────────────────────────────────
function NoteEditor({
  note, onClose, onDelete,
}: {
  note: Note | null;
  onClose: (saved?: Partial<Note>) => void;
  onDelete?: () => void;
}) {
  const [title, setTitle]     = useState(note?.title ?? "");
  const [body, setBody]       = useState(note?.body ?? "");
  const [color, setColor]     = useState<NoteColor>(note?.color ?? "default");
  const [pinned, setPinned]   = useState(note?.pinned ?? false);
  const [tags, setTags]       = useState<string[]>(note?.tags ?? []);
  const [tagInput, setTagInput] = useState("");

  const bodyRef = useRef<HTMLTextAreaElement>(null);
  const wordCount = body.trim() ? body.trim().split(/\s+/).length : 0;
  const charCount = body.length;

  useEffect(() => {
    if (bodyRef.current) {
      bodyRef.current.style.height = "auto";
      bodyRef.current.style.height = bodyRef.current.scrollHeight + "px";
    }
  }, [body]);

  function addTag() {
    const t = tagInput.trim().toLowerCase().replace(/\s+/g, "-");
    if (t && !tags.includes(t)) setTags((prev) => [...prev, t]);
    setTagInput("");
  }

  function removeTag(t: string) { setTags((prev) => prev.filter((x) => x !== t)); }

  function save() {
    if (!title.trim() && !body.trim()) { onClose(); return; }
    onClose({ title, body, color, pinned, tags });
  }

  const cc = COLOR_CFG[color];

  return (
    <>
      <motion.div
        initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
        className="absolute inset-0 bg-black/40 z-20"
        onClick={save}
      />
      <motion.div
        initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
        className={`absolute bottom-0 left-0 right-0 ${cc.card} rounded-t-3xl z-30 shadow-2xl max-h-[92%] flex flex-col`}
      >
        {/* Toolbar */}
        <div className={`${cc.header} rounded-t-3xl px-4 pt-4 pb-3 border-b border-border/40 flex items-center justify-between gap-3`}>
          <div className="flex items-center gap-2">
            <div className="flex gap-1.5">
              {NOTE_COLORS.map((c) => (
                <button key={c} onClick={() => setColor(c)}
                  className={`w-5 h-5 rounded-full ${COLOR_CFG[c].dot} transition-all ${color === c ? "ring-2 ring-offset-1 ring-foreground/40 scale-110" : "opacity-60 hover:opacity-100"}`}
                />
              ))}
            </div>
          </div>
          <div className="flex items-center gap-1">
            <button onClick={() => setPinned((p) => !p)}
              className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors ${pinned ? "bg-amber-100 text-amber-500" : "text-muted-foreground hover:bg-muted"}`}>
              {pinned ? <Pin className="w-4 h-4" /> : <PinOff className="w-4 h-4" />}
            </button>
            {onDelete && (
              <button onClick={onDelete}
                className="w-8 h-8 rounded-full flex items-center justify-center text-muted-foreground hover:bg-rose-50 hover:text-rose-500 transition-colors">
                <Trash2 className="w-4 h-4" />
              </button>
            )}
            <button onClick={save}
              className="w-8 h-8 rounded-full bg-amber-500 flex items-center justify-center text-white shadow-sm" data-testid="button-save-note">
              <Check className="w-4 h-4" strokeWidth={3} />
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-3">
          <input
            data-testid="input-note-title"
            placeholder="Title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full bg-transparent text-xl font-bold text-foreground placeholder:text-muted-foreground/40 focus:outline-none"
          />
          <textarea
            ref={bodyRef}
            data-testid="input-note-body"
            placeholder="Start writing…"
            value={body}
            onChange={(e) => setBody(e.target.value)}
            className="w-full bg-transparent text-sm text-foreground leading-relaxed placeholder:text-muted-foreground/40 focus:outline-none resize-none min-h-[120px]"
          />

          {/* Tags */}
          <div className="border-t border-border/40 pt-3">
            <div className="flex items-center gap-2 flex-wrap mb-2">
              <Tag className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
              {tags.map((t) => (
                <span key={t}
                  className="flex items-center gap-1 text-xs font-medium px-2 py-0.5 rounded-full bg-amber-100 text-amber-700">
                  #{t}
                  <button onClick={() => removeTag(t)}><X className="w-2.5 h-2.5" /></button>
                </span>
              ))}
              <input
                data-testid="input-note-tag"
                placeholder="Add tag…"
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter" || e.key === ",") { e.preventDefault(); addTag(); } }}
                onBlur={addTag}
                className="text-xs text-foreground placeholder:text-muted-foreground/40 bg-transparent focus:outline-none w-20 min-w-0"
              />
            </div>
            <p className="text-[10px] text-muted-foreground/50">
              {wordCount} word{wordCount !== 1 ? "s" : ""} · {charCount} char{charCount !== 1 ? "s" : ""}
            </p>
          </div>
        </div>
      </motion.div>
    </>
  );
}

// ─── Main Notes page ──────────────────────────────────────────────────────────
export default function Notes() {
  const { notes, allTags, addNote, updateNote, deleteNote } = useNotes();
  const [search, setSearch]       = useState("");
  const [showSearch, setShowSearch] = useState(false);
  const [activeTag, setActiveTag] = useState<string | null>(null);
  const [activeColor, setActiveColor] = useState<NoteColor | null>(null);
  const [filterPinned, setFilterPinned] = useState(false);
  const [sortKey, setSortKey]     = useState<SortKey>("updated");
  const [showSort, setShowSort]   = useState(false);
  const [gridView, setGridView]   = useState(true);
  const [editingNote, setEditingNote] = useState<Note | null | "new">(null);
  const [deleteTarget, setDeleteTarget] = useState<Note | null>(null);

  const filtered = useMemo(() => {
    let list = [...notes];
    if (filterPinned) list = list.filter((n) => n.pinned);
    if (activeTag)    list = list.filter((n) => n.tags.includes(activeTag));
    if (activeColor)  list = list.filter((n) => n.color === activeColor);
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      list = list.filter((n) =>
        n.title.toLowerCase().includes(q) ||
        n.body.toLowerCase().includes(q) ||
        n.tags.some((t) => t.includes(q))
      );
    }
    list.sort((a, b) => {
      if (sortKey === "alpha") return a.title.localeCompare(b.title);
      if (sortKey === "created") return b.createdAt - a.createdAt;
      return b.updatedAt - a.updatedAt;
    });
    return [
      ...list.filter((n) => n.pinned),
      ...list.filter((n) => !n.pinned),
    ];
  }, [notes, filterPinned, activeTag, activeColor, search, sortKey]);

  function openNew() { setEditingNote("new"); }

  function handleEditorClose(saved?: Partial<Note>) {
    if (saved) {
      if (editingNote === "new") {
        addNote({ title: saved.title ?? "", body: saved.body ?? "", color: saved.color ?? "default", tags: saved.tags ?? [], pinned: saved.pinned ?? false });
      } else if (editingNote) {
        updateNote((editingNote as Note).id, saved);
      }
    }
    setEditingNote(null);
  }

  function confirmDelete(note: Note) {
    setEditingNote(null);
    setDeleteTarget(note);
  }

  function handleDeleteConfirm() {
    if (deleteTarget) deleteNote(deleteTarget.id);
    setDeleteTarget(null);
  }

  const editNote = editingNote === "new" ? null : (editingNote as Note | null);
  const hasFilters = filterPinned || activeTag || activeColor || search;

  return (
    <div className="flex flex-col h-full bg-background relative overflow-hidden">
      {/* ── Header ── */}
      <div className="px-5 pt-12 pb-3 sticky top-0 bg-background/90 backdrop-blur-xl z-10 border-b border-border">
        <div className="flex items-center justify-between gap-3">
          {showSearch ? (
            <motion.div
              initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}
              className="flex-1 flex items-center gap-2 bg-muted rounded-2xl px-3 h-10"
            >
              <Search className="w-4 h-4 text-muted-foreground shrink-0" />
              <input
                autoFocus
                data-testid="input-search-notes"
                placeholder="Search notes…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="flex-1 bg-transparent text-sm focus:outline-none placeholder:text-muted-foreground/50"
              />
              {search && (
                <button onClick={() => setSearch("")}><X className="w-4 h-4 text-muted-foreground" /></button>
              )}
            </motion.div>
          ) : (
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 bg-amber-100 rounded-xl flex items-center justify-center">
                <StickyNote className="w-5 h-5 text-amber-600" />
              </div>
              <div>
                <h1 className="text-2xl font-bold leading-none">Notes</h1>
                <p className="text-[11px] text-muted-foreground mt-0.5">{notes.length} note{notes.length !== 1 ? "s" : ""}</p>
              </div>
            </div>
          )}
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              data-testid="button-toggle-search"
              onClick={() => { setShowSearch((v) => !v); if (showSearch) setSearch(""); }}
              className={`w-9 h-9 rounded-full flex items-center justify-center transition-colors ${showSearch ? "bg-amber-100 text-amber-600" : "bg-muted text-muted-foreground"}`}
            >
              {showSearch ? <X className="w-4 h-4" /> : <Search className="w-4 h-4" />}
            </button>
            <button
              data-testid="button-toggle-view"
              onClick={() => setGridView((v) => !v)}
              className="w-9 h-9 rounded-full bg-muted flex items-center justify-center text-muted-foreground"
            >
              {gridView ? <List className="w-4 h-4" /> : <LayoutGrid className="w-4 h-4" />}
            </button>
            <button
              data-testid="button-add-note"
              onClick={openNew}
              className="w-10 h-10 rounded-full bg-amber-500 hover:bg-amber-600 flex items-center justify-center text-white shadow-md shadow-amber-200"
            >
              <Plus className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* ── Filter bar ── */}
      <div className="flex gap-2 items-center px-5 py-3 overflow-x-auto scrollbar-hide border-b border-border bg-background/80">
        <div className="relative shrink-0">
          <button
            onClick={() => setShowSort((v) => !v)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold bg-card border border-border text-muted-foreground"
          >
            {SORT_LABELS[sortKey]}
            <ChevronDown className={`w-3 h-3 transition-transform ${showSort ? "rotate-180" : ""}`} />
          </button>
          <AnimatePresence>
            {showSort && (
              <motion.div
                initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -4 }}
                className="absolute top-9 left-0 bg-card border border-border rounded-2xl shadow-xl z-50 w-40 overflow-hidden"
              >
                {(Object.keys(SORT_LABELS) as SortKey[]).map((k) => (
                  <button key={k} onClick={() => { setSortKey(k); setShowSort(false); }}
                    className={`w-full text-left px-4 py-2.5 text-xs font-medium transition-colors ${sortKey === k ? "bg-amber-50 text-amber-600" : "text-foreground hover:bg-muted"}`}>
                    {SORT_LABELS[k]}
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="w-px h-4 bg-border shrink-0" />

        <TagChip
          label="All"
          active={!filterPinned && !activeTag && !activeColor}
          onClick={() => { setFilterPinned(false); setActiveTag(null); setActiveColor(null); }}
        />
        <TagChip label="📌 Pinned" active={filterPinned} onClick={() => { setFilterPinned((v) => !v); setActiveTag(null); setActiveColor(null); }} />
        {allTags.map((t) => (
          <TagChip key={t} label={`#${t}`} active={activeTag === t}
            onClick={() => { setActiveTag(activeTag === t ? null : t); setFilterPinned(false); setActiveColor(null); }} />
        ))}
        {NOTE_COLORS.filter((c) => c !== "default").map((c) => (
          <button key={c} onClick={() => { setActiveColor(activeColor === c ? null : c); setFilterPinned(false); setActiveTag(null); }}
            className={`shrink-0 w-6 h-6 rounded-full ${COLOR_CFG[c].dot} transition-all ${activeColor === c ? "ring-2 ring-offset-2 ring-foreground/30 scale-110" : "opacity-60 hover:opacity-100"}`}
          />
        ))}
      </div>

      {/* ── Note list/grid ── */}
      <div className="flex-1 overflow-y-auto pb-28 px-4 pt-4">
        {hasFilters && (
          <div className="flex items-center gap-2 mb-3">
            <p className="text-xs text-muted-foreground">{filtered.length} result{filtered.length !== 1 ? "s" : ""}</p>
            <button onClick={() => { setSearch(""); setActiveTag(null); setActiveColor(null); setFilterPinned(false); }}
              className="text-xs text-amber-600 font-medium flex items-center gap-1">
              <X className="w-3 h-3" /> Clear filters
            </button>
          </div>
        )}

        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 gap-4 text-center">
            <div className="w-16 h-16 bg-amber-50 rounded-3xl flex items-center justify-center">
              <StickyNote className="w-8 h-8 text-amber-200" strokeWidth={1.5} />
            </div>
            <div>
              <p className="font-semibold text-foreground">
                {hasFilters ? "No matching notes" : "No notes yet"}
              </p>
              <p className="text-sm text-muted-foreground mt-1">
                {hasFilters ? "Try different filters or search terms." : "Tap + to write your first note."}
              </p>
            </div>
          </div>
        ) : gridView ? (
          // ── 2-column grid with long-press delete ──
          <div className="columns-2 gap-3 space-y-3">
            <AnimatePresence>
              {filtered.map((note) => (
                <div key={note.id} className="break-inside-avoid mb-3">
                  <GridNoteCard
                    note={note}
                    onOpen={() => setEditingNote(note)}
                    onDelete={() => confirmDelete(note)}
                  />
                </div>
              ))}
            </AnimatePresence>
          </div>
        ) : (
          // ── List view with swipe-to-delete ──
          <AnimatePresence>
            <div className="space-y-2">
              {filtered.map((note) => (
                <SwipeableNoteRow
                  key={note.id}
                  note={note}
                  onOpen={() => setEditingNote(note)}
                  onDelete={() => confirmDelete(note)}
                />
              ))}
            </div>
          </AnimatePresence>
        )}
      </div>

      {/* ── Editor sheet ── */}
      <AnimatePresence>
        {editingNote !== null && (
          <NoteEditor
            note={editNote}
            onClose={handleEditorClose}
            onDelete={editNote ? () => confirmDelete(editNote) : undefined}
          />
        )}
      </AnimatePresence>

      {/* ── Centered delete dialog ── */}
      <AnimatePresence>
        {deleteTarget && (
          <DeleteDialog
            note={deleteTarget}
            onConfirm={handleDeleteConfirm}
            onCancel={() => setDeleteTarget(null)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
