import { motion } from "framer-motion";
import { Settings, Shield, Bell, Key, CircleHelp, LogOut, ChevronRight } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";

export default function Profile() {
  const menuItems = [
    { icon: Settings, label: "Account Settings" },
    { icon: Shield, label: "Privacy & Security" },
    { icon: Bell, label: "Notifications" },
    { icon: Key, label: "Passwords" },
    { icon: CircleHelp, label: "Help & Support" },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      className="flex flex-col h-full bg-background"
    >
      <div className="px-4 pt-12 pb-4 sticky top-0 bg-background/80 backdrop-blur-xl z-10 border-b border-border flex justify-between items-center">
        <h1 className="text-2xl font-bold">Profile</h1>
        <Button variant="ghost" size="icon" className="rounded-full w-8 h-8">
          <Settings className="w-5 h-5" />
        </Button>
      </div>

      <div className="flex-1 overflow-y-auto pb-24">
        {/* Header */}
        <div className="flex flex-col items-center py-8 px-4 border-b border-border bg-card">
          <div className="relative">
            <Avatar className="w-24 h-24 border-4 border-background shadow-sm">
              <AvatarImage src="https://i.pravatar.cc/150?u=a042581f4e29026024d" />
              <AvatarFallback>AL</AvatarFallback>
            </Avatar>
            <div className="absolute bottom-0 right-0 w-6 h-6 bg-primary rounded-full border-2 border-background flex items-center justify-center">
              <div className="w-2 h-2 bg-white rounded-full" />
            </div>
          </div>
          <h2 className="mt-4 text-xl font-bold">Alex Lincoln</h2>
          <p className="text-muted-foreground text-sm">@alexlincoln</p>
          
          <div className="flex gap-8 mt-6 w-full max-w-xs">
            <div className="flex flex-col items-center flex-1">
              <span className="font-bold text-lg">142</span>
              <span className="text-xs text-muted-foreground font-medium uppercase tracking-wider">Posts</span>
            </div>
            <div className="w-px bg-border" />
            <div className="flex flex-col items-center flex-1">
              <span className="font-bold text-lg">8.2k</span>
              <span className="text-xs text-muted-foreground font-medium uppercase tracking-wider">Followers</span>
            </div>
            <div className="w-px bg-border" />
            <div className="flex flex-col items-center flex-1">
              <span className="font-bold text-lg">431</span>
              <span className="text-xs text-muted-foreground font-medium uppercase tracking-wider">Following</span>
            </div>
          </div>
        </div>

        {/* Menu */}
        <div className="p-4 space-y-6">
          <div className="bg-card rounded-2xl border border-border overflow-hidden shadow-sm">
            {menuItems.map((item, index) => (
              <motion.button
                key={item.label}
                whileTap={{ backgroundColor: "var(--elevate-1)" }}
                className={`w-full flex items-center gap-4 p-4 text-left transition-colors ${
                  index !== menuItems.length - 1 ? "border-b border-border" : ""
                }`}
              >
                <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center shrink-0">
                  <item.icon className="w-4 h-4" />
                </div>
                <span className="font-medium flex-1">{item.label}</span>
                <ChevronRight className="w-4 h-4 text-muted-foreground" />
              </motion.button>
            ))}
          </div>

          <Button variant="destructive" className="w-full rounded-xl h-12 font-semibold">
            <LogOut className="w-4 h-4 mr-2" />
            Log Out
          </Button>
        </div>
      </div>
    </motion.div>
  );
}
