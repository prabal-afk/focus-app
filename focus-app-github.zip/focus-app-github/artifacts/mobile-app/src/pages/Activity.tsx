import { motion } from "framer-motion";
import { Heart, MessageCircle, Share2, MoreHorizontal } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export default function Activity() {
  const posts = Array.from({ length: 5 }).map((_, i) => ({
    id: i,
    user: `User ${i + 1}`,
    handle: `@user${i + 1}`,
    time: `${i + 1}h`,
    content: "Just shipped a new feature! The mobile app is looking so clean and smooth. Can't wait for everyone to try it out.",
    likes: Math.floor(Math.random() * 100) + 10,
    comments: Math.floor(Math.random() * 20),
  }));

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      className="flex flex-col h-full bg-background"
    >
      <div className="px-4 pt-12 pb-4 sticky top-0 bg-background/80 backdrop-blur-xl z-10 border-b border-border">
        <h1 className="text-2xl font-bold">Activity</h1>
      </div>

      <div className="flex-1 overflow-y-auto pb-24 divide-y divide-border">
        {posts.map((post) => (
          <motion.div 
            key={post.id} 
            className="p-4 bg-card"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            <div className="flex gap-3">
              <Avatar className="w-10 h-10 border border-border">
                <AvatarImage src={`https://i.pravatar.cc/150?u=${post.id}`} />
                <AvatarFallback>{post.user[0]}</AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 overflow-hidden">
                    <span className="font-semibold text-sm truncate">{post.user}</span>
                    <span className="text-sm text-muted-foreground truncate">{post.handle}</span>
                    <span className="text-sm text-muted-foreground shrink-0">· {post.time}</span>
                  </div>
                  <button className="p-1 text-muted-foreground hover:text-foreground">
                    <MoreHorizontal className="w-4 h-4" />
                  </button>
                </div>
                <p className="mt-1 text-sm text-foreground/90 leading-relaxed">
                  {post.content}
                </p>
                
                {/* Actions */}
                <div className="flex items-center gap-6 mt-4">
                  <button className="flex items-center gap-1.5 text-muted-foreground hover:text-primary transition-colors">
                    <Heart className="w-4 h-4" />
                    <span className="text-xs font-medium">{post.likes}</span>
                  </button>
                  <button className="flex items-center gap-1.5 text-muted-foreground hover:text-primary transition-colors">
                    <MessageCircle className="w-4 h-4" />
                    <span className="text-xs font-medium">{post.comments}</span>
                  </button>
                  <button className="flex items-center gap-1.5 text-muted-foreground hover:text-primary transition-colors ml-auto">
                    <Share2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}
